import os, re, datetime as dt

_CHK = "ACDEFGHJKLMNPRTUVWXY"  # 20 letters, no look-alikes (no B/I/O/Q/S/Z)

def make_slug(s: str) -> str:
    s = re.sub(r"[^A-Z0-9]+", "_", (s or "").upper()).strip("_")[:40].strip("_")
    return s or "STORY"

def broadcast_day(now: dt.datetime, day_start: str = "05:00") -> dt.date:
    """'Today' starts at day_start, not midnight (check D6)."""
    h, m = (int(x) for x in day_start.split(":"))
    return (now - dt.timedelta(hours=h, minutes=m)).date()

def check_char(day: dt.date, seq: int) -> str:
    """Weighted digit sum -> one letter. Catches single-digit typos and most swaps when an ID is typed."""
    digits = f"{day:%Y%m%d}{seq:04d}"
    return _CHK[sum(int(d) * (i + 1) for i, d in enumerate(digits)) % len(_CHK)]

def display_id(day: dt.date, seq: int, slug: str, version: int = 1, check: bool | None = None) -> str:
    if check is None: check = os.getenv("CHECK_CHAR", "1") == "1"
    num = f"{seq:04d}" + (check_char(day, seq) if check else "")
    base = f"{day:%Y%m%d}_{num}_{make_slug(slug)}"
    return base if version == 1 else f"{base}_V{version}"
