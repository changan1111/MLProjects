import os, re, uuid, time, secrets, threading, datetime as dt
from contextlib import contextmanager
from typing import Optional
from zoneinfo import ZoneInfo
import psycopg2, psycopg2.extras, psycopg2.pool
from psycopg2.extras import Json
from fastapi import FastAPI, Header, HTTPException, Depends, Cookie, Response
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel
from .ids import broadcast_day, display_id, check_char
from .security import hash_pw, check_pw
from .alerts import send_alert

API_KEY = os.environ["SERVICE_API_KEY"]
TZ = ZoneInfo(os.getenv("TZ", "UTC")); DAY_START = os.getenv("BROADCAST_DAY_START", "05:00")
MAX_ATTACH = int(os.getenv("MAX_ATTACH_ATTEMPTS", "3")); CUTOVER = os.getenv("CUTOVER_RUNDOWN_REGEX", ".*")
STALE = int(os.getenv("STALE_SECS", "90")); BLAZE_SILENT = int(os.getenv("BLAZE_SILENT_SECS", "300"))
STATES = {"WAITING_FOR_CLIP", "EXPORTING", "VERIFIED", "ON_NITRO", "ATTACH_SUBMITTED", "ATTACHED", "NEEDS_DESK", "QUARANTINED"}
CONFIRM_SECS = int(os.getenv("ATTACH_CONFIRM_SECS", "600"))   # alert if a submitted attach is still unconfirmed after this long
RANK = {"editor": 1, "desk": 2, "admin": 3}

SCHEMA = """
CREATE TABLE IF NOT EXISTS rundowns(id serial PRIMARY KEY, blaze_rundown_id text UNIQUE NOT NULL, name text, air_date date);
CREATE TABLE IF NOT EXISTS stories(id serial PRIMARY KEY, blaze_story_id text NOT NULL, rundown_id int NOT NULL REFERENCES rundowns(id),
  slug text, last_seen_at timestamptz DEFAULT now(), deleted boolean DEFAULT false, UNIQUE(rundown_id, blaze_story_id));
CREATE TABLE IF NOT EXISTS counters(day date PRIMARY KEY, last int NOT NULL);
CREATE TABLE IF NOT EXISTS clip_ids(id serial PRIMARY KEY, display_id text UNIQUE NOT NULL, day date NOT NULL, seq int NOT NULL,
  story_id int NOT NULL REFERENCES stories(id), version int NOT NULL DEFAULT 1, state text NOT NULL DEFAULT 'WAITING_FOR_CLIP',
  created_at timestamptz DEFAULT now(), UNIQUE(day, seq, version));
CREATE TABLE IF NOT EXISTS files(id serial PRIMARY KEY, clip_id int NOT NULL REFERENCES clip_ids(id), nas_path text, nitro_path text,
  size bigint, sha256 text, state text, error text, created_at timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS events(id serial PRIMARY KEY, time timestamptz DEFAULT now(), actor text, action text, details jsonb);
CREATE TABLE IF NOT EXISTS users(id serial PRIMARY KEY, username text UNIQUE NOT NULL, pw_hash text NOT NULL, role text NOT NULL, active boolean NOT NULL DEFAULT true);
CREATE TABLE IF NOT EXISTS sessions(token text PRIMARY KEY, user_id int NOT NULL REFERENCES users(id), expires timestamptz NOT NULL);
CREATE TABLE IF NOT EXISTS heartbeats(component text PRIMARY KEY, ts timestamptz NOT NULL DEFAULT now(), detail jsonb);
ALTER TABLE clip_ids ADD COLUMN IF NOT EXISTS verified_at timestamptz, ADD COLUMN IF NOT EXISTS on_nitro_at timestamptz,
  ADD COLUMN IF NOT EXISTS attached_at timestamptz, ADD COLUMN IF NOT EXISTS attach_attempts int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS attach_last_try timestamptz, ADD COLUMN IF NOT EXISTS attach_method text, ADD COLUMN IF NOT EXISTS attach_error text;
ALTER TABLE files ADD COLUMN IF NOT EXISTS duration_s double precision;
CREATE OR REPLACE FUNCTION events_ro() RETURNS trigger AS $$ BEGIN RAISE EXCEPTION 'events is append-only'; END $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS events_ro_t ON events;
CREATE TRIGGER events_ro_t BEFORE UPDATE OR DELETE ON events FOR EACH ROW EXECUTE FUNCTION events_ro();
"""

pool = None
app = FastAPI(title="Auto-ID Registry")

@contextmanager
def tx():
    conn = pool.getconn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            yield cur
        conn.commit()
    except Exception:
        conn.rollback(); raise
    finally:
        pool.putconn(conn)

@app.on_event("startup")
def startup():
    global pool
    for _ in range(30):
        try: pool = psycopg2.pool.ThreadedConnectionPool(1, 10, os.environ["DATABASE_URL"]); break
        except psycopg2.OperationalError: time.sleep(2)
    with tx() as cur:
        cur.execute(SCHEMA)
        cur.execute("SELECT count(*) AS n FROM users")
        if cur.fetchone()["n"] == 0 and os.getenv("ADMIN_PASSWORD"):
            cur.execute("INSERT INTO users(username,pw_hash,role) VALUES(%s,%s,'admin')", (os.getenv("ADMIN_USER", "admin"), hash_pw(os.environ["ADMIN_PASSWORD"])))
    threading.Thread(target=monitor, daemon=True).start()

# ---------- helpers ----------
def svc_auth(x_api_key: str = Header("")):
    if x_api_key != API_KEY: raise HTTPException(401, "bad api key")

def need(role):
    def dep(sid: Optional[str] = Cookie(None)):
        if not sid: raise HTTPException(401, "login required")
        with tx() as cur:
            cur.execute("SELECT u.username,u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=%s AND s.expires>now() AND u.active", (sid,))
            u = cur.fetchone()
        if not u: raise HTTPException(401, "session expired")
        if RANK[u["role"]] < RANK[role]: raise HTTPException(403, "not allowed for your role")
        return u
    return dep

def log(cur, actor, action, details):
    import json
    cur.execute("INSERT INTO events(actor,action,details) VALUES(%s,%s,%s)", (actor, action, Json(details, dumps=lambda o: json.dumps(o, default=str))))

def today() -> dt.date: return broadcast_day(dt.datetime.now(TZ), DAY_START)

def next_seq(cur, day) -> int:
    cur.execute("INSERT INTO counters(day,last) VALUES(%s,1) ON CONFLICT(day) DO UPDATE SET last=counters.last+1 RETURNING last", (day,))
    return cur.fetchone()["last"]

def new_clip(cur, story_id, slug, day, seq, version=1):
    cur.execute("INSERT INTO clip_ids(display_id,day,seq,story_id,version) VALUES(%s,%s,%s,%s,%s) RETURNING *", (display_id(day, seq, slug, version), day, seq, story_id, version))
    return cur.fetchone()

def get_rundown(cur, rid, name=None):
    cur.execute("INSERT INTO rundowns(blaze_rundown_id,name,air_date) VALUES(%s,%s,%s) ON CONFLICT(blaze_rundown_id) DO UPDATE SET name=COALESCE(EXCLUDED.name, rundowns.name) RETURNING id", (rid, name, today()))
    return cur.fetchone()["id"]

# ---------- models ----------
class StoryIn(BaseModel):
    blaze_rundown_id: str; blaze_story_id: str; slug: str = ""; rundown_name: Optional[str] = None
class RenameIn(BaseModel):
    blaze_rundown_id: str; old_id: str; new_id: str
class DeleteIn(BaseModel):
    blaze_rundown_id: str; blaze_story_id: Optional[str] = None
class FileIn(BaseModel):
    display_id: str; state: str; nas_path: Optional[str] = None; nitro_path: Optional[str] = None
    size: Optional[int] = None; sha256: Optional[str] = None; error: Optional[str] = None; duration_s: Optional[float] = None
class AttachResult(BaseModel):
    display_id: str; ok: bool; method: str; error: Optional[str] = None; shadow: bool = False
    confirmed: bool = False      # True ONLY when the story/clip link was read back from Blaze. Message accepted / clicks done is NOT confirmed.
class AttachConfirm(BaseModel):
    display_id: str; blaze_rundown_id: str; blaze_story_id: str; source: str = "mos_item"
class HeartbeatIn(BaseModel):
    component: str; detail: dict = {}
class ManualIn(BaseModel): slug: str
class LoginIn(BaseModel): username: str; password: str
class UserIn(BaseModel): username: str; password: str; role: str

@app.get("/healthz")
def healthz():
    with tx() as cur: cur.execute("SELECT 1")
    return {"ok": True}

# ---------- service endpoints (not routed by nginx) ----------
@app.post("/svc/stories", dependencies=[Depends(svc_auth)])
def upsert_story(b: StoryIn):
    with tx() as cur:
        rid = get_rundown(cur, b.blaze_rundown_id, b.rundown_name)
        cur.execute("SELECT id FROM stories WHERE rundown_id=%s AND blaze_story_id=%s", (rid, b.blaze_story_id))
        row = cur.fetchone()
        if row:
            cur.execute("UPDATE stories SET slug=COALESCE(NULLIF(%s,''),slug), last_seen_at=now(), deleted=false WHERE id=%s", (b.slug, row["id"]))
            cur.execute("SELECT * FROM clip_ids WHERE story_id=%s ORDER BY version LIMIT 1", (row["id"],))
            return cur.fetchone()
        cur.execute("INSERT INTO stories(blaze_story_id,rundown_id,slug) VALUES(%s,%s,%s) RETURNING id", (b.blaze_story_id, rid, b.slug))
        sid = cur.fetchone()["id"]; day = today()
        clip = new_clip(cur, sid, b.slug, day, next_seq(cur, day))
        log(cur, "mos", "clip_id_created", {"display_id": clip["display_id"], "story": b.blaze_story_id})
        return clip

@app.post("/svc/stories/rename", dependencies=[Depends(svc_auth)])
def rename_story(b: RenameIn):
    with tx() as cur:
        rid = get_rundown(cur, b.blaze_rundown_id)
        cur.execute("UPDATE stories SET blaze_story_id=%s WHERE rundown_id=%s AND blaze_story_id=%s", (b.new_id, rid, b.old_id))
        log(cur, "mos", "story_id_changed", b.model_dump()); return {"updated": cur.rowcount}

@app.post("/svc/stories/delete", dependencies=[Depends(svc_auth)])
def delete_story(b: DeleteIn):
    with tx() as cur:
        rid = get_rundown(cur, b.blaze_rundown_id)
        if b.blaze_story_id: cur.execute("UPDATE stories SET deleted=true WHERE rundown_id=%s AND blaze_story_id=%s", (rid, b.blaze_story_id))
        else: cur.execute("UPDATE stories SET deleted=true WHERE rundown_id=%s", (rid,))
        log(cur, "mos", "story_deleted", b.model_dump()); return {"updated": cur.rowcount}

@app.get("/svc/match", dependencies=[Depends(svc_auth)])
def match(day: str, seq: int, version: int = 1, chk: Optional[str] = None):
    """Match on date + number only. If a check letter was typed it must be right (catches typos)."""
    d = dt.datetime.strptime(day, "%Y%m%d").date()
    if chk and chk != check_char(d, seq): raise HTTPException(422, "check character mismatch: the ID was probably mistyped")
    with tx() as cur:
        cur.execute("SELECT * FROM clip_ids WHERE day=%s AND seq=%s AND version=%s", (d, seq, version)); row = cur.fetchone()
    if not row: raise HTTPException(404, "no such clip id")
    return row

@app.post("/svc/files", dependencies=[Depends(svc_auth)])
def file_event(f: FileIn):
    if f.state not in STATES: raise HTTPException(400, "bad state")
    with tx() as cur:
        cur.execute("SELECT id FROM clip_ids WHERE display_id=%s", (f.display_id,)); c = cur.fetchone()
        if not c: raise HTTPException(404, "unknown display_id")
        cur.execute("INSERT INTO files(clip_id,nas_path,nitro_path,size,sha256,state,error,duration_s) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)",
                    (c["id"], f.nas_path, f.nitro_path, f.size, f.sha256, f.state, f.error, f.duration_s))
        cur.execute("""UPDATE clip_ids SET state=%s,
            verified_at = CASE WHEN %s='VERIFIED' THEN now() ELSE verified_at END,
            on_nitro_at = CASE WHEN %s='ON_NITRO' THEN now() ELSE on_nitro_at END
            WHERE id=%s AND state NOT IN ('ATTACHED','ATTACH_SUBMITTED')
              AND NOT (%s='VERIFIED' AND state IN ('ON_NITRO','NEEDS_DESK'))""", (f.state, f.state, f.state, c["id"], f.state))
        log(cur, "watcher", "file_" + f.state.lower(), f.model_dump())
    return {"ok": True}

@app.post("/svc/heartbeat", dependencies=[Depends(svc_auth)])
def heartbeat(h: HeartbeatIn):
    with tx() as cur:
        cur.execute("INSERT INTO heartbeats(component,ts,detail) VALUES(%s,now(),%s) ON CONFLICT(component) DO UPDATE SET ts=now(), detail=EXCLUDED.detail", (h.component, Json(h.detail)))
    return {"ok": True}

@app.get("/svc/attach/pending", dependencies=[Depends(svc_auth)])
def attach_pending(limit: int = 5):
    """Clips on Nitro but not attached. Back-off grows with each failed attempt. Only rundowns matching CUTOVER_RUNDOWN_REGEX."""
    with tx() as cur:
        cur.execute("""SELECT c.display_id, c.version, c.attach_attempts, s.slug, s.blaze_story_id, r.blaze_rundown_id, r.name AS rundown_name,
              (SELECT nitro_path FROM files f WHERE f.clip_id=c.id AND f.state='ON_NITRO' ORDER BY f.id DESC LIMIT 1) AS nitro_path,
              (SELECT duration_s FROM files f WHERE f.clip_id=c.id AND f.state='ON_NITRO' ORDER BY f.id DESC LIMIT 1) AS duration_s
            FROM clip_ids c JOIN stories s ON s.id=c.story_id JOIN rundowns r ON r.id=s.rundown_id
            WHERE c.state='ON_NITRO' AND r.blaze_rundown_id<>'manual' AND NOT s.deleted AND c.attach_attempts<%s
              AND (c.attach_last_try IS NULL OR now()-c.attach_last_try > make_interval(mins => c.attach_attempts*c.attach_attempts))
            ORDER BY c.id LIMIT %s""", (MAX_ATTACH, limit * 5))
        rows = [r for r in cur.fetchall() if re.search(CUTOVER, r["rundown_name"] or "")]
    return rows[:limit]

@app.post("/svc/attach/result", dependencies=[Depends(svc_auth)])
def attach_result(r: AttachResult):
    """ok+confirmed -> ATTACHED. ok but NOT confirmed -> ATTACH_SUBMITTED (Blaze accepted the request; nobody has seen the result yet).
    ATTACH_SUBMITTED becomes ATTACHED only via /svc/attach/confirm (read back from Blaze) or a desk click."""
    with tx() as cur:
        if r.ok and r.shadow:   # shadow run: record what we WOULD have done, never touch the state
            cur.execute("UPDATE clip_ids SET attach_attempts=%s, attach_method='shadow', attach_last_try=now() WHERE display_id=%s", (MAX_ATTACH, r.display_id))
            log(cur, "attach", "attach_shadow", r.model_dump())
        elif r.ok and r.confirmed:
            cur.execute("UPDATE clip_ids SET state='ATTACHED', attached_at=now(), attach_method=%s, attach_error=NULL WHERE display_id=%s AND state IN ('ON_NITRO','ATTACH_SUBMITTED','NEEDS_DESK')", (r.method + "+verified", r.display_id))
            log(cur, "attach", "attached_verified", r.model_dump())
        elif r.ok:
            cur.execute("UPDATE clip_ids SET state='ATTACH_SUBMITTED', attach_method=%s, attach_last_try=now(), attach_error=NULL WHERE display_id=%s AND state='ON_NITRO'", (r.method, r.display_id))
            log(cur, "attach", "attach_submitted", r.model_dump())
        else:
            cur.execute("UPDATE clip_ids SET attach_attempts=attach_attempts+1, attach_last_try=now(), attach_error=%s WHERE display_id=%s RETURNING attach_attempts", (r.error, r.display_id))
            n = cur.fetchone()["attach_attempts"]
            log(cur, "attach", "attach_failed", {**r.model_dump(), "attempt": n})
            if n >= MAX_ATTACH:
                cur.execute("UPDATE clip_ids SET state='NEEDS_DESK' WHERE display_id=%s AND state='ON_NITRO'", (r.display_id,))
                threading.Thread(target=send_alert, args=("%s could not be attached automatically (%s). Desk please attach by hand." % (r.display_id, r.error),), daemon=True).start()
    return {"ok": True}

@app.post("/svc/attach/confirm", dependencies=[Depends(svc_auth)])
def attach_confirm(b: AttachConfirm):
    """Blaze itself reported that this clip object sits in a story. Accept only if it is the RIGHT story; a wrong story needs a human."""
    with tx() as cur:
        cur.execute("""SELECT c.id, c.state, s.blaze_story_id, r.blaze_rundown_id FROM clip_ids c JOIN stories s ON s.id=c.story_id
                       JOIN rundowns r ON r.id=s.rundown_id WHERE c.display_id=%s""", (b.display_id,)); c = cur.fetchone()
        if not c: raise HTTPException(404, "unknown display_id")
        if c["state"] == "ATTACHED": return {"ok": True, "state": "ATTACHED", "note": "already attached"}
        if c["blaze_story_id"] != b.blaze_story_id or c["blaze_rundown_id"] != b.blaze_rundown_id:
            msg = "WRONG STORY: Blaze shows %s in %s/%s, registry expects %s/%s" % (b.display_id, b.blaze_rundown_id, b.blaze_story_id, c["blaze_rundown_id"], c["blaze_story_id"])
            cur.execute("UPDATE clip_ids SET state='NEEDS_DESK', attach_error=%s WHERE id=%s", (msg, c["id"]))
            log(cur, "attach", "attach_wrong_story", b.model_dump())
            threading.Thread(target=send_alert, args=(msg,), daemon=True).start()
            return {"ok": False, "state": "NEEDS_DESK", "error": msg}
        if c["state"] not in ("ATTACH_SUBMITTED", "ON_NITRO", "NEEDS_DESK"): return {"ok": False, "state": c["state"], "note": "clip not in an attachable state"}
        cur.execute("UPDATE clip_ids SET state='ATTACHED', attached_at=now(), attach_method=%s, attach_error=NULL WHERE id=%s", (b.source + "+verified", c["id"]))
        log(cur, "blaze", "attached_verified", b.model_dump()); return {"ok": True, "state": "ATTACHED"}

# ---------- health, alerts, metrics ----------
def compute_health():
    with tx() as cur:
        cur.execute("SELECT component, EXTRACT(EPOCH FROM now()-ts)::float AS age, detail FROM heartbeats"); hb = {r["component"]: r for r in cur.fetchall()}
    res = {}
    for c in ("gateway", "watcher", "attach"):
        r = hb.get(c)
        if r is None:
            if c != "attach": res[c] = (False, "%s has never reported" % c)
        else: res[c] = (r["age"] < STALE, "%s last seen %ds ago" % (c, r["age"]))
    g = hb.get("gateway")
    if g and BLAZE_SILENT > 0:
        d = g["detail"] or {}; la, up = d.get("last_mos_age"), d.get("uptime", 0)
        res["blaze_link"] = ((la is not None and la <= BLAZE_SILENT) or (la is None and up < BLAZE_SILENT), "no MOS traffic from Blaze for %s s" % (int(la) if la is not None else "any"))
    w = hb.get("watcher")
    if w: res["nas_nitro"] = (bool((w["detail"] or {}).get("nas_ok", True)), "NAS or Nitro folder not reachable from the watcher")
    return res

def check_unconfirmed(warned: set):
    """Alert once per clip whose attach was accepted by Blaze but never confirmed (read back or clicked by the desk)."""
    with tx() as cur:
        cur.execute("SELECT display_id FROM clip_ids WHERE state='ATTACH_SUBMITTED' AND attach_last_try < now()-make_interval(secs => %s)", (CONFIRM_SECS,))
        stuck = {r["display_id"] for r in cur.fetchall()}
    for d in stuck - warned: send_alert("%s: attach was submitted but NOT confirmed in Blaze after %d s. Desk: check the story, then Confirm attached or Retry." % (d, CONFIRM_SECS))
    warned.intersection_update(stuck); warned.update(stuck)

def monitor():
    time.sleep(60); state = {}; warned = set()
    while True:
        try: check_unconfirmed(warned)
        except Exception: pass
        try:
            for name, (ok, msg) in compute_health().items():
                if state.get(name, True) != ok:
                    state[name] = ok
                    send_alert(("RECOVERED: %s" % name) if ok else ("DOWN: %s - %s" % (name, msg)))
                    with tx() as cur: log(cur, "monitor", "recovered" if ok else "down", {"check": name, "msg": msg})
        except Exception: pass
        time.sleep(30)

@app.get("/metrics", response_class=PlainTextResponse)
def metrics():
    out = []
    with tx() as cur:
        cur.execute("SELECT state, count(*) AS n FROM clip_ids WHERE day=%s GROUP BY state", (today(),))
        counts = {r["state"]: r["n"] for r in cur.fetchall()}
    for s in sorted(STATES): out.append('autoid_clips{state="%s"} %d' % (s, counts.get(s, 0)))
    for name, (ok, _) in compute_health().items(): out.append('autoid_check_ok{check="%s"} %d' % (name, 1 if ok else 0))
    return "\n".join(out) + "\n"

# ---------- UI endpoints (nginx exposes /api/ only) ----------
@app.post("/api/login")
def login(b: LoginIn, resp: Response):
    k = b.username.lower(); n, t = FAIL.get(k, (0, 0))
    if n >= 5 and time.time() - t < 60: raise HTTPException(429, "too many attempts, wait a minute")
    ok = False
    with tx() as cur:
        cur.execute("DELETE FROM sessions WHERE expires<now()")
        cur.execute("SELECT id,pw_hash,role,active FROM users WHERE lower(username)=%s", (k,)); u = cur.fetchone()
        ok = bool(u and u["active"] and check_pw(b.password, u["pw_hash"]))
        if ok:
            token = secrets.token_urlsafe(32)
            cur.execute("INSERT INTO sessions(token,user_id,expires) VALUES(%s,%s,now()+interval '12 hours')", (token, u["id"]))
        log(cur, b.username, "login_ok" if ok else "login_failed", {})
    if not ok:
        FAIL[k] = (n + 1, time.time()); raise HTTPException(401, "wrong username or password")
    FAIL.pop(k, None)
    resp.set_cookie("sid", token, httponly=True, secure=True, samesite="lax", max_age=43200)
    return {"username": b.username, "role": u["role"]}
FAIL = {}

@app.post("/api/logout")
def logout(resp: Response, sid: Optional[str] = Cookie(None)):
    with tx() as cur: cur.execute("DELETE FROM sessions WHERE token=%s", (sid,))
    resp.delete_cookie("sid"); return {"ok": True}

@app.get("/api/me")
def me(u=Depends(need("editor"))): return u

@app.get("/api/config")
def config(u=Depends(need("editor"))):
    """Option C: link template that opens the story in Blaze, e.g. https://blaze/story/{blaze_rundown_id}/{blaze_story_id}"""
    return {"story_url": os.getenv("BLAZE_STORY_URL_TEMPLATE", "")}

@app.get("/api/status")
def status(u=Depends(need("editor"))):
    return {"problems": [m for _, (ok, m) in compute_health().items() if not ok]}

@app.get("/api/clips")
def clips(day: Optional[str] = None, u=Depends(need("editor"))):
    d = dt.datetime.strptime(day, "%Y%m%d").date() if day else today()
    with tx() as cur:
        cur.execute("""SELECT c.id, c.display_id, c.version, c.state, s.slug, s.deleted, r.name AS rundown, r.blaze_rundown_id, s.blaze_story_id, c.created_at,
            COALESCE(c.attach_error, (SELECT error FROM files f WHERE f.clip_id=c.id ORDER BY f.id DESC LIMIT 1)) AS error
            FROM clip_ids c JOIN stories s ON s.id=c.story_id JOIN rundowns r ON r.id=s.rundown_id WHERE c.day=%s ORDER BY c.seq, c.version""", (d,))
        return {"day": d.isoformat(), "clips": cur.fetchall()}

@app.post("/api/manual")
def manual(b: ManualIn, u=Depends(need("editor"))):
    """Standalone mode (risk R1): the desk creates the ID itself when Blaze sends no stories."""
    with tx() as cur:
        rid = get_rundown(cur, "manual", "MANUAL")
        cur.execute("INSERT INTO stories(blaze_story_id,rundown_id,slug) VALUES(%s,%s,%s) RETURNING id", ("manual-" + uuid.uuid4().hex, rid, b.slug))
        sid = cur.fetchone()["id"]; day = today(); clip = new_clip(cur, sid, b.slug, day, next_seq(cur, day))
        log(cur, u["username"], "manual_clip_id", {"display_id": clip["display_id"]}); return clip

@app.post("/api/clips/{clip_id}/version")
def add_version(clip_id: int, u=Depends(need("editor"))):
    with tx() as cur:
        cur.execute("SELECT c.*, s.slug FROM clip_ids c JOIN stories s ON s.id=c.story_id WHERE c.id=%s", (clip_id,)); c = cur.fetchone()
        if not c: raise HTTPException(404)
        cur.execute("SELECT max(version) AS v FROM clip_ids WHERE story_id=%s", (c["story_id"],))
        clip = new_clip(cur, c["story_id"], c["slug"], c["day"], c["seq"], cur.fetchone()["v"] + 1)
        log(cur, u["username"], "version_added", {"display_id": clip["display_id"]}); return clip

@app.post("/api/clips/{clip_id}/attached")
def mark_attached(clip_id: int, u=Depends(need("desk"))):
    """Desk looked at the story in Blaze and confirms the right clip is on the right story (also the only way out of ATTACH_SUBMITTED when Blaze cannot be read back)."""
    with tx() as cur:
        cur.execute("UPDATE clip_ids SET state='ATTACHED', attached_at=now(), attach_method='desk', attach_error=NULL WHERE id=%s AND state IN ('ON_NITRO','NEEDS_DESK','ATTACH_SUBMITTED') RETURNING display_id", (clip_id,))
        row = cur.fetchone()
        if not row: raise HTTPException(409, "clip must be ON_NITRO, ATTACH_SUBMITTED or NEEDS_DESK")
        log(cur, u["username"], "attached_by_desk", row); return row

@app.post("/api/clips/{clip_id}/retry")
def retry_attach(clip_id: int, u=Depends(need("desk"))):
    with tx() as cur:
        cur.execute("UPDATE clip_ids SET state='ON_NITRO', attach_attempts=0, attach_last_try=NULL, attach_error=NULL WHERE id=%s AND state IN ('NEEDS_DESK','ATTACH_SUBMITTED') RETURNING display_id", (clip_id,))
        row = cur.fetchone()
        if not row: raise HTTPException(409, "only NEEDS_DESK or ATTACH_SUBMITTED clips can be retried (check Blaze first so the clip is not attached twice)")
        log(cur, u["username"], "attach_retry", row); return row

@app.get("/api/events")
def events(limit: int = 100, u=Depends(need("desk"))):
    with tx() as cur:
        cur.execute("SELECT * FROM events ORDER BY id DESC LIMIT %s", (min(limit, 500),)); return cur.fetchall()

@app.get("/api/users")
def users(u=Depends(need("admin"))):
    with tx() as cur: cur.execute("SELECT id,username,role,active FROM users ORDER BY username"); return cur.fetchall()

@app.post("/api/users")
def add_user(b: UserIn, u=Depends(need("admin"))):
    if b.role not in RANK: raise HTTPException(400, "role must be editor, desk or admin")
    if len(b.password) < 8: raise HTTPException(400, "password needs 8+ characters")
    with tx() as cur:
        cur.execute("INSERT INTO users(username,pw_hash,role) VALUES(%s,%s,%s) ON CONFLICT(username) DO UPDATE SET pw_hash=EXCLUDED.pw_hash, role=EXCLUDED.role, active=true",
                    (b.username, hash_pw(b.password), b.role))
        log(cur, u["username"], "user_saved", {"user": b.username, "role": b.role}); return {"ok": True}

@app.post("/api/users/{user_id}/disable")
def disable_user(user_id: int, u=Depends(need("admin"))):
    with tx() as cur:
        cur.execute("UPDATE users SET active=false WHERE id=%s", (user_id,)); cur.execute("DELETE FROM sessions WHERE user_id=%s", (user_id,))
        log(cur, u["username"], "user_disabled", {"id": user_id}); return {"ok": True}
