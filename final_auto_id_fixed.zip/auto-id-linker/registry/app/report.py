"""Shadow-run report (Phase 3).  docker compose exec registry python -m app.report --day 20261020 [--desk-csv desk.csv] [--out day.csv]
desk.csv = what the desk did by hand that day, one column named 'clip' (a filename or ID starting YYYYMMDD_NNNN)."""
import argparse, csv, datetime as dt, os, re, sys
import psycopg2, psycopg2.extras
from zoneinfo import ZoneInfo
from .ids import broadcast_day

def key(s):
    m = re.match(r"^(\d{8})_(\d{4})", os.path.basename(s.strip())); return (m.group(1), int(m.group(2))) if m else None

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--day"); ap.add_argument("--desk-csv"); ap.add_argument("--out"); a = ap.parse_args()
    day = dt.datetime.strptime(a.day, "%Y%m%d").date() if a.day else broadcast_day(dt.datetime.now(ZoneInfo(os.getenv("TZ", "UTC"))), os.getenv("BROADCAST_DAY_START", "05:00"))
    with psycopg2.connect(os.environ["DATABASE_URL"]) as c, c.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("""SELECT display_id, version, state, created_at, verified_at, on_nitro_at, attached_at, attach_method, attach_error
                       FROM clip_ids WHERE day=%s ORDER BY seq, version""", (day,)); rows = cur.fetchall()
    n = len(rows); by = {}
    for r in rows: by[r["state"]] = by.get(r["state"], 0) + 1
    secs = [(r["on_nitro_at"] - r["verified_at"]).total_seconds() for r in rows if r["on_nitro_at"] and r["verified_at"]]
    print("Day %s: %d IDs  %s" % (day, n, by))
    if secs: print("Verified->Nitro: avg %.1fs, max %.1fs over %d clips" % (sum(secs) / len(secs), max(secs), len(secs)))
    if a.desk_csv:
        desk = {key(r["clip"]) for r in csv.DictReader(open(a.desk_csv)) if key(r["clip"])}
        ours = {(r["display_id"][:8], int(r["display_id"][9:13])) for r in rows if r["state"] in ("ON_NITRO", "ATTACHED")}
        print("Desk did, we missed:", sorted(desk - ours) or "none"); print("We did, desk log lacks:", sorted(ours - desk) or "none")
    if a.out:
        with open(a.out, "w", newline="") as f:
            w = csv.writer(f); w.writerow(["display_id", "state", "created", "verified", "on_nitro", "attached", "method", "error"])
            for r in rows: w.writerow([r["display_id"], r["state"], r["created_at"], r["verified_at"], r["on_nitro_at"], r["attached_at"], r["attach_method"], r["attach_error"]])
        print("wrote", a.out)
if __name__ == "__main__": main()
