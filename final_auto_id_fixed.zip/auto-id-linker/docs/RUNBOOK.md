# Runbook

## ONE-PAGE MANUAL FALLBACK (print this)
If the Auto-ID page is down or red, **work exactly as before**:
1. Name the export by your usual rule and put it on the NAS as always.
2. Desk copies the clip to Nitro and attaches it in Blaze by hand.
3. Tell the on-call person. Do NOT type IDs from memory later: new IDs are made by the system.
Blaze, NAS and Nitro are not affected by this system being down.

## Daily checks (2 minutes)
Page banner green. Nothing stuck in QUARANTINED. Any NEEDS_DESK handled. Grafana "checks OK" all 1.

## Common actions
| Task | Command |
|---|---|
| Status | `docker compose ps` |
| Logs | `docker compose logs -f --tail=100 <service>` (registry, mos-gateway, watcher, attach, web) |
| Restart one service | `docker compose restart watcher` |
| Update after code change | `docker compose up -d --build` |
| Switch attach mode (rollback to manual) | edit `ATTACH_MODE=desk` in `.env`, then `docker compose up -d attach` |
| Clips on Nitro but not ON_NITRO in the registry | `docker compose exec watcher python reconcile_nitro.py` (dry run), then add `--fix` |
| Clip stuck ATTACH_SUBMITTED | open the story in Blaze: right clip there -> **confirm attached**; not there -> **Retry**; wrong clip -> fix by hand, then confirm |
| Watcher crashed mid-copy | nothing to do: restart it. Dead-pid locks break at once, other locks after `LOCK_STALE_SECS`; leftover `.part` files go after `PART_STALE_SECS`. Never delete files in `Exports/.autoid-locks` while a watcher is running |
| Reprocess a quarantined clip | rename it so it starts with the right ID, move it back to Exports |
| Add or disable a user | web page, Users box (admin) |
| Raw MOS traffic | `docker compose exec mos-gateway tail -n 100 /data/mos_capture.log` |
| Audit trail | desk/admin: Recent activity on the page, or `docker compose exec db psql -U autoid -c "select * from events order by id desc limit 50"` |

## After every Blaze update
Send a test rundown, confirm IDs appear, run one clip through Exports to Nitro, and for option A/B run one attach on the test channel.

## Incidents
- **blaze_link down:** check Blaze device status and firewall. IDs missing for stories created meanwhile: use standalone box or re-send the rundown (the gateway's calls are idempotent).
- **Two watchers running by mistake:** safe (they claim files one at a time), but stop the extra one: `docker compose ps`. Both must see the same `LOCK_DIR`; if they do not share Exports, set `LOCK_DIR` to a shared folder.
- **nas_nitro down:** remount (`sudo mount -a`), then `docker compose restart watcher`. Files wait safely in Exports.
- **VM dead:** `./ops/promote_standby.sh` on the standby, move DNS and the Blaze device host. Restore from `backups/` if no standby.
- **Owner and on-call:** write names and phone numbers here: ______________________
