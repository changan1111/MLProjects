# MOS validation against YOUR Blaze (required before `ATTACH_MODE=mos`)

Passing the unit tests only proves our XML is well formed. It does not prove Blaze accepts it. Until this page is signed off,
`attach` refuses to send (`MOS_PROTOCOL_VALIDATED=0`). Do everything on a **test Blaze and non-production rundown**.

1. **Capture real traffic.** Run `tools/mos_sniffer.py` (or use the gateway's `/data/mos_capture.log`). From Blaze: create/replace a rundown,
   insert/move/delete stories, add a clip item to a story. Also ask your Blaze admin for its MOS version and device settings, and keep Blaze's own MOS log.
2. **Run the checker:** `python3 tools/mos_validate.py --capture mos_capture.log`. Fix every FAIL/CHECK line.
   It compares our `mosObj` element order with a real `mosObj` if you capture one from Blaze's MAM, and flags unhandled message types and mosID mismatches.
3. **Framing / handshake** (confirm in capture, not by assumption): UTF-16BE, one message per `<mos>...</mos>`, no length prefix; which port each message type uses
   (object messages vs run-order messages); whether Blaze sends `heartbeat` / `reqMachInfo` and what profiles it expects from us (gateway advertises 0, 1, 2, 4).
4. **Announce test:** `ATTACH_MODE=mos` + `MOS_PROTOCOL_VALIDATED=1` on the TEST stack only, then
   `docker compose run --rm attach python attach.py --test-announce`. Raw send/receive is saved to `/data/mos_attach_capture.log`.
   Try `MOS_ANNOUNCE_MSG=mosObjCreate` if `mosObj` is rejected. `ACK` = accepted, **not** attached.
5. **Prove the end state:** in Blaze, confirm the object is visible, and that a story built from it contains the *right* clip.
   Check whether Blaze echoes the item back in a run-order message (`roStoryReplace` / `roItemInsert` with `<objID>`): if yes, the gateway
   confirms automatically (and flags a WRONG STORY); if no, every MOS attach stays `ATTACH_SUBMITTED` until the desk confirms.
6. **Sign-off:** date, Blaze version, tester, result: ______________________ . Only then set `MOS_PROTOCOL_VALIDATED=1` for production, and start with one rundown (`CUTOVER_RUNDOWN_REGEX`).
7. Repeat after every Blaze update.
