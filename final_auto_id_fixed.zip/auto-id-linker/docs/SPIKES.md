# Phase 0: spike tests (go / no-go)
Do these on a test Blaze, test NAS share and test Nitro channel. Never on live. Record pass or fail with a date.

| # | Test | How | Pass means |
|---|---|---|---|
| S1 | Blaze sends story messages to a test device | On a spare PC run `python3 tools/mos_sniffer.py`. In Blaze add that PC as MOS device (ports 10540/10541), send a test rundown, create/edit/move/delete a story. Also read Blaze's own MOS log. | `mos_capture.log` shows messages with story ID, slug, rundown. FAIL: use standalone mode (README risk R1) |
| S2 | Story ID survives slug edit, move, delete | Compare captured messages before and after each action | Same story ID, or a predictable mapping (the gateway already handles `roStoryReplace` with a new ID) |
| S3 | Nitro registers a dropped file | Copy a clip made by `tools/make_test_clip.sh` into the Nitro ingest folder on the test channel | Clip appears in the Nitro library. Also note accepted container/codec/frame rate/filename rules (B4) |
| S4 | Blaze accepts a media object from our device | `ATTACH_MODE=mos` values in `.env`, then `docker compose run --rm attach python attach.py --test-announce` | `ACK` and the object is visible/attachable in Blaze. Try `MOS_ANNOUNCE_MSG=mosObjCreate` if rejected. FAIL: option B or desk |
| S5 | Mac: Copy ID works over HTTPS, and NLE export uses the ID as filename | Open the page in the editors' browser, click Copy ID, paste into Notes. In Premiere rename the sequence to the ID and export; Final Cut: name the project | Clipboard works on every Mac; exported filename starts with the ID. FAIL: add a Tauri/Electron helper or NLE panel |
| S6 | Dry run end to end | Steps 7 and 8 of the README on test systems | Story, ID, export, NAS, Nitro all work; then start Phase 1 for real |

Also confirm before coding: Blaze licence allows third-party MOS devices/automation (E1), spare Blaze seat for option B (A8), NAS "file complete" rule (D1), broadcast-day start (D6).
