#!/usr/bin/env bash
# Runs ON THE STANDBY VM (cron every 15 min). Keeps a warm copy of the primary database.
# Standby runs only the db container until promoted:  docker compose up -d db
set -euo pipefail
cd "$(dirname "$0")/.."; set -a; . ./.env; set +a
[ -n "${PRIMARY_SSH:-}" ] || { echo "set PRIMARY_SSH in .env (user@primary-host)"; exit 1; }
ssh -o BatchMode=yes "$PRIMARY_SSH" "cd $PRIMARY_DIR && docker compose exec -T db pg_dump -U autoid --clean --if-exists autoid" \
 | docker compose exec -T db psql -U autoid -d autoid -q -v ON_ERROR_STOP=1 >/dev/null
echo "standby synced $(date -Is)"
