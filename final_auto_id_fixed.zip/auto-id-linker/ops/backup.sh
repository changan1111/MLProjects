#!/usr/bin/env bash
# Nightly: ./ops/backup.sh   (cron: 30 2 * * * /opt/auto-id-linker/ops/backup.sh >> /var/log/autoid-backup.log 2>&1)
set -euo pipefail
cd "$(dirname "$0")/.."; set -a; . ./.env; set +a
mkdir -p backups; f="backups/autoid_$(date +%Y%m%d_%H%M%S).sql.gz"
docker compose exec -T db pg_dump -U autoid --clean --if-exists autoid | gzip > "$f"
gzip -t "$f"                                   # fail loudly if the archive is broken
[ -n "${BACKUP_TARGET:-}" ] && rsync -a "$f" "$BACKUP_TARGET/"   # e.g. backup@otherhost:/srv/autoid
find backups -name 'autoid_*.sql.gz' -mtime +"${BACKUP_KEEP_DAYS:-30}" -delete
echo "backup ok: $f ($(du -h "$f" | cut -f1))"
