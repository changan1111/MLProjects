#!/usr/bin/env bash
# Run on the standby when the primary is dead. Then move the DNS name / IP to this VM and update Blaze's MOS device host if needed.
set -euo pipefail
cd "$(dirname "$0")/.."; docker compose up -d --build
echo "standby is now live. Next: repoint DNS name to this VM; in Blaze point the MOS device to this VM."
