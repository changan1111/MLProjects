#!/usr/bin/env bash
# Monthly proof that backups restore: loads the newest dump into a scratch DB and counts rows.
set -euo pipefail
cd "$(dirname "$0")/.."; f=$(ls -t backups/autoid_*.sql.gz | head -1); echo "testing $f"
docker compose exec -T db psql -U autoid -d postgres -qc "DROP DATABASE IF EXISTS autoid_restore_test" -c "CREATE DATABASE autoid_restore_test"
gunzip -c "$f" | docker compose exec -T db psql -U autoid -d autoid_restore_test -q -v ON_ERROR_STOP=1 >/dev/null
docker compose exec -T db psql -U autoid -d autoid_restore_test -tAc "SELECT 'clip_ids rows: '||count(*) FROM clip_ids"
docker compose exec -T db psql -U autoid -d postgres -qc "DROP DATABASE autoid_restore_test"
echo "restore test PASSED"
