#!/usr/bin/env bash
# ./ops/restore.sh backups/autoid_XXXX.sql.gz   (stop writers first: docker compose stop registry mos-gateway watcher attach)
set -euo pipefail
cd "$(dirname "$0")/.."; [ -f "${1:-}" ] || { echo "usage: $0 backup.sql.gz"; exit 1; }
gunzip -c "$1" | docker compose exec -T db psql -U autoid -d autoid -q -v ON_ERROR_STOP=1
echo "restored $1. Now: docker compose up -d"
