#!/usr/bin/env python3
"""Protocol validation helper for spike S4 / docs/MOS_VALIDATION.md. Compares what OUR code sends with what REAL Blaze traffic looks like.
  python3 tools/mos_validate.py --capture mos_capture.log [--ours-capture mos_attach_capture.log]
Reads the sniffer/gateway capture (messages FROM Blaze) and reports, as PASS / CHECK lines, what you must confirm by eye.
It cannot prove compatibility; it removes guesswork by diffing our mosObj against any real mosObj Blaze (or its MAM) produced."""
import argparse, os, re, sys, xml.etree.ElementTree as ET
_root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
for _d in ("attach", "mos_gateway"): sys.path.insert(0, os.path.join(_root, _d))
os.environ.setdefault("MOS_ID", "AUTOID.LINKER.MOS"); os.environ.setdefault("NCS_ID", "BLAZE.NCS")
import attach, gateway

def messages(path):
    text = open(path, encoding="utf-8", errors="replace").read()
    for m in re.finditer(r"<mos>.*?</mos>", text, re.S):
        try: yield ET.fromstring(m.group(0))
        except ET.ParseError: pass

def body(root): return next((c for c in root if c.tag not in ("mosID", "ncsID", "messageID")), None)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--capture", required=True); ap.add_argument("--ours-capture"); a = ap.parse_args()
    msgs = list(messages(a.capture)); tags = {}
    for r in msgs:
        b = body(r); tags[b.tag if b is not None else "?"] = tags.get(b.tag if b is not None else "?", 0) + 1
    print("Message types seen from Blaze:", ", ".join("%s x%d" % kv for kv in sorted(tags.items())) or "NONE")
    ids = {(r.findtext("mosID"), r.findtext("ncsID")) for r in msgs}
    print("mosID/ncsID pairs seen:", ids or "none", "| ours:", (attach.MOS_ID, attach.NCS_ID),
          "-> PASS" if ids and all(i[0] == attach.MOS_ID for i in ids) else "-> CHECK: Blaze addresses us by a different mosID than MOS_ID")
    handled = set(gateway.ACK_ONLY) | {"heartbeat", "reqMachInfo"}
    unhandled = sorted(t for t in tags if t not in handled)
    print("Unhandled message types:", unhandled or "none", "-> PASS" if not unhandled else "-> CHECK: Blaze may expect an ack we never send")
    if not any(t.startswith("ro") for t in tags): print("CHECK: no run-order (ro*) messages in capture. Send a test rundown from Blaze first (S1).")
    items = [i for r in msgs for i in r.iter("item")]
    print("Items with objID in run-order traffic: %d -> %s" % (sum(1 for i in items if i.findtext("objID")),
          "read-back confirmation is possible" if any(i.findtext("objID") for i in items) else "CHECK: Blaze does not echo objects in stories: ATTACHED will need desk confirmation (or UI verify)"))
    real = [body(r) for r in msgs if body(r) is not None and body(r).tag in ("mosObj", "mosObjCreate")]
    clip = {"display_id": "20990101_0001A_TEST", "slug": "T", "version": 1, "duration_s": 5, "nitro_path": "/x.mov", "blaze_story_id": "S"}
    ours = body(ET.fromstring(attach.build_announce(clip, 1)))
    if real:
        want = [c.tag for c in real[0]]; have = [c.tag for c in ours]
        print("Real mosObj element order :", want); print("Our  mosObj element order :", have)
        print("-> PASS: same order" if want == have else "-> FAIL/CHECK: element order or set differs. Fix build_announce() to match your Blaze MOS version.")
    else: print("CHECK: no real mosObj in capture; capture one from Blaze's own MAM/MOS device and re-run to diff element order.")
    if a.ours_capture and os.path.exists(a.ours_capture):
        t = open(a.ours_capture, encoding="utf-8").read(); acks = re.findall(r"<status>(.*?)</status>", t)
        print("Replies Blaze gave to our announces:", acks or "none", "-> ACK only proves acceptance. Open Blaze and confirm the object is visible and attachable.")
    print("\nWhen every line is PASS or manually checked: set MOS_PROTOCOL_VALIDATED=1 (and record who/when in docs/MOS_VALIDATION.md).")

if __name__ == "__main__": main()
