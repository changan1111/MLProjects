#!/bin/sh
# ./make_test_clip.sh 20261020_0001K_TEST.mov  -> 5-second test clip (needs ffmpeg)
ffmpeg -y -f lavfi -i testsrc=duration=5:size=640x360:rate=25 -f lavfi -i sine=frequency=440:duration=5 -shortest -c:v libx264 -pix_fmt yuv420p -c:a aac "$1"
