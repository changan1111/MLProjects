# Auto-ID Linker: Phases 1 to 3 (plus cut-over)

One automatic ID per editing video. The exported clip reaches Nitro and is linked to its Blaze story with no typing.
Blaze stays unchanged. Everything here is open-source and runs on one Linux VM with Docker Compose.

| Folder | What it is | Phase |
|---|---|---|
| `mos_gateway/` | MOS device Blaze talks to; sends story IDs to the registry | 1 |
| `registry/` | ID registry, API, logins and roles, alerts, metrics, shadow report | 1, 3 |
| `watcher/` | Watches NAS Exports, validates, moves to Nitro, quarantines bad files | 1 |
| `web/` | HTTPS page for the Macs: Copy ID, status, attach buttons, users | 1, 3 |
| `attach/` | Auto-attach: option A (MOS), option B (Playwright bot), shadow mode | 2, 3 |
| `ops/` | Backup, restore test, warm standby, Prometheus + Grafana | 3 |
| `tools/` | MOS sniffer (S1), fake Blaze, test clip maker | 0 |
| `docs/` | `SPIKES.md` (Phase 0 checklist), `RUNBOOK.md` (operations + one-page manual fallback) | all |

---
## STEP 0. Spikes first (1 to 2 weeks, no production)
Follow `docs/SPIKES.md`. The two results that decide the build:
- **S1/S2** Blaze sends story messages and the story ID survives edits. If not, use standalone mode (type the slug once on the web page).
- **S4** whether Blaze accepts a media object from another device. Pass: use `ATTACH_MODE=mos`. Fail: `ui` or stay on `desk`.

## STEP 1. Prepare the VM
Ubuntu LTS, 4 vCPU, 8 GB RAM, 100 GB SSD, static IP, NTP on. Install Docker and Compose, then `git`/`rsync`/`ffmpeg` (ffmpeg only needed for the test clip).
```
sudo apt install -y docker.io docker-compose-v2 rsync ffmpeg
sudo usermod -aG docker $USER      # log out and in
```
Ask IT to open: Blaze to VM TCP 10540 and 10541; VM to NAS 445; VM to Nitro ingest; Macs to VM 443; VM to Blaze MOS port (option A) or Blaze web (option B).

## STEP 2. Copy the project
```
sudo mkdir -p /opt/auto-id-linker && sudo chown $USER /opt/auto-id-linker
unzip auto-id-linker.zip -d /tmp && cp -r /tmp/auto-id-linker/. /opt/auto-id-linker/ && cd /opt/auto-id-linker
```

## STEP 3. Mount the NAS and Nitro folders on the VM
Add SMB mounts to `/etc/fstab` (service account that can only write Exports, Quarantine, Archive and the Nitro ingest folder):
```
//nas/Exports     /mnt/nas/Exports     cifs credentials=/root/.nascred,uid=0,iocharset=utf8,vers=3.0,_netdev 0 0
//nas/Quarantine  /mnt/nas/Quarantine  cifs credentials=/root/.nascred,vers=3.0,_netdev 0 0
//nas/Archive     /mnt/nas/Archive     cifs credentials=/root/.nascred,vers=3.0,_netdev 0 0
//nitro/ingest    /mnt/nitro/ingest    cifs credentials=/root/.nitrocred,vers=3.0,_netdev 0 0
```
`sudo mkdir -p /mnt/nas/{Exports,Quarantine,Archive} /mnt/nitro/ingest && sudo mount -a`. Check you can create a file in each.

## STEP 4. Configure
```
cp .env.example .env && chmod 600 .env && nano .env
```
Set at least: `DB_PASSWORD`, `SERVICE_API_KEY` (long random), `ADMIN_PASSWORD`, `TZ`, `BROADCAST_DAY_START`, the four folder paths, `MOS_ID`/`NCS_ID`. Leave `ATTACH_MODE=desk` for now.

## STEP 5. HTTPS certificate
Production: get a cert for your internal DNS name from your IT CA (the Macs must trust it) and save as `certs/server.crt` and `certs/server.key`.
Testing only: `cd certs && ./make_selfsigned.sh autoid.yourdomain && cd ..` (browsers will warn; Copy ID needs HTTPS).

## STEP 6. Start Phase 1
```
docker compose up -d --build
docker compose ps            # all Up
docker compose logs -f registry mos-gateway watcher
```
Open `https://autoid.yourdomain/`, sign in as `ADMIN_USER`, then create users in the Users box: `editor` (view, copy, versions), `desk` (also attach and retry), `admin` (also users). Change nothing in Blaze yet.

## STEP 7. Smoke test without Blaze
```
python3 tools/send_test_mos.py localhost 10541      # fake Blaze: 2 stories appear on the page
tools/make_test_clip.sh 20261020_0001K_TEST.mov     # use the exact ID shown on the page
cp 20261020_0001K_TEST.mov /mnt/nas/Exports/        # after STABLE_SECS it appears on Nitro; state turns ON_NITRO
```
Also test the quarantine: drop `rubbish.mov` into Exports; it moves to Quarantine with a `.reason.txt` and an alert.

## STEP 8. Connect real Blaze
1. In Blaze add a MOS device: mosID = `MOS_ID`, host = the VM, ports 10540/10541, MOS version 2.8.x.
2. Send a test rundown to that device. Within a minute the `blaze_link` check on the page banner stays green and IDs appear.
3. Check `docker compose exec mos-gateway cat /data/mos_capture.log` shows real messages. If Blaze never sends, use standalone mode (risk R1).
4. Edit a slug, move a story, delete a story. The ID must not change (check A4). If Blaze replaces a story under a new story ID, the gateway already carries the clip ID over.

## STEP 8b. Option C: one-click attach by the desk (works from day one, needs no Blaze automation)
Open any story in Blaze, copy its address-bar URL, replace the rundown and story parts with `{blaze_rundown_id}` and `{blaze_story_id}`, and put it in `.env` as `BLAZE_STORY_URL_TEMPLATE` (ask the Blaze admin which ID appears in the URL). Run `docker compose up -d registry`.
Then the desk sees clips marked ON_NITRO at the top of the page. For each: click **Open in Blaze + copy ID** (opens the story and copies the ID), attach the clip, click **Mark attached**. Takes seconds instead of minutes. This is the permanent fallback for options A and B (`ATTACH_MODE=desk`).

## STEP 9. Train the editors (Phase 1 done)
Editor opens the page, clicks **Copy ID**, names the Premiere sequence (or Final Cut project) with it so the export filename starts with the ID, exports to `/Exports`. Done. The state shows ON_NITRO. Desk then attaches with one click and presses **Mark attached** (option C).

---
## PHASE 2. Auto-attach
Run spike S4 first. Keep `ATTACH_MODE=desk` until one option works on the test channel.

**Option A, MOS announce.** Set `ATTACH_MODE=mos`, `BLAZE_HOST`, `BLAZE_MOS_PORT` (the port Blaze listens on for device messages; often 10540). Test alone: `docker compose run --rm attach python attach.py --test-announce`. A reply of `ACK` means Blaze accepted it. Then check if the object is visible or attachable in Blaze. If Blaze rejects `mosObj`, set `MOS_ANNOUNCE_MSG=mosObjCreate` and test again. If neither shows in Blaze, option A is out.

**Option B, UI bot.** Needs a dedicated Blaze user and a free concurrent seat (check A8, E1).
1. On your laptop: `pip install playwright && playwright install chromium && playwright codegen https://blaze.yourdomain`. Do one real attach by hand and copy the selectors.
2. Put them in `attach/ui_steps.json` replacing every `CHANGE_ME` (the bot refuses to start while any remain).
3. Set `ATTACH_MODE=ui`, `BLAZE_URL`, `BLAZE_USER`, `BLAZE_PASS`. `docker compose up -d attach`.
4. Failures save a screenshot in the `attachdata` volume (`/data/ui_fail_<ID>.png`). Re-record steps after Blaze updates.

After `MAX_ATTACH_ATTEMPTS` failures a clip turns NEEDS_DESK, an alert fires, and the desk uses **Mark attached** or **Retry auto-attach**.

---
## PHASE 3. Hardening and shadow run
**3a. Alerts.** Set `ALERT_WEBHOOK_URL` (Teams or Slack incoming webhook) and/or `SMTP_*` + `ALERT_EMAIL_TO`; `docker compose up -d registry watcher`. Alerts fire when the gateway, watcher or attach engine stops reporting, when Blaze goes silent for `BLAZE_SILENT_SECS` (set 0 to disable), when the NAS/Nitro folder is unreachable, on every quarantine, and on NEEDS_DESK. The page shows a red banner for the same problems.

**3b. Monitoring.** `docker compose --profile monitoring up -d`, open `http://<vm>:3000` (user `admin`, password `GRAFANA_PASSWORD`), dashboard "Auto-ID Linker". Restrict port 3000 to IT.

**3c. Backups.** Nightly dump, optional copy to another machine, and a monthly restore proof:
```
chmod +x ops/*.sh && ./ops/backup.sh && ./ops/restore_test.sh
crontab -e   ->   30 2 * * * /opt/auto-id-linker/ops/backup.sh >> /var/log/autoid-backup.log 2>&1
```
Set `BACKUP_TARGET=user@otherhost:/srv/autoid` in `.env` (passwordless SSH key). Restore: stop the writers, `./ops/restore.sh backups/<file>`, `docker compose up -d`.

**3d. Standby VM.** Repeat Steps 1 to 5 on a second VM with the same `.env`, plus `PRIMARY_SSH=user@primary` and `PRIMARY_DIR`. On the standby run only `docker compose up -d db`, then cron `*/15 * * * * /opt/auto-id-linker/ops/standby_sync.sh`. Failover: `./ops/promote_standby.sh`, move the DNS name to the standby, and point Blaze's MOS device to it. Rehearse once.

**3e. Shadow run (about 4 weeks).** Set `ATTACH_MODE=shadow`. The system does everything except change Blaze and records what it would have attached. Each day:
```
docker compose exec registry python -m app.report --day 20261020 --out /tmp/day.csv
docker compose exec registry python -m app.report --day 20261020 --desk-csv desk.csv   # compare with the desk's own list (column "clip")
```
Fix every mismatch and every quarantine reason. Exit when a full week has no missed clips.

## PHASE 4. Cut-over, desk by desk
Set `CUTOVER_RUNDOWN_REGEX` to one rundown name (for example `Evening Bulletin`), set `ATTACH_MODE=mos` or `ui`, `docker compose up -d registry attach`. Only matching rundowns auto-attach; the rest keep working by hand. Widen the regex as confidence grows. Rollback in one minute: `ATTACH_MODE=desk`, restart attach (see `docs/RUNBOOK.md`).

## Reference
- **States:** WAITING_FOR_CLIP, EXPORTING, VERIFIED, ON_NITRO, ATTACH_SUBMITTED, ATTACHED, NEEDS_DESK, QUARANTINED. `ATTACH_SUBMITTED` = Blaze accepted the request (or the UI bot finished) but the result is unproven. It becomes `ATTACHED` only when (a) Blaze reports the clip in the right story (gateway read-back; a clip in the WRONG story goes to NEEDS_DESK with an alert), (b) the UI bot's `verify` steps find the clip in the reloaded story, or (c) the desk clicks **confirm attached**. An unconfirmed submission alerts after `ATTACH_CONFIRM_SECS`.
- **One worker per file:** before touching a file the watcher takes an atomic claim (a lock file created with `O_EXCL` in `LOCK_DIR`, default `Exports/.autoid-locks`). A second watcher, or an overlapping restart, skips a claimed file. The owner refreshes the lock every 5 s and aborts if it ever finds the claim taken. A lock is dead at once if its process is gone on the same host (or it is a leftover from before a container restart); otherwise after `LOCK_STALE_SECS` (default 120) without a refresh, measured on the watcher's own clock so NAS clock skew cannot matter. Copies go to a unique `.<name>.<claim>.part`, are hashed while copying, fsynced, re-hashed, and only then atomically renamed, so Nitro never sees a partial or unverified file. Stale `.part` files (no live owner and unchanged for `PART_STALE_SECS`, default 900) are removed every 5 minutes; nothing outside that naming pattern is ever deleted. `docker stop` unwinds cleanly; kill -9 or power loss is handled by the stale rules.
- **Registry acknowledgement is mandatory in the watcher:** the source file is archived only after the registry acknowledges ON_NITRO. If the registry is down the file stays in Exports (never quarantined for that reason), an alert fires, and the next poll re-reports and archives. For files already copied to Nitro by an older build run `docker compose exec watcher python reconcile_nitro.py` (dry run) then `--fix`.
- **ID format:** `YYYYMMDD_NNNNC_SLUG` (C = check letter, `CHECK_CHAR=0` turns it off). Versions add `_V2`. Matching uses only date and number (and the check letter if typed), so slug typos never stop a match. The day number resets at `BROADCAST_DAY_START`.
- **Fail-safe:** if anything here is down, Blaze, the NAS and Nitro work exactly as before. Nothing live depends on this system.
- **Tests:** `pip install pytest && pytest tests` (31 tests: IDs, check letter, broadcast day, filename matching, MOS parsing, password hashing, announce XML, registry-outage handling in the watcher, ACK semantics, read-back confirmation, per-file claims, stale locks, `.part` cleanup, kill -9 during a copy). The registry endpoints' new state logic needs a Postgres run to verify (not covered by these tests).
- **Honest limits:** not yet run against real Blaze, Nitro or Postgres. The `mosObj`/`mosObjCreate` field order and the Blaze MOS port come from the public MOS standard and need confirming in spike S4. Option A will not send until `MOS_PROTOCOL_VALIDATED=1`, which you set only after `docs/MOS_VALIDATION.md` (real traffic capture, `tools/mos_validate.py`, test rundown). Check the Blaze licence (E1) before using option A or B.

## Troubleshooting
| Symptom | Check |
|---|---|
| No IDs appear | `docker compose logs mos-gateway`; Blaze device host/ports; firewall 10540/10541; red `blaze_link` banner |
| File sits in Exports | Still within `STABLE_SECS`; or watcher log shows NAS unreachable (`nas_nitro` red) |
| Everything quarantines "not in the registry" | Wrong date in the filename, or ID typed from another broadcast day |
| Copy ID does nothing | Page is not on trusted HTTPS (check D4) |
| NEEDS_DESK on many clips | `docker compose logs attach`; Blaze changed screens (B) or rejects objects (A) |
| Login locked | 5 wrong passwords lock that name for 1 minute |
