"""Ingest watcher: polls the NAS Exports folder, waits until files are complete, validates with ffprobe,
matches the ID in the filename, copies to Nitro (checksum compared), archives the original,
quarantines anything unmatched or bad. Polling, not file events: events are unreliable on SMB shares."""
import hashlib, json, logging, os, re, shutil, signal, socket, subprocess, sys, time, urllib.error, urllib.request, uuid

REGISTRY = os.getenv("REGISTRY_URL", "http://registry:8000"); KEY = os.getenv("SERVICE_API_KEY", "")
EXPORTS, NITRO, QUAR, ARCH = (os.getenv(k, d) for k, d in
                              (("EXPORTS_DIR", "/exports"), ("NITRO_DIR", "/nitro"), ("QUARANTINE_DIR", "/quarantine"), ("ARCHIVE_DIR", "/archive")))
STABLE = int(os.getenv("STABLE_SECS", "30")); POLL = int(os.getenv("POLL_SECS", "5")); MAX_TRIES = int(os.getenv("MAX_TRIES", "5"))
RETAIN = int(os.getenv("ARCHIVE_RETAIN_DAYS", "14")); WEBHOOK = os.getenv("ALERT_WEBHOOK_URL", "")
EXTS = tuple(os.getenv("EXTS", ".mov,.mp4,.mxf").split(","))
NEED_PROBE = os.getenv("FFPROBE_REQUIRED", "1") == "1"
# Concurrency / crash safety. Lock dir must be on storage every watcher instance can see (default: inside Exports, dot-prefixed so it is ignored).
LOCK_DIR = os.getenv("LOCK_DIR", os.path.join(EXPORTS, ".autoid-locks"))
LOCK_STALE = int(os.getenv("LOCK_STALE_SECS", "120"))     # a lock whose file has not been refreshed for this long (by OUR clock) is dead
PART_STALE = int(os.getenv("PART_STALE_SECS", "900"))     # a .part file that has not changed for this long, with no live owner, is deleted
CLEAN_EVERY = int(os.getenv("CLEAN_EVERY_SECS", "300")); CHUNK = 1 << 20; REFRESH_EVERY = 5
HOST = socket.gethostname(); BUSY, DONE = "busy", "done"
_now = time.monotonic          # indirection so tests can move the clock; monotonic so NAS clock skew cannot matter
COPY_HOOK = None               # test seam: called after every copied chunk
log = logging.getLogger("watcher"); logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")

def parse_name(name: str):
    """ID rule: only date + number are used to match; slug typos cannot break it."""
    stem = os.path.splitext(name)[0]
    m = re.match(r"^(\d{8})_(\d{4})([A-Z])?(?:_|$)", stem)
    if not m: return None
    v = re.search(r"_V(\d+)$", stem)
    return m.group(1), int(m.group(2)), int(v.group(1)) if v else 1, m.group(3)

class LockLost(Exception):
    """Our claim on the file disappeared or was taken over mid-copy: stop immediately and leave the source untouched."""

MINE = set()                   # tokens of claims taken by THIS process life; a lock with our host+pid but another token is a leftover of a previous life
_OBS = {}                      # path -> (signature, first time seen with that signature): how long has it been unchanged, by our clock

def unchanged_for(key, sig):
    t = _now(); old = _OBS.get(key)
    if old is None or old[0] != sig: _OBS[key] = (sig, t); return 0.0
    return t - old[1]

def pid_alive(pid):
    try: os.kill(pid, 0); return True
    except ProcessLookupError: return False
    except PermissionError: return True
    except OSError: return True

def _read_lock(lp):
    try:
        with open(lp) as f: return json.load(f)
    except (OSError, ValueError): return {}          # missing, empty (creator is mid-write) or unreadable: judge by staleness only

def lock_is_dead(lp):
    """True if nobody is working under this lock. Same host: a dead pid (or our own pid with a token we never issued = previous life,
    e.g. after a container restart) is dead at once. Anything else: dead only after LOCK_STALE seconds with no refresh."""
    try: st = os.stat(lp)
    except FileNotFoundError: return True
    info = _read_lock(lp)
    if info.get("host") == HOST and isinstance(info.get("pid"), int):
        if info["pid"] == os.getpid():
            if info.get("token") not in MINE: return True
        elif not pid_alive(info["pid"]): return True
    return unchanged_for(lp, (st.st_mtime, st.st_size)) >= LOCK_STALE

class Claim:
    def __init__(self, path, token): self.path, self.token, self._last = path, token, _now()
    def refresh(self, force=False):
        """Heartbeat the lock (mtime) and make sure it is still ours. Raises LockLost if not."""
        if not force and _now() - self._last < REFRESH_EVERY: return
        if _read_lock(self.path).get("token") != self.token: raise LockLost("claim on %s was lost" % os.path.basename(self.path))
        os.utime(self.path, None); self._last = _now()
    def release(self):
        MINE.discard(self.token)
        if _read_lock(self.path).get("token") == self.token:      # never delete somebody else's lock
            try: os.unlink(self.path)
            except FileNotFoundError: pass

def _break_lock(lp):
    """Remove a lock judged dead. rename is atomic, so of several workers breaking the same lock exactly one wins."""
    try: before = os.stat(lp)
    except FileNotFoundError: return
    grave = "%s.stale.%s" % (lp, uuid.uuid4().hex[:8])
    try: os.rename(lp, grave)
    except FileNotFoundError: return                              # someone else broke it first
    try: after = os.stat(grave)
    except FileNotFoundError: return
    if (after.st_mtime, after.st_size) != (before.st_mtime, before.st_size):    # it was refreshed meanwhile: we grabbed a LIVE lock, put it back
        try: os.link(grave, lp)
        except OSError: pass
    try: os.unlink(grave)
    except FileNotFoundError: pass

def acquire(name):
    """Atomic claim on a source file name: O_CREAT|O_EXCL create of a lock file. Returns a Claim or None if someone else holds it."""
    os.makedirs(LOCK_DIR, exist_ok=True); lp = os.path.join(LOCK_DIR, name + ".lock"); token = uuid.uuid4().hex
    for _ in range(3):
        try: fd = os.open(lp, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
        except FileExistsError:
            if not lock_is_dead(lp): return None
            log.warning("breaking dead lock on %s", name); _break_lock(lp); continue
        with os.fdopen(fd, "w") as f:
            json.dump({"host": HOST, "pid": os.getpid(), "token": token, "started": time.time()}, f); f.flush(); os.fsync(f.fileno())
        MINE.add(token); return Claim(lp, token)
    return None

PART_RE = re.compile(r"^\.(?P<name>.+?)(?:\.(?P<tok>[0-9a-f]{32}))?\.part$")    # .<name>.<token>.part  (or legacy .<name>.part)

def clean_stale():
    """Delete leftovers of crashed copies. A .part file goes only if (a) it has not changed for PART_STALE seconds AND (b) no live claim
    owns it. Locks of crashed workers whose source is gone are removed too. Nothing that does not match our own naming is ever touched."""
    n = 0
    for f in os.listdir(NITRO) if os.path.isdir(NITRO) else []:
        m = PART_RE.match(f); p = os.path.join(NITRO, f)
        if not m or not os.path.isfile(p) or os.path.islink(p): continue
        try: st = os.stat(p)
        except FileNotFoundError: continue
        lp = os.path.join(LOCK_DIR, m["name"] + ".lock")
        if os.path.exists(lp) and not lock_is_dead(lp) and (m["tok"] is None or _read_lock(lp).get("token") == m["tok"]): continue
        if unchanged_for(p, (st.st_mtime, st.st_size)) >= PART_STALE:
            try: os.remove(p); n += 1; log.warning("removed stale partial copy %s", f)
            except OSError as e: log.warning("could not remove %s: %s", f, e)
    for f in os.listdir(LOCK_DIR) if os.path.isdir(LOCK_DIR) else []:
        p = os.path.join(LOCK_DIR, f)
        if ".stale." in f and unchanged_for(p, 0) >= LOCK_STALE:
            try: os.remove(p)
            except OSError: pass
        elif f.endswith(".lock") and not os.path.exists(os.path.join(EXPORTS, f[:-5])) and lock_is_dead(p):
            try: os.remove(p); n += 1
            except OSError: pass
    for k in [k for k in _OBS if not os.path.exists(k)]: _OBS.pop(k, None)
    return n

def sha256(path, tick=None):
    h = hashlib.sha256(); last = _now()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(CHUNK), b""):
            h.update(b)
            if tick and _now() - last >= REFRESH_EVERY: tick(); last = _now()
    return h.hexdigest()

def copy_hashing(src, dst, tick):
    """Copy src to dst in one pass, hashing what was read, fsync before returning. Refreshes the claim while it works."""
    h = hashlib.sha256()
    with open(src, "rb") as i, open(dst, "wb") as o:
        for b in iter(lambda: i.read(CHUNK), b""):
            h.update(b); o.write(b); tick()
            if COPY_HOOK: COPY_HOOK(len(b))
        o.flush(); os.fsync(o.fileno())
    return h.hexdigest()

def api(path, payload=None):
    req = urllib.request.Request(REGISTRY + path, method="POST" if payload is not None else "GET",
                                 headers={"Content-Type": "application/json", "X-API-Key": KEY},
                                 data=json.dumps(payload).encode() if payload is not None else None)
    with urllib.request.urlopen(req, timeout=10) as r: return json.loads(r.read())

def alert(text):
    log.warning("ALERT %s", text)
    if WEBHOOK:
        try: urllib.request.urlopen(urllib.request.Request(WEBHOOK, data=json.dumps({"text": "Auto-ID: " + text}).encode(),
                                    headers={"Content-Type": "application/json"}), timeout=10)
        except Exception as e: log.warning("webhook failed: %s", e)

class RegistryUnavailable(Exception):
    """Registry could not be reached or answered 5xx. Transient: wait and retry, never count against the file."""

def report(did, state, required=False, **kw):
    """required=True: the registry MUST acknowledge, or this raises and the caller stops (the source file is not archived).
    required=False: best effort, used only for QUARANTINED where the file has already been moved aside."""
    if not did: return
    try: api("/svc/files", {"display_id": did, "state": state, **kw})
    except urllib.error.HTTPError as e:
        if e.code >= 500 and required: raise RegistryUnavailable("registry error %d while reporting %s" % (e.code, state))
        if required: raise
        log.warning("report %s failed: %s", state, e)
    except (urllib.error.URLError, OSError, ValueError) as e:
        if required: raise RegistryUnavailable("registry unreachable while reporting %s: %s" % (state, e))
        log.warning("report %s failed: %s", state, e)

def quarantine(path, reason, did=None):
    os.makedirs(QUAR, exist_ok=True)
    dest = os.path.join(QUAR, os.path.basename(path))
    if os.path.exists(dest): dest = "%s.%d" % (dest, int(time.time()))
    shutil.move(path, dest)
    with open(dest + ".reason.txt", "w") as f: f.write(reason + "\n")
    report(did, "QUARANTINED", nas_path=dest, error=reason)   # best effort: the file is already moved aside and the alert below fires
    alert("%s quarantined: %s" % (os.path.basename(path), reason))

def probe(path):
    """-> (ok, error_text, duration_seconds)"""
    try:
        out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json", path],
                             capture_output=True, text=True, timeout=120)
        dur = float(json.loads(out.stdout)["format"]["duration"]) if out.returncode == 0 else 0.0
        return out.returncode == 0 and dur > 0, out.stderr.strip()[:200], dur
    except Exception as e: return False, str(e), 0.0

def process(path):
    """Claim the file, process it, release the claim. Returns BUSY if another worker holds it, DONE if it is already gone."""
    name = os.path.basename(path); claim = acquire(name)
    if claim is None: log.info("%s is being processed by another worker, skipping", name); return BUSY
    try:
        if not os.path.exists(path): return DONE          # another worker finished between our listing and our claim
        _process(path, claim); return None
    finally: claim.release()

def _process(path, claim):
    name = os.path.basename(path); key = parse_name(name)
    if not key: return quarantine(path, "no ID at start of filename (expected YYYYMMDD_NNNN_...)")
    try: clip = api("/svc/match?day=%s&seq=%d&version=%d" % key[:3] + ("&chk=" + key[3] if key[3] else ""))
    except urllib.error.HTTPError as e:
        if e.code == 404: return quarantine(path, "ID %s_%04d is not in the registry" % key[:2])
        if e.code == 422: return quarantine(path, "check character does not match: ID was mistyped")
        raise
    did = clip["display_id"]
    dur = None
    if NEED_PROBE:
        ok, err, dur = probe(path)
        if not ok: return quarantine(path, "ffprobe rejected the file: " + err, did)
    src_hash = sha256(path, claim.refresh); size = os.path.getsize(path)
    report(did, "VERIFIED", required=True, nas_path=path, size=size, sha256=src_hash)
    dest = os.path.join(NITRO, name)
    if os.path.exists(dest):                      # idempotent: only ever created by the atomic replace below, so a mismatch is a genuinely different file
        if sha256(dest, claim.refresh) != src_hash: return quarantine(path, "a different file with this name is already on Nitro", did)
    else:
        tmp = os.path.join(NITRO, ".%s.%s.part" % (name, claim.token))    # unique per claim: two workers can never write the same partial file
        try:
            if copy_hashing(path, tmp, claim.refresh) != src_hash: raise IOError("source file changed while it was being copied")
            if sha256(tmp, claim.refresh) != src_hash: raise IOError("checksum mismatch after copy")   # verified BEFORE it gets its real name
            claim.refresh(force=True)                                      # still ours? (raises LockLost if not)
            os.replace(tmp, dest)                                          # atomic: Nitro never sees a half-written or unverified file
        except BaseException:                                              # includes LockLost and SIGTERM (SystemExit): leave no partial behind
            try: os.remove(tmp)
            except OSError: pass
            raise
    # The registry must acknowledge ON_NITRO BEFORE the source is archived. If it cannot, this raises, the source stays in
    # Exports, and the next poll finds the identical file already on Nitro (idempotent branch above), re-reports and archives.
    report(did, "ON_NITRO", required=True, nas_path=path, nitro_path=dest, size=size, sha256=src_hash, duration_s=dur)
    os.makedirs(ARCH, exist_ok=True)
    try: shutil.move(path, os.path.join(ARCH, "%d_%s" % (int(time.time()), name)))
    except FileNotFoundError:
        if os.path.exists(path): raise                                      # source vanished = another worker already archived it: fine
    log.info("%s -> Nitro (registry acknowledged)", name)

def purge_archive():
    cut = time.time() - RETAIN * 86400
    for f in os.listdir(ARCH) if os.path.isdir(ARCH) else []:
        p = os.path.join(ARCH, f)
        if os.path.isfile(p) and os.path.getmtime(p) < cut: os.remove(p)

_ALERTED = {}
def alert_once(key, text, every=900):
    if time.time() - _ALERTED.get(key, 0) > every: _ALERTED[key] = time.time(); alert(text)

def beat(nas_ok):
    try: api("/svc/heartbeat", {"component": "watcher", "detail": {"nas_ok": nas_ok}})
    except Exception as e: log.warning("heartbeat failed: %s", e)

def main():
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))      # docker stop: unwind, so claims are released and partial copies removed
    seen, tries, last_purge, last_beat, last_clean = {}, {}, 0, 0, 0
    while True:
        if time.time() - last_clean > CLEAN_EVERY:
            try: clean_stale()
            except Exception as e: log.warning("stale cleanup failed: %s", e)
            last_clean = time.time()
        if time.time() - last_beat > 30:
            beat(os.path.isdir(EXPORTS) and os.path.isdir(NITRO) and os.access(NITRO, os.W_OK)); last_beat = time.time()
        try:
            names = [n for n in os.listdir(EXPORTS) if n.lower().endswith(EXTS) and not n.startswith(".")]
            for n in names:
                p = os.path.join(EXPORTS, n)
                try: st = os.stat(p)
                except FileNotFoundError: continue
                sig = (st.st_size, st.st_mtime)
                if seen.get(p, (None,))[0] != sig: seen[p] = (sig, time.time()); continue
                marker = os.path.exists(p + ".done")
                if not marker and time.time() - seen[p][1] < STABLE: continue   # still being written
                try:
                    if process(p) == BUSY: continue                 # someone else has it: look again next poll, no retry counted
                    seen.pop(p, None); tries.pop(p, None)
                    if marker and os.path.exists(p + ".done"): os.remove(p + ".done")
                except RegistryUnavailable as e:        # registry outage is not the file's fault: keep waiting, never quarantine
                    log.warning("%s waiting for registry: %s", n, e); alert_once("registry", "registry unavailable, files are waiting in Exports: %s" % e)
                except Exception as e:                  # transient: retry next poll, then give up
                    tries[p] = tries.get(p, 0) + 1; log.warning("%s attempt %d failed: %s", n, tries[p], e)
                    if tries[p] >= MAX_TRIES and os.path.exists(p): quarantine(p, "gave up after %d tries: %s" % (MAX_TRIES, e))
            for p in [p for p in seen if not os.path.exists(p)]: seen.pop(p, None)
        except Exception as e: log.error("poll error (NAS down?): %s", e)
        if time.time() - last_purge > 3600:
            try: purge_archive()
            except Exception: pass
            last_purge = time.time()
        time.sleep(POLL)

if __name__ == "__main__": main()
