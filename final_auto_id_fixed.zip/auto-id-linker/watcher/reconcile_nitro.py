#!/usr/bin/env python3
"""Recovery: find clips whose file is already on Nitro but whose registry state never reached ON_NITRO
(registry was down, or the old watcher swallowed the error). Dry run by default; --fix records them.
Run inside the watcher container:  docker compose exec watcher python reconcile_nitro.py [--fix]
Safe to repeat. It never moves, copies or deletes any file; it only tells the registry what is already true.
A file is only recorded if its sha256 matches an archived/exports copy OR you pass --trust-nitro (then ffprobe must pass)."""
import argparse, os, sys, urllib.error
import watcher as w

def find_source(name):
    """Original copy (Exports, or Archive as '<epoch>_<name>') to compare checksums against."""
    cands = [os.path.join(w.EXPORTS, name)]
    if os.path.isdir(w.ARCH): cands += [os.path.join(w.ARCH, f) for f in os.listdir(w.ARCH) if f.endswith("_" + name)]
    return [c for c in cands if os.path.isfile(c)]

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--fix", action="store_true"); ap.add_argument("--trust-nitro", action="store_true"); a = ap.parse_args()
    todo = skipped = 0
    for name in sorted(os.listdir(w.NITRO)):
        if name.startswith(".") or not name.lower().endswith(w.EXTS): continue
        key = w.parse_name(name)
        if not key: continue
        try: clip = w.api("/svc/match?day=%s&seq=%d&version=%d" % key[:3] + ("&chk=" + key[3] if key[3] else ""))
        except urllib.error.HTTPError: continue
        if clip["state"] not in ("WAITING_FOR_CLIP", "EXPORTING", "VERIFIED"): continue       # already ON_NITRO / ATTACHED / etc.
        dest = os.path.join(w.NITRO, name); h = w.sha256(dest); size = os.path.getsize(dest)
        srcs = find_source(name); matched = [s for s in srcs if w.sha256(s) == h]
        if not matched and not a.trust_nitro:
            print("SKIP  %s: no source copy with the same checksum (use --trust-nitro after checking the file)" % name); skipped += 1; continue
        ok, err, dur = w.probe(dest)
        if not ok: print("SKIP  %s: ffprobe rejected: %s" % (name, err)); skipped += 1; continue
        todo += 1
        print("%s %s (state %s, sha256 %s..., %.1fs)" % ("FIX " if a.fix else "WOULD FIX", name, clip["state"], h[:10], dur))
        if a.fix: w.report(clip["display_id"], "ON_NITRO", required=True, nas_path=matched[0] if matched else None, nitro_path=dest, size=size, sha256=h, duration_s=dur)
    print("%d to fix, %d skipped%s" % (todo, skipped, "" if a.fix else "  (dry run; add --fix)")); return 0

if __name__ == "__main__": sys.exit(main())
