"""Minimal MOS device. Listens on both MOS ports, answers heartbeats / machine-info / run-order
messages with acks, and sends story IDs to the registry. Raw traffic is logged to /data/mos_capture.log
(use it for checks A3/A4). To use Sofie's mos-connection instead, keep the same registry calls."""
import asyncio, codecs, datetime, json, logging, os, re, time, urllib.request
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

REGISTRY = os.getenv("REGISTRY_URL", "http://registry:8000")
KEY = os.getenv("SERVICE_API_KEY", "")
DATA = os.getenv("DATA_DIR", "/data")
PORTS = [int(p) for p in os.getenv("MOS_PORTS", "10540,10541").split(",")]
log = logging.getLogger("mos"); logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
HEADER = {"mosID", "ncsID", "messageID"}
ACK_ONLY = {"roStoryInsert", "roStoryReplace", "roStoryAppend", "roStoryDelete", "roStoryMove", "roStorySwap", "roStorySend",
            "roItemInsert", "roItemReplace", "roItemDelete", "roItemMoveMultiple", "roReadyToAir", "roElementAction",
            "roMetadataReplace", "roDelete", "roCreate", "roReplace", "roStatus", "roItemStatus", "roStoryStatus"}

def t(el, tag, default=""):
    x = el.find(tag)
    return (x.text or "").strip() if x is not None and x.text else default

def parse_mos(xml: str):
    root = ET.fromstring(xml)
    hdr = {k: t(root, k) for k in HEADER}
    body = next((c for c in root if c.tag not in HEADER), None)
    return hdr, body

def reply(hdr, inner: str) -> str:
    return ("<mos><mosID>%s</mosID><ncsID>%s</ncsID><messageID>%s</messageID>%s</mos>"
            % (escape(hdr["mosID"]), escape(hdr["ncsID"]), escape(hdr["messageID"]), inner))

def ro_ack(ro_id, status="OK"):
    return "<roAck><roID>%s</roID><roStatus>%s</roStatus></roAck>" % (escape(ro_id), status)

def machine_info(hdr):
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
    return ("<listMachInfo><manufacturer>Auto-ID</manufacturer><model>Linker</model><hwRev>0</hwRev><swRev>1.0</swRev>"
            "<DOM>2026-01-01</DOM><SN>1</SN><ID>%s</ID><time>%s</time><opTime>%s</opTime><mosRev>2.8.3</mosRev>"
            "<supportedProfiles deviceType=\"MOS\"><mosProfile number=\"0\">YES</mosProfile><mosProfile number=\"1\">YES</mosProfile>"
            "<mosProfile number=\"2\">YES</mosProfile><mosProfile number=\"3\">NO</mosProfile><mosProfile number=\"4\">YES</mosProfile>"
            "<mosProfile number=\"5\">NO</mosProfile></supportedProfiles></listMachInfo>") % (escape(hdr["mosID"]), now, now)

def call(path, payload=None, method="POST"):
    req = urllib.request.Request(REGISTRY + path, method=method, headers={"Content-Type": "application/json", "X-API-Key": KEY},
                                 data=json.dumps(payload).encode() if payload is not None else None)
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())

def actions_for(body):
    """Translate a run-order message into registry calls: [(path, payload)]."""
    tag = body.tag; ro = t(body, "roID"); out = []
    if tag in ("roCreate", "roReplace"):
        name = t(body, "roSlug")
        for s in body.findall("story"):
            out.append(("/svc/stories", {"blaze_rundown_id": ro, "rundown_name": name, "blaze_story_id": t(s, "storyID"), "slug": t(s, "storySlug")}))
    elif tag in ("roStoryInsert", "roStoryAppend"):
        for s in body.findall("story"):
            out.append(("/svc/stories", {"blaze_rundown_id": ro, "blaze_story_id": t(s, "storyID"), "slug": t(s, "storySlug")}))
    elif tag == "roStoryReplace":
        old = t(body, "storyID")
        for s in body.findall("story"):
            new = t(s, "storyID")
            if old and new and old != new:
                out.append(("/svc/stories/rename", {"blaze_rundown_id": ro, "old_id": old, "new_id": new}))
            out.append(("/svc/stories", {"blaze_rundown_id": ro, "blaze_story_id": new, "slug": t(s, "storySlug")}))
    elif tag == "roStoryDelete":
        for s in body.findall("storyID"):
            out.append(("/svc/stories/delete", {"blaze_rundown_id": ro, "blaze_story_id": (s.text or "").strip()}))
    elif tag == "roDelete":
        out.append(("/svc/stories/delete", {"blaze_rundown_id": ro}))
    return out

ID_RE = re.compile(r"^\d{8}_\d{4}[A-Z]?(?:_|$)")

def confirmations(body):
    """Read-back: Blaze tells us which objects sit in which story (items carry an objID). Our clip IDs start with YYYYMMDD_NNNN, so
    any item whose objID looks like one is a confirmation that THAT clip is in THAT story. Returns registry calls."""
    ro = t(body, "roID"); out = []
    def add(story_id, item):
        oid = t(item, "objID")
        if story_id and oid and ID_RE.match(oid):
            out.append(("/svc/attach/confirm", {"display_id": oid, "blaze_rundown_id": ro, "blaze_story_id": story_id, "source": "mos_item"}))
    for s in body.findall("story"):
        for it in s.findall("item"): add(t(s, "storyID"), it)
    for it in body.findall("item"): add(t(body, "storyID"), it)      # roItemInsert / roItemReplace carry storyID + item at top level
    return out

START = time.time(); LAST_MOS = [None]
SPOOL = os.path.join(DATA, "spool.jsonl")

def spool(path, payload):
    with open(SPOOL, "a") as f: f.write(json.dumps([path, payload]) + "\n")

def replay_spool():
    """Registry was down: retry stored calls in order. Safe because the calls are idempotent."""
    if not os.path.exists(SPOOL): return
    items = [json.loads(l) for l in open(SPOOL) if l.strip()]
    os.remove(SPOOL)
    for i, (p, d) in enumerate(items):
        try: call(p, d)
        except Exception:
            for rest in items[i:]: spool(*rest)
            return

def handle(xml: str) -> str:
    LAST_MOS[0] = time.time()
    hdr, body = parse_mos(xml)
    if body is None: return ""
    tag = body.tag
    if tag == "heartbeat":
        return reply(hdr, "<heartbeat><time>%s</time></heartbeat>" % datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S"))
    if tag == "reqMachInfo": return reply(hdr, machine_info(hdr))
    for path, payload in actions_for(body) + confirmations(body):
        try: call(path, payload)
        except Exception as e:
            log.warning("registry call failed (%s), spooled: %s", path, e); spool(path, payload)
    if tag in ACK_ONLY: return reply(hdr, ro_ack(t(body, "roID")))
    log.info("unhandled MOS message: %s", tag)
    return ""

async def client(reader, writer):
    peer = writer.get_extra_info("peername"); log.info("connect %s", peer)
    dec = codecs.getincrementaldecoder("utf-16-be")(errors="replace"); buf = ""
    try:
        while data := await reader.read(65536):
            buf += dec.decode(data)
            while "</mos>" in buf:
                msg, buf = buf.split("</mos>", 1); msg = msg.strip() + "</mos>"
                with open(os.path.join(DATA, "mos_capture.log"), "a", encoding="utf-8") as f:
                    f.write("[%s] %s\n%s\n\n" % (datetime.datetime.now().isoformat(timespec="seconds"), peer, msg))
                try: resp = await asyncio.to_thread(handle, msg)
                except ET.ParseError as e: log.warning("bad XML: %s", e); continue
                if resp:
                    writer.write(resp.encode("utf-16-be")); await writer.drain()
    finally:
        log.info("disconnect %s", peer); writer.close()

async def main():
    os.makedirs(DATA, exist_ok=True)
    servers = [await asyncio.start_server(client, "0.0.0.0", p) for p in PORTS]
    log.info("listening on %s", PORTS)
    async def replayer():
        while True:
            await asyncio.sleep(15); await asyncio.to_thread(replay_spool)
    async def beat():
        while True:
            d = {"last_mos_age": None if LAST_MOS[0] is None else time.time() - LAST_MOS[0], "uptime": time.time() - START}
            try: await asyncio.to_thread(call, "/svc/heartbeat", {"component": "gateway", "detail": d})
            except Exception as e: log.warning("heartbeat failed: %s", e)
            await asyncio.sleep(30)
    await asyncio.gather(replayer(), beat(), *[s.serve_forever() for s in servers])

if __name__ == "__main__":
    asyncio.run(main())
