#!/bin/sh
# Dev only. In production use an internal CA cert the Macs trust (check D4).
openssl req -x509 -newkey rsa:2048 -nodes -days 365 -keyout server.key -out server.crt -subj "/CN=${1:-autoid.local}" -addext "subjectAltName=DNS:${1:-autoid.local}"
