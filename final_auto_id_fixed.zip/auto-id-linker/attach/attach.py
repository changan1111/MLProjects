"""Attach Engine (Phase 2). ATTACH_MODE = desk | shadow | mos | ui
  desk   - do nothing; the desk clicks 'Mark attached' (option C, always-safe fallback)
  shadow - log what would be done, touch nothing in Blaze (Phase 3 shadow run)
  mos    - option A: announce the clip to Blaze as a MOS media object. Blaze ACCEPTING it is not proof it is attached: the clip
           goes to ATTACH_SUBMITTED and only becomes ATTACHED when Blaze reports the item in the right story (gateway) or the desk confirms.
           Refuses to run until MOS_PROTOCOL_VALIDATED=1 (see docs/MOS_VALIDATION.md)
  ui     - option B: Playwright bot clicks through Blaze using steps in ui_steps.json. ATTACHED only if a "verify" block reloads the
           story and finds the clip; without one the clip stays ATTACH_SUBMITTED for the desk to confirm
Test option A without the loop:  python attach.py --test-announce"""
import argparse, datetime, json, logging, os, socket, time, urllib.request
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

REGISTRY = os.getenv("REGISTRY_URL", "http://registry:8000"); KEY = os.getenv("SERVICE_API_KEY", "")
MODE = os.getenv("ATTACH_MODE", "desk"); POLL = int(os.getenv("POLL_SECS", "10"))
BLAZE_HOST = os.getenv("BLAZE_HOST", ""); BLAZE_MOS_PORT = int(os.getenv("BLAZE_MOS_PORT", "10540"))
MOS_ID = os.getenv("MOS_ID", "AUTOID.LINKER.MOS"); NCS_ID = os.getenv("NCS_ID", "BLAZE.NCS")
ANNOUNCE = os.getenv("MOS_ANNOUNCE_MSG", "mosObj")      # or mosObjCreate: decided by spike S4
VALIDATED = os.getenv("MOS_PROTOCOL_VALIDATED", "0") == "1"; DATA = os.getenv("DATA_DIR", "/data")
FPS = int(os.getenv("FPS", "25")); STEPS_FILE = os.getenv("UI_STEPS_FILE", "/config/ui_steps.json")
log = logging.getLogger("attach"); logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")

def api(path, payload=None):
    req = urllib.request.Request(REGISTRY + path, method="POST" if payload is not None else "GET",
                                 headers={"Content-Type": "application/json", "X-API-Key": KEY},
                                 data=json.dumps(payload).encode() if payload is not None else None)
    with urllib.request.urlopen(req, timeout=10) as r: return json.loads(r.read())

# ---------- option A: MOS announce ----------
def build_announce(clip, msg_id, msg=None):
    msg = msg or ANNOUNCE; now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
    dur = int((clip.get("duration_s") or 0) * FPS); did = escape(clip["display_id"])
    body = ("<objSlug>%s</objSlug><objGroup></objGroup><objType>VIDEO</objType><objTB>%d</objTB><objRev>%d</objRev><objDur>%d</objDur>"
            "<status>NEW</status><objAir>READY</objAir><createdBy>AUTOID</createdBy><created>%s</created><changedBy>AUTOID</changedBy><changed>%s</changed>"
            "<description>%s</description><objPaths><objPath techDescription=\"Nitro\">%s</objPath></objPaths>"
            "<mosExternalMetadata><mosScope>PLAYLIST</mosScope><mosSchema>https://autoid.local/schema</mosSchema>"
            "<mosPayload><clipID>%s</clipID><storyID>%s</storyID></mosPayload></mosExternalMetadata>") % (
        did if msg == "mosObjCreate" else escape(clip.get("slug") or ""), FPS, clip.get("version", 1), dur, now, now,
        escape(clip.get("slug") or ""), escape(clip.get("nitro_path") or ""), did, escape(clip.get("blaze_story_id") or ""))
    if msg == "mosObj": body = "<objID>%s</objID>" % did + body
    return "<mos><mosID>%s</mosID><ncsID>%s</ncsID><messageID>%d</messageID><%s>%s</%s></mos>" % (escape(MOS_ID), escape(NCS_ID), msg_id, msg, body, msg)

def capture(direction, text):
    """Raw copy of every MOS message we send/receive, for protocol validation (tools/mos_validate.py)."""
    try:
        with open(os.path.join(DATA, "mos_attach_capture.log"), "a", encoding="utf-8") as f:
            f.write("[%s] %s\n%s\n\n" % (datetime.datetime.now().isoformat(timespec="seconds"), direction, text))
    except OSError: pass

def send_mos(xml, host=None, port=None, expect_obj=None):
    """Send one MOS message to Blaze, return (ok, detail). ok means Blaze ACCEPTED the message, nothing more.
    If expect_obj is given, the ack must also name that object (a generic ACK for something else is a failure)."""
    capture("SEND", xml)
    with socket.create_connection((host or BLAZE_HOST, port or BLAZE_MOS_PORT), timeout=10) as s:
        s.sendall(xml.encode("utf-16-be")); data = b""; s.settimeout(10)
        try:
            while not data.decode("utf-16-be", "ignore").rstrip().endswith("</mos>"):
                chunk = s.recv(65536)
                if not chunk: break
                data += chunk
        except socket.timeout: return False, "no reply from Blaze within 10 s"
    text = data.decode("utf-16-be", "ignore"); capture("RECV", text)
    try:
        ack = ET.fromstring(text).find("mosAck")
        if ack is None: return False, "unexpected reply: " + text[:200]
        st = (ack.findtext("status") or "").strip(); detail = "%s %s" % (st, ack.findtext("statusDescription") or "")
        if st != "ACK": return False, detail
        got = (ack.findtext("objID") or "").strip()
        if expect_obj and got and got != expect_obj: return False, "ACK names a different object (%s, expected %s)" % (got, expect_obj)
        return True, detail
    except ET.ParseError: return False, "unreadable reply: " + text[:200]

def attach_mos(clip):
    """-> (ok, detail, confirmed). confirmed is always False here: a mosAck proves acceptance only. The gateway confirms later
    if Blaze reports the item in the story; otherwise the desk does."""
    if not BLAZE_HOST: raise RuntimeError("BLAZE_HOST not set")
    if not VALIDATED: raise RuntimeError("MOS_PROTOCOL_VALIDATED is not 1: complete docs/MOS_VALIDATION.md against a test Blaze first")
    ok, detail = send_mos(build_announce(clip, int(time.time()) % 2_000_000_000), expect_obj=clip["display_id"])
    return ok, detail, False

# ---------- option B: UI bot ----------
class UiBot:
    def __init__(self):
        self.cfg = json.load(open(STEPS_FILE)); self.pw = self.page = self.browser = None
        if "CHANGE_ME" in json.dumps(self.cfg): raise RuntimeError("ui_steps.json still contains CHANGE_ME selectors: record them first (see README Phase 2B)")
    def render(self, v, ctx):
        env = {"BLAZE_URL": os.getenv("BLAZE_URL", ""), "BLAZE_USER": os.getenv("BLAZE_USER", ""), "BLAZE_PASS": os.getenv("BLAZE_PASS", "")}
        for k, val in {**env, **ctx}.items(): v = v.replace("{%s}" % k, str(val or ""))
        return v
    def start(self):
        from playwright.sync_api import sync_playwright
        self.pw = sync_playwright().start(); self.browser = self.pw.chromium.launch(headless=True)
        self.page = self.browser.new_context(ignore_https_errors=os.getenv("BLAZE_IGNORE_TLS") == "1").new_page(); self.page.set_default_timeout(15000)
        self.run(self.cfg["login"], {})
    def run(self, steps, ctx):
        p = self.page
        for s in steps:
            a = s["do"]; sel = self.render(s.get("selector", ""), ctx); val = self.render(s.get("value", ""), ctx)
            if a == "goto": p.goto(self.render(s["url"], ctx))
            elif a == "fill": p.fill(sel, val)
            elif a == "click": p.click(sel)
            elif a == "press": p.press(sel, val)
            elif a == "select": p.select_option(sel, val)
            elif a == "wait_for": p.wait_for_selector(sel)
            elif a == "expect_text": p.wait_for_selector("%s:has-text(\"%s\")" % (sel, val))
            elif a == "wait_ms": p.wait_for_timeout(int(s["ms"]))
            else: raise ValueError("unknown step " + a)
    def close(self):
        try: self.browser.close(); self.pw.stop()
        except Exception: pass
        self.pw = self.page = self.browser = None
    def attach(self, clip):
        """-> (ok, detail, confirmed). The attach clicks finishing is not proof. confirmed is True only if the optional "verify" steps
        (reopen the story, expect_text on the clip ID) pass. No "verify" block = the desk must confirm."""
        if not self.page: self.start()
        try:
            self.run(self.cfg["attach"], clip)
            if not self.cfg.get("verify"): return True, "ui steps completed, NOT verified (no verify block)", False
            self.run(self.cfg["verify"], clip); return True, "ui attach verified in story", True
        except Exception as e:
            try: self.page.screenshot(path="/data/ui_fail_%s.png" % clip["display_id"])
            except Exception: pass
            self.close(); raise

def main():
    bot = UiBot() if MODE == "ui" else None; last_beat = 0
    log.info("attach engine mode=%s", MODE)
    while True:
        if time.time() - last_beat > 30:
            try: api("/svc/heartbeat", {"component": "attach", "detail": {"mode": MODE}})
            except Exception as e: log.warning("heartbeat failed: %s", e)
            last_beat = time.time()
        try: pending = [] if MODE == "desk" else api("/svc/attach/pending?limit=5")
        except Exception as e: log.warning("registry unreachable: %s", e); pending = []
        for clip in pending:
            did = clip["display_id"]
            try:
                if MODE == "shadow": ok, detail, confirmed = True, "shadow: would attach", False
                elif MODE == "mos": ok, detail, confirmed = attach_mos(clip)
                elif MODE == "ui": ok, detail, confirmed = bot.attach(clip)
                else: ok, detail, confirmed = False, "bad ATTACH_MODE", False
            except Exception as e: ok, detail, confirmed = False, str(e)[:300], False
            log.info("%s -> %s (%s)", did, ("CONFIRMED" if confirmed else "SUBMITTED, awaiting confirmation") if ok else "FAIL", detail)
            try: api("/svc/attach/result", {"display_id": did, "ok": ok, "method": MODE, "error": None if ok else detail, "shadow": MODE == "shadow", "confirmed": confirmed})
            except Exception as e: log.warning("result not saved: %s", e)
        time.sleep(POLL)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--test-announce", action="store_true"); ap.add_argument("--print-only", action="store_true"); a = ap.parse_args()
    if a.test_announce:
        clip = {"display_id": "20990101_0001A_TEST_OBJECT", "slug": "Test object", "version": 1, "duration_s": 5, "nitro_path": "/test/20990101_0001A_TEST_OBJECT.mov", "blaze_story_id": "TEST"}
        x = build_announce(clip, 1); print(x)
        if not a.print_only: print(send_mos(x, expect_obj=clip["display_id"]), "(ACK = accepted only; check the object in Blaze, then see docs/MOS_VALIDATION.md)")
    else: main()
