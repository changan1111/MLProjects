const { contextBridge, ipcRenderer } = require('electron');

// What the ClipStage page may ask the desktop app to do. Every handler in main.js re-checks that the
// request comes from the ClipStage server page.
contextBridge.exposeInMainWorld('clipstageNative', {
  version: 7,
  platform: process.platform,
  startDragPaths: (paths) => ipcRenderer.send('clipstage-start-drag-paths', paths),   // host paths -> real files on THIS computer
  checkClips: (items) => ipcRenderer.invoke('clipstage-check', items),                // [{id, path}] -> [{id, state, reason}]
  localPath: (hostPath) => ipcRenderer.invoke('clipstage-local-path', hostPath),
  pathMapStatus: (hostVols) => ipcRenderer.invoke('clipstage-pm-status', hostVols),
  pathMapConfirm: (hostVol, localRoot) => ipcRenderer.invoke('clipstage-pm-confirm', hostVol, localRoot),
  pathMapChoose: (hostVol) => ipcRenderer.invoke('clipstage-pm-choose', hostVol),
  pathMapForget: (hostVol) => ipcRenderer.invoke('clipstage-pm-forget', hostVol),
  syncLocal: (editor, clips) => ipcRenderer.invoke('clipstage-sync-local', editor, clips),   // optional, off by default
  openLocal: (editor) => ipcRenderer.send('clipstage-open-local', editor),
});
