const { app, BrowserWindow, ipcMain, nativeImage, shell, dialog } = require('electron');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { PathMap, checkLocal, parseHostPath } = require('./pathmap');

const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));
const IS_WIN = process.platform === 'win32';
const SERVER_ORIGIN = new URL(cfg.serverUrl).origin;

// 32x32 drag icon, generated in code so no extra file is needed
const ICON_B64 = 'iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAlElEQVR4nO2WMQrAIAxF09JLtIPe/1g6tNfopIOI1ORHheaNIvxnEiFEhvF3ttqhc+7WCIsxXk0BreCWyD4isEUWGPX6MmudCvQQQjinCiQJhIi4BVIR2AxwJaBDyKmGyi/oETk0BLz3z9e7UIGe4ASsBZxwIkAFuMFiAWlwgtUCVDhbAEkWqG0rWiy1kEzfCQ1jOi/ZpDcgcZsLWQAAAABJRU5ErkJggg==';
const dragIcon = nativeImage.createFromDataURL('data:image/png;base64,' + ICON_B64);

let mainWin = null;
let pathMap = null;                       // created after app.whenReady (needs the userData folder)

// ---- navigation hardening ----------------------------------------------------------------------------
// The window must never open popups or leave the ClipStage server: the page it shows can call the drag and
// file-check bridge, so only the server's own pages may be loaded in it. A plain http(s) link may open in the
// SYSTEM browser, but only for the ClipStage server itself or hosts listed in config.json "allowedExternal".
const EXTERNAL_HOSTS = new Set([new URL(cfg.serverUrl).host.toLowerCase()].concat(
  (Array.isArray(cfg.allowedExternal) ? cfg.allowedExternal : []).map((h) => String(h).toLowerCase())));
function approvedExternal(u) {
  try {
    const x = new URL(u);
    return (x.protocol === 'https:' || x.protocol === 'http:') && EXTERNAL_HOSTS.has(x.host.toLowerCase());
  } catch (e) { return false; }
}
function openApprovedExternal(u) {
  if (approvedExternal(u)) shell.openExternal(u).catch(() => {});
  else console.warn('[ClipStage] blocked link:', String(u).slice(0, 200));
}
function lockDownNavigation(wc) {
  wc.setWindowOpenHandler(({ url }) => { openApprovedExternal(url); return { action: 'deny' }; });   // no popups, ever
  const guard = (event, url) => {                                // leaving the server's origin is not allowed
    try { if (new URL(url).origin === SERVER_ORIGIN) return; } catch (e) { /* unparsable: block */ }
    event.preventDefault();
    openApprovedExternal(url);
  };
  wc.on('will-navigate', guard);
  wc.on('will-redirect', guard);
  wc.on('will-attach-webview', (event) => event.preventDefault());
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1500, height: 950, title: 'ClipStage',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  mainWin = win;
  win.loadURL(cfg.serverUrl);
  lockDownNavigation(win.webContents);
}

let lastWarn = 0;
function fail(msg) {
  console.error('[ClipStage drag]', msg);
  if (Date.now() - lastWarn < 4000) return;           // don't spam popups
  lastWarn = Date.now();
  dialog.showMessageBox(mainWin, { type: 'warning', message: 'Drag to your editor failed', detail: msg });
}

function fromServerPage(event) {
  try {
    const u = event.senderFrame ? event.senderFrame.url : event.sender.getURL();
    return new URL(u).origin === SERVER_ORIGIN;
  } catch (e) { return false; }
}

const isSafeName = (s) => typeof s === 'string' && s && !s.includes('/') && !s.includes('\\') && !s.includes('\0') && s !== '.' && s !== '..';

// ---- per-row file check, cached for a few seconds (NAS round trips are slow) -----------------
const CHECK_TTL_MS = 5000;
const checkCache = new Map();             // host path -> { at, result }
async function checkOne(hostPath) {
  const hit = checkCache.get(hostPath);
  if (hit && Date.now() - hit.at < CHECK_TTL_MS) return hit.result;
  const result = await checkLocal(fs.promises, pathMap, hostPath);
  checkCache.set(hostPath, { at: Date.now(), result });
  if (checkCache.size > 5000) checkCache.clear();
  return result;
}

// Mapped, existing real files for a list of host paths (sync: startDrag must run inside the IPC event).
function mappedFiles(paths) {
  const files = []; let skipped = 0;
  for (const p of (Array.isArray(paths) ? paths : [paths]).slice(0, 200)) {
    const r = pathMap.resolve(p);
    if (r.state === 'ok' && fs.existsSync(r.local)) files.push(r.local); else skipped++;
  }
  return { files, skipped };
}

// ---- path map ---------------------------------------------------------------------------------
ipcMain.handle('clipstage-pm-status', (event, hostVols) => {
  if (!fromServerPage(event)) return { ok: false };
  const vols = (Array.isArray(hostVols) ? hostVols : []).filter((v) => isSafeName(v)).slice(0, 50);
  return { ok: true, platform: process.platform, root: pathMap.ad.volumesRoot(), volumes: pathMap.status(vols) };
});

ipcMain.handle('clipstage-pm-confirm', (event, hostVol, localRoot) => {
  if (!fromServerPage(event) || !isSafeName(hostVol)) return { ok: false };
  checkCache.clear();
  return { ok: pathMap.set(hostVol, localRoot) };
});

ipcMain.handle('clipstage-pm-choose', async (event, hostVol) => {
  if (!fromServerPage(event) || !isSafeName(hostVol)) return { ok: false };
  const r = await dialog.showOpenDialog(mainWin, {
    title: 'Where is the ' + hostVol + ' share on this computer?',
    defaultPath: pathMap.ad.volumesRoot(), properties: ['openDirectory'],
  });
  if (r.canceled || !r.filePaths.length) return { ok: false, canceled: true };
  checkCache.clear();
  return { ok: pathMap.set(hostVol, r.filePaths[0]), local: r.filePaths[0] };
});

ipcMain.handle('clipstage-pm-forget', (event, hostVol) => {
  if (!fromServerPage(event) || !isSafeName(hostVol)) return { ok: false };
  pathMap.remove(hostVol); checkCache.clear();
  return { ok: true };
});

// ---- green / red per row ----------------------------------------------------------------------
ipcMain.handle('clipstage-check', async (event, items) => {
  if (!fromServerPage(event) || !Array.isArray(items)) return [];
  const out = [];
  for (const it of items.slice(0, 500)) {
    const id = it && it.id, p = it && it.path;
    if (typeof id !== 'string' || typeof p !== 'string' || !p) { out.push({ id, state: 'bad_path' }); continue; }
    const r = await checkOne(p);
    out.push({ id, state: r.state, reason: r.reason || '', volume: r.volume || '' });
  }
  return out;
});

// This machine's spelling of a host path (for the Copy path button).
ipcMain.handle('clipstage-local-path', (event, hostPath) => {
  if (!fromServerPage(event)) return '';
  const r = pathMap.resolve(hostPath);
  return r.state === 'ok' ? r.local : '';
});

// ---- drag: staging panel AND search results use the same handler ------------------------------
ipcMain.on('clipstage-start-drag-paths', (event, paths) => {
  try {
    if (!fromServerPage(event)) {
      return fail('Drag refused: the page origin does not match serverUrl ' + SERVER_ORIGIN + ' in config.json.');
    }
    const { files, skipped } = mappedFiles(paths);
    if (!files.length) {
      return fail('No clip file could be found on this computer. Open the Volumes panel and confirm where ' +
        'each NAS share is mounted here, and check the NAS is connected.');
    }
    if (skipped) console.warn('[ClipStage drag] ' + skipped + ' clip(s) skipped: not reachable from this computer');
    if (dragIcon.isEmpty()) return fail('Drag icon failed to load.');
    event.sender.startDrag({ files, file: files[0], icon: dragIcon });
  } catch (err) {
    fail('startDrag error: ' + (err && err.message ? err.message : err));
  }
});

// ---- OPTIONAL local symlink folder (off by default: set "localLinks": true in config.json) ----
const LOCAL_ROOT = cfg.localFolder || path.join(os.homedir(), 'ClipStage');
const localDirFor = (editor) => path.join(LOCAL_ROOT, editor);
function syncLocalLinks(editor, clips) {
  const dir = localDirFor(editor);
  fs.mkdirSync(dir, { recursive: true });
  const want = new Map();
  const missing = [];
  for (const c of clips) {
    if (!c || !isSafeName(c.name) || !c.path) continue;
    const r = pathMap.resolve(c.path);
    if (!(r.state === 'ok' && fs.existsSync(r.local))) { missing.push(c.name); continue; }
    // two different clips can share a file name: keep both (name__2.ext). The same file twice is listed once.
    const dot = c.name.lastIndexOf('.');
    const stem = dot > 0 ? c.name.slice(0, dot) : c.name, ext = dot > 0 ? c.name.slice(dot) : '';
    let name = c.name, n = 2, dup = false;
    while (want.has(name)) {
      if (want.get(name) === r.local) { dup = true; break; }
      name = stem + '__' + n + ext; n += 1;
    }
    if (!dup) want.set(name, r.local);
  }
  for (const n of fs.readdirSync(dir)) {          // only symlinks are ever removed
    const p = path.join(dir, n);
    let st; try { st = fs.lstatSync(p); } catch (e) { continue; }
    if (st.isSymbolicLink() && !want.has(n)) { try { fs.unlinkSync(p); } catch (e) {} }
  }
  let linked = 0;
  for (const [n, real] of want) {
    const p = path.join(dir, n);
    let st = null; try { st = fs.lstatSync(p); } catch (e) {}
    if (st && !st.isSymbolicLink()) { missing.push(n); continue; }   // a real file: leave it alone
    if (st) {
      let cur = null; try { cur = fs.readlinkSync(p); } catch (e) {}
      if (cur === real) { linked++; continue; }
      try { fs.unlinkSync(p); } catch (e) {}
    }
    try { fs.symlinkSync(real, p); linked++; } catch (e) { missing.push(n); }
  }
  return { dir, linked, missing };
}

ipcMain.handle('clipstage-sync-local', (event, editor, clips) => {
  try {
    if (!fromServerPage(event)) return { ok: false, reason: 'origin' };
    if (!cfg.localLinks) return { ok: false, reason: 'disabled' };
    if (IS_WIN) return { ok: false, reason: 'windows' };
    if (!isSafeName(editor) || !Array.isArray(clips)) return { ok: false, reason: 'bad request' };
    return Object.assign({ ok: true }, syncLocalLinks(editor, clips.slice(0, 500)));
  } catch (err) {
    return { ok: false, reason: String(err && err.message ? err.message : err) };
  }
});

ipcMain.on('clipstage-open-local', (event, editor) => {
  try {
    if (!fromServerPage(event) || !cfg.localLinks || IS_WIN || !isSafeName(editor)) return;
    const dir = localDirFor(editor);
    fs.mkdirSync(dir, { recursive: true });
    shell.openPath(dir).then((err) => { if (err) fail('Could not open ' + dir + ': ' + err); });
  } catch (err) {
    fail('open local folder error: ' + (err && err.message ? err.message : err));
  }
});

app.whenReady().then(() => {
  pathMap = new PathMap(path.join(app.getPath('userData'), 'pathmap.json'), process.platform);
  createWindow();
});
app.on('window-all-closed', () => app.quit());
