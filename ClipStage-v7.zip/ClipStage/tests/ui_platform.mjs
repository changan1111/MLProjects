/*
 * ClipStage UI check for the editor's computer type. Runs the REAL index.html in jsdom twice:
 * as a plain browser and as the desktop app (stubbed), and checks the v7 staging wording, the Volumes box
 * (it lists the host's volumes, not only those of staged clips) and the Open local folder link.   node tests/ui_platform.mjs   (from the project folder; needs jsdom)
 */
import { JSDOM } from "jsdom";
import fs from "fs";
import { fileURLToPath } from "url";
const here = (p) => fileURLToPath(new URL(p, import.meta.url));
const html = fs.readFileSync(here("../index.html"), "utf8").replace("__CLIPSTAGE_SMB_HOST__", '""');
const reply = (body) => Promise.resolve({ ok: true, status: 200, headers: new Map(), json: async () => body, text: async () => JSON.stringify(body) });
let pass = 0, fail = 0;
const check = (name, cond, extra = "") => { (cond ? pass++ : fail++); console.log(`${cond ? "PASS" : "FAIL"}  ${name}${extra ? "  -> " + extra : ""}`); };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

async function boot(userAgent, native) {
  const clip = { text: null };
  const stub = (url) => {
    const u = String(url);
    if (u.startsWith("/config")) return reply({ smb_host: "10.1.10.5", platform: "windows", share_name: "staging" });
    if (u.startsWith("/auth/me")) return reply({ username: "e@x.com", role: "editor", valid_through: "2099-01-01", editor_name: "GOKUL" });
    if (u.startsWith("/editors")) return reply({ editors: ["GOKUL"] });
    if (u.startsWith("/stage/")) return reply({ clips: [] });
    if (u.startsWith("/pathmap/hints")) return reply({ host_volumes: ["EDIT", "PLAYOUT"] });
    if (u.startsWith("/search")) return reply({ hits: [], total: 0, truncated: false });
    return reply({});
  };
  const dom = new JSDOM(html, {
    runScripts: "dangerously", url: "http://localhost:8000/", pretendToBeVisual: true,
    beforeParse(w) {
      Object.defineProperty(w.navigator, "userAgent", { value: userAgent, configurable: true });
      w.Request = class Request {}; w.Headers = Headers; w.CSS = { escape: (v) => String(v) }; w.fetch = stub;
      w.confirm = () => true; w.alert = () => {}; w.prompt = () => null;
      w.localStorage.setItem("clipstage_token_exp", String(Math.floor(Date.now() / 1000) + 3600));
      w.localStorage.setItem("clipstage_token_role", "editor");
      w.localStorage.setItem("clipstage_token_valid_through", "2099-01-01");
      w.HTMLElement.prototype.scrollIntoView = () => {};
      Object.defineProperty(w.navigator, "clipboard", { value: { writeText: (t) => { clip.text = t; return Promise.resolve(); } }, configurable: true });
      if (native) w.clipstageNative = native;
    },
  });
  await wait(500);
  return { w: dom.window, clip };
}

const WIN = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36";
const MAC = "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 Safari/605.1.15";

const APP = (extra = {}) => ({
  version: 7, platform: "darwin",
  startDragPaths() {}, checkClips: async () => [], localPath: async () => "", openLocal() {},
  pathMapStatus: async (vols) => ({ ok: true, root: "/Volumes", volumes: vols.map((h) => h === "EDIT"
    ? { host: h, local: "/Volumes/EDIT-1", confirmed: false, kind: "renamed", candidates: ["/Volumes/EDIT-1"] }
    : { host: h, local: "", confirmed: false, kind: "none", candidates: [] }) }),
  syncLocal: async () => ({ ok: true, linked: 0, missing: [] }),
  ...extra,
});
{
  const { w } = await boot(WIN);
  const how = w.document.getElementById("stagingHow");
  check("Browser: says dragging needs the desktop app and offers copy paths", how && /desktop app/.test(how.textContent) && /copy paths/i.test(how.textContent), how && how.textContent);
  w.eval("currentEditor = 'GOKUL'"); w.eval("openFinder()");
  const t = w.document.getElementById("toast").textContent;
  check("Browser: the Volumes button explains it needs the app", /desktop app/.test(t), t);
  check("No staging-share wording is left in the page", !/\/Volumes\/staging|smb:\/\//i.test(w.document.body.innerHTML));
}
{
  let asked = null;
  const { w } = await boot(MAC, APP({ pathMapStatus: async (vols) => { asked = vols; return APP().pathMapStatus(vols); } }));
  check("App: button says Volumes on this computer", /Volumes on this computer/.test(w.document.getElementById("openFinderBtn").textContent));
  w.eval("currentEditor = 'GOKUL'");
  await w.eval("loadStaging()"); await wait(150);
  check("App: the path map is asked about EVERY host volume (EDIT and PLAYOUT), with no clip staged", JSON.stringify(asked) === JSON.stringify(["EDIT", "PLAYOUT"]), JSON.stringify(asked));
  const box = w.document.getElementById("pmBox");
  check("App: a renamed volume is offered for one-click confirmation", /Yes, use it/.test(box.innerHTML) && /EDIT-1/.test(box.innerHTML));
  check("App: a volume this computer does not have is not nagged about", !/PLAYOUT/.test(box.innerHTML), box.innerHTML.slice(0, 200));
  const a = w.document.getElementById("stgOpenLocal");
  check("App: Open local folder link appears when the app keeps a local folder", a && a.style.display === "inline", a && a.style.display);
}
{
  const { w } = await boot(MAC, APP({ syncLocal: async () => ({ ok: false, reason: "disabled" }) }));
  w.eval("currentEditor = 'GOKUL'");
  await w.eval("loadStaging()"); await wait(150);
  const a = w.document.getElementById("stgOpenLocal");
  check("App with local links off: no Open local folder link", a && a.style.display === "none", a && a.style.display);
}
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
