// Unit tests for the editor app's path map + platform adapter (plain Node, no Electron needed).
//   node --test tests/pathmap.test.js
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { PathMap, parseHostPath, detect, checkLocal } = require('../clipstage-fcp-drag/pathmap');

const tmpFile = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'pm-')), 'pathmap.json');
// a fake fs that pretends these folders exist under the volumes root
const fakeFs = (names) => ({
  readFileSync: (...a) => fs.readFileSync(...a), writeFileSync: (...a) => fs.writeFileSync(...a), mkdirSync: (...a) => fs.mkdirSync(...a),
  readdirSync: () => names.map((n) => ({ name: n, isDirectory: () => true, isSymbolicLink: () => false })),
});

test('parseHostPath accepts Mac and Windows host spellings', () => {
  assert.deepStrictEqual(parseHostPath('/Volumes/EDIT/NEWS/a.mxf'), { volume: 'EDIT', rest: ['NEWS', 'a.mxf'] });
  assert.deepStrictEqual(parseHostPath('C:/Volumes/EDIT/NEWS/a.mxf'), { volume: 'EDIT', rest: ['NEWS', 'a.mxf'] });
  assert.deepStrictEqual(parseHostPath('C:\\Volumes\\EDIT\\a.mxf'), { volume: 'EDIT', rest: ['a.mxf'] });
});

test('parseHostPath rejects traversal, NUL, short and foreign paths', () => {
  for (const bad of ['/Volumes/EDIT/../etc/passwd', '/Volumes/EDIT/./a', '/etc/passwd', '/Volumes/EDIT', '/Volumes', '', null, 5, '/Volumes/EDIT/a\0b']) {
    assert.strictEqual(parseHostPath(bad), null, String(bad));
  }
});

test('detect: exact, renamed (EDIT-1), ambiguous, none; case-insensitive', () => {
  assert.strictEqual(detect('EDIT', ['EDIT', 'PLAYOUT']).kind, 'exact');
  assert.strictEqual(detect('EDIT', ['edit']).kind, 'exact');
  assert.deepStrictEqual(detect('EDIT', ['EDIT-1', 'PLAYOUT']), { kind: 'renamed', candidates: ['EDIT-1'] });
  assert.strictEqual(detect('EDIT', ['EDIT', 'EDIT-1']).kind, 'ambiguous');
  assert.strictEqual(detect('EDIT', ['EDIT-1', 'EDIT-2']).kind, 'ambiguous');
  assert.strictEqual(detect('EDIT', ['EDITOR', 'EDIT2']).kind, 'none');      // not a duplicate-suffix name
  assert.strictEqual(detect('EDIT', []).kind, 'none');
});

test('Mac with the share mounted as EDIT-1: proposal needs one confirm, then maps', () => {
  const pm = new PathMap(tmpFile(), 'darwin', fakeFs(['EDIT-1', 'PLAYOUT']));
  const host = '/Volumes/EDIT/NEWS/a.mxf';
  assert.strictEqual(pm.resolve(host).state, 'not_mapped');                    // never guesses before the confirm
  const st = pm.status(['EDIT'])[0];
  assert.deepStrictEqual([st.kind, st.local, st.confirmed], ['renamed', '/Volumes/EDIT-1', false]);
  assert.ok(pm.set('EDIT', st.local));
  assert.deepStrictEqual(pm.resolve(host), { state: 'ok', local: '/Volumes/EDIT-1/NEWS/a.mxf', volume: 'EDIT' });
  assert.strictEqual(pm.resolve('/Volumes/edit/NEWS/a.mxf').state, 'ok');       // case-insensitive volume match
});

test('Windows editor: host Mac path maps to C:\\Volumes or a UNC share', () => {
  const pm = new PathMap(tmpFile(), 'win32', fakeFs([]));
  pm.set('EDIT', 'C:\\Volumes\\EDIT');
  assert.strictEqual(pm.resolve('/Volumes/EDIT/NEWS/a.mxf').local, 'C:\\Volumes\\EDIT\\NEWS\\a.mxf');
  pm.set('EDIT', '\\\\nas\\EDIT');
  assert.strictEqual(pm.resolve('/Volumes/EDIT/NEWS/a.mxf').local, '\\\\nas\\EDIT\\NEWS\\a.mxf');
  pm.set('PLAYOUT', 'Z:\\');
  assert.strictEqual(pm.resolve('C:/Volumes/PLAYOUT/x/y.mov').local, 'Z:\\x\\y.mov');
});

test('set() refuses relative or empty roots; map persists and reloads', () => {
  const f = tmpFile();
  const pm = new PathMap(f, 'darwin', fakeFs([]));
  assert.strictEqual(pm.set('EDIT', 'relative/dir'), false);
  assert.strictEqual(pm.set('', '/Volumes/EDIT'), false);
  pm.set('EDIT', '/Volumes/EDIT-1');
  const again = new PathMap(f, 'darwin', fakeFs([]));
  assert.strictEqual(again.resolve('/Volumes/EDIT/a/b.mxf').local, '/Volumes/EDIT-1/a/b.mxf');
  again.remove('EDIT');
  assert.strictEqual(again.resolve('/Volumes/EDIT/a/b.mxf').state, 'not_mapped');
});

test('a corrupt map file is ignored, not fatal', () => {
  const f = tmpFile(); fs.writeFileSync(f, '{not json');
  assert.strictEqual(new PathMap(f, 'darwin', fakeFs([])).data.pairs.length, 0);
});

test('checkLocal reports ok / not_mapped / not_mounted / missing / no_access / bad_path', async () => {
  const pm = new PathMap(tmpFile(), 'darwin', fakeFs([]));
  pm.set('EDIT', '/Volumes/EDIT-1');
  const mk = (gone, denied) => ({ access: async (p) => {
    if (gone.includes(p)) { const e = new Error('x'); e.code = 'ENOENT'; throw e; }
    if (denied.includes(p)) { const e = new Error('x'); e.code = 'EACCES'; throw e; }
  } });
  const h = '/Volumes/EDIT/NEWS/a.mxf';
  assert.strictEqual((await checkLocal(mk([], []), pm, h)).state, 'ok');
  assert.strictEqual((await checkLocal(mk([], []), pm, '/Volumes/PLAYOUT/a.mxf')).state, 'not_mapped');
  assert.strictEqual((await checkLocal(mk(['/Volumes/EDIT-1'], []), pm, h)).state, 'not_mounted');
  assert.strictEqual((await checkLocal(mk(['/Volumes/EDIT-1/NEWS/a.mxf'], []), pm, h)).state, 'missing');
  assert.strictEqual((await checkLocal(mk([], ['/Volumes/EDIT-1/NEWS/a.mxf']), pm, h)).state, 'no_access');
  assert.strictEqual((await checkLocal(mk([], []), pm, '/Volumes/EDIT/../x/a.mxf')).state, 'bad_path');
});

test('real files: a dropped mount shows not_mounted, a present file is ok', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'vol-'));
  fs.mkdirSync(path.join(root, 'EDIT-1', 'NEWS'), { recursive: true });
  fs.writeFileSync(path.join(root, 'EDIT-1', 'NEWS', 'a.mxf'), 'x');
  const pm = new PathMap(tmpFile(), 'linux', fakeFs([]));
  pm.set('EDIT', path.join(root, 'EDIT-1'));
  assert.strictEqual((await checkLocal(fs.promises, pm, '/Volumes/EDIT/NEWS/a.mxf')).state, 'ok');
  assert.strictEqual((await checkLocal(fs.promises, pm, '/Volumes/EDIT/NEWS/gone.mxf')).state, 'missing');
  fs.rmSync(path.join(root, 'EDIT-1'), { recursive: true });                 // the share drops mid-session
  assert.strictEqual((await checkLocal(fs.promises, pm, '/Volumes/EDIT/NEWS/a.mxf')).state, 'not_mounted');
});
