'use strict';
// Runs clipstage-fcp-drag/main.js with a stubbed `electron` module to check the IPC logic (no GUI needed).
//   node --test tests/pathmap.test.js tests/main.smoke.test.js
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const Module = require('module');

const T = fs.mkdtempSync(path.join(os.tmpdir(), 'cs-main-'));
const VOL = path.join(T, 'vol');
fs.mkdirSync(path.join(VOL, 'EDIT-1', '2026'), { recursive: true });
fs.mkdirSync(path.join(VOL, 'EDIT-1', 'other'), { recursive: true });
fs.writeFileSync(path.join(VOL, 'EDIT-1', '2026', 'a.mxf'), 'x');
fs.writeFileSync(path.join(VOL, 'EDIT-1', 'other', 'a.mxf'), 'y');

const APP = path.join(T, 'app');                  // main.js reads config.json next to itself
fs.mkdirSync(APP);
const SRC = path.join(__dirname, '..', 'clipstage-fcp-drag');
for (const f of ['main.js', 'pathmap.js']) fs.copyFileSync(path.join(SRC, f), path.join(APP, f));
const writeCfg = (extra) => fs.writeFileSync(path.join(APP, 'config.json'),
  JSON.stringify(Object.assign({ serverUrl: 'http://host:8000', localLinks: true, localFolder: path.join(T, 'links') }, extra)));
writeCfg({ allowedExternal: ['docs.example.org'] });

const handlers = {}, ons = {}, calls = { drag: [], dialog: [], open: [], external: [], wc: {}, popup: null };
const electron = {
  app: { getPath: () => path.join(T, 'userdata'), whenReady: () => ({ then: (f) => { f(); } }), on() {} },
  BrowserWindow: function () { this.loadURL = () => {}; this.webContents = { setWindowOpenHandler: (f) => { calls.popup = f; }, on: (ev, f) => { calls.wc[ev] = f; } }; },
  ipcMain: { handle: (n, f) => { handlers[n] = f; }, on: (n, f) => { ons[n] = f; } },
  nativeImage: { createFromDataURL: () => ({ isEmpty: () => false }) },
  shell: { openPath: (p) => { calls.open.push(p); return Promise.resolve(''); }, openExternal: (u) => { calls.external.push(u); return Promise.resolve(); } },
  dialog: { showMessageBox: (_w, o) => { calls.dialog.push(o.detail); return Promise.resolve({}); }, showOpenDialog: async () => ({ canceled: true, filePaths: [] }) },
};
const orig = Module._load;
Module._load = function (req, ...r) { return req === 'electron' ? electron : orig.call(this, req, ...r); };
require(path.join(APP, 'main.js'));
Module._load = orig;

const good = { senderFrame: { url: 'http://host:8000/' }, sender: { startDrag: (o) => calls.drag.push(o) } };
const evil = { senderFrame: { url: 'http://evil:9/' }, sender: { startDrag: (o) => calls.drag.push(o) } };

test('rejects every call from a page that is not the ClipStage server', async () => {
  assert.strictEqual((await handlers['clipstage-pm-status'](evil, ['EDIT'])).ok, false);
  assert.strictEqual((await handlers['clipstage-pm-confirm'](evil, 'EDIT', VOL)).ok, false);
  assert.deepStrictEqual(await handlers['clipstage-check'](evil, [{ id: '1', path: '/Volumes/EDIT/a.mxf' }]), []);
  assert.strictEqual((await handlers['clipstage-sync-local'](evil, 'GOKUL', [])).ok, false);
  ons['clipstage-start-drag-paths'](evil, ['/Volumes/EDIT/2026/a.mxf']);
  assert.strictEqual(calls.drag.length, 0);
});
test('an unconfirmed volume is never used: not_mapped, and drag refuses with a clear message', async () => {
  const r = await handlers['clipstage-check'](good, [{ id: '1', path: '/Volumes/EDIT/2026/a.mxf' }]);
  assert.strictEqual(r[0].state, 'not_mapped');
  const realNow = Date.now; Date.now = () => realNow() + 10000;      // step past the app's 4 s popup rate limit
  ons['clipstage-start-drag-paths'](good, ['/Volumes/EDIT/2026/a.mxf']);
  Date.now = realNow;
  assert.strictEqual(calls.drag.length, 0);
  assert.match(calls.dialog[calls.dialog.length - 1], /Volumes/);
});
test('confirm once, then check / local-path / drag use the mapped folder (EDIT -> EDIT-1)', async () => {
  assert.strictEqual((await handlers['clipstage-pm-confirm'](good, 'EDIT', path.join(VOL, 'EDIT-1'))).ok, true);
  assert.strictEqual((await handlers['clipstage-pm-confirm'](good, '../x', VOL)).ok, false);       // unsafe name refused
  assert.strictEqual((await handlers['clipstage-pm-confirm'](good, 'EDIT2', 'relative/path')).ok, false);   // not absolute
  const r = await handlers['clipstage-check'](good, [{ id: '1', path: '/Volumes/EDIT/2026/a.mxf' },
    { id: '2', path: '/Volumes/EDIT/2026/nope.mxf' }, { id: '3', path: '/Volumes/INGEST/x.mxf' }, { id: '4', path: '/etc/passwd' }]);
  assert.deepStrictEqual(r.map((x) => x.state), ['ok', 'missing', 'not_mapped', 'bad_path']);
  assert.strictEqual(await handlers['clipstage-local-path'](good, '/Volumes/EDIT/2026/a.mxf'), path.join(VOL, 'EDIT-1/2026/a.mxf'));
  ons['clipstage-start-drag-paths'](good, ['/Volumes/EDIT/2026/a.mxf', '/Volumes/EDIT/other/a.mxf', '/Volumes/EDIT/2026/nope.mxf']);
  assert.deepStrictEqual(calls.drag[0].files, [path.join(VOL, 'EDIT-1/2026/a.mxf'), path.join(VOL, 'EDIT-1/other/a.mxf')]);
});
test('path map status lists host volumes and proposes a renamed one for confirmation', async () => {
  const s = await handlers['clipstage-pm-status'](good, ['EDIT', 'PLAYOUT', '../bad']);
  assert.strictEqual(s.ok, true);
  assert.deepStrictEqual(s.volumes.map((v) => v.host), ['EDIT', 'PLAYOUT']);         // the unsafe name is dropped
  assert.strictEqual(s.volumes[0].confirmed, true);
  assert.strictEqual(s.volumes[1].confirmed, false);
});
test('local links: same file name from two folders keeps both, stale links go, a real file stays', async () => {
  const clips = [{ name: 'a.mxf', path: '/Volumes/EDIT/2026/a.mxf' }, { name: 'a.mxf', path: '/Volumes/EDIT/other/a.mxf' },
    { name: 'gone.mxf', path: '/Volumes/EDIT/2026/gone.mxf' }];
  const r = await handlers['clipstage-sync-local'](good, 'GOKUL', clips);
  assert.strictEqual(r.ok, true); assert.strictEqual(r.linked, 2); assert.deepStrictEqual(r.missing, ['gone.mxf']);
  const d = path.join(T, 'links', 'GOKUL');
  assert.strictEqual(fs.readlinkSync(path.join(d, 'a.mxf')), path.join(VOL, 'EDIT-1/2026/a.mxf'));
  assert.strictEqual(fs.readlinkSync(path.join(d, 'a__2.mxf')), path.join(VOL, 'EDIT-1/other/a.mxf'));
  fs.writeFileSync(path.join(d, 'keep.txt'), 'mine');
  await handlers['clipstage-sync-local'](good, 'GOKUL', [clips[0]]);
  assert.ok(!fs.existsSync(path.join(d, 'a__2.mxf')));
  assert.strictEqual(fs.readFileSync(path.join(d, 'keep.txt'), 'utf8'), 'mine');
  assert.strictEqual((await handlers['clipstage-sync-local'](good, '../evil', [])).ok, false);
});
test('open-local opens the folder; localLinks=false turns the local folder off', async () => {
  ons['clipstage-open-local'](good, 'GOKUL');
  assert.deepStrictEqual(calls.open, [path.join(T, 'links', 'GOKUL')]);
});

test('navigation hardening: no popups, no leaving the server, only approved links open in the system browser', () => {
  assert.strictEqual(typeof calls.popup, 'function');
  for (const u of ['http://host:8000/staging/view/GOKUL', 'https://docs.example.org/help', 'https://evil.example/x', 'file:///etc/passwd', 'javascript:alert(1)', 'not a url']) {
    assert.deepStrictEqual(calls.popup({ url: u }), { action: 'deny' }, u);          // never allowed to open a window
  }
  assert.deepStrictEqual(calls.external, ['http://host:8000/staging/view/GOKUL', 'https://docs.example.org/help']);
  const nav = (u) => { let blocked = false; calls.wc['will-navigate']({ preventDefault: () => { blocked = true; } }, u); return blocked; };
  assert.strictEqual(nav('http://host:8000/#clip'), false);                          // the app's own pages navigate normally
  assert.strictEqual(nav('http://host:8000/login'), false);
  assert.strictEqual(nav('https://evil.example/phish'), true);                       // leaving the origin is blocked
  assert.strictEqual(nav('http://host:9999/'), true);                                // same host, other port = other origin
  assert.strictEqual(nav('file:///etc/passwd'), true);
  let redirectBlocked = false; calls.wc['will-redirect']({ preventDefault: () => { redirectBlocked = true; } }, 'https://evil.example/r');
  assert.strictEqual(redirectBlocked, true);
  let wvBlocked = false; calls.wc['will-attach-webview']({ preventDefault: () => { wvBlocked = true; } });
  assert.strictEqual(wvBlocked, true);
  assert.ok(!calls.external.some((u) => /evil|file:|javascript/.test(u)));          // nothing unapproved reached the system browser
});
