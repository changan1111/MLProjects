# ClipStage v7 - staging as a database list

v7 = the v6-dev build, plus the parts of my own 5.1.4 build that were better, plus fixes found while merging.
Install guide (Mac + Windows): **INSTALL-v7.pdf / INSTALL-v7.html**.

## The design (from v6-dev)
- Staging is a table (`staged`) in `clipstage.db`. `POST /stage` accepts paths or `clip_ids`, writes rows, and writes nothing to disk.
- `GET /stage/{editor}` returns `clip_id, canonical_path, name, status (ok | removed_from_index | hidden), staged_at`.
- `DELETE /stage/{editor}/{clip_id}` removes one clip. `DELETE /stage/{editor}` clears the list.
- The desktop app maps the host's volume names to this computer's mounts (`pathmap.js`). A volume is used only after the
  editor confirms it once. One adapter handles Mac and Windows path styles.
- `migrate_staging_to_db.py` imports old host staging links (dry run by default).

## Added in v7 (from my 5.1.4)
- `GET /pathmap/hints`: the host's volume names, so the Volumes box lists every host volume, not only those of staged clips
  (needed for drag straight from search). A volume this computer does not have is hidden unless a staged clip needs it.
- A removed-from-index clip keeps its name (path snapshot in `staged.path`; older tables are upgraded in place).
- Local links folder `~/ClipStage/<NAME>` is ON by default on Mac (the proven Finder fallback), with an **Open local folder**
  link. Two clips with the same file name no longer overwrite each other (`name__2.ext`). Off on Windows.
- Installers: Mac editor rebuilds an older app (version/server check) and writes `localLinks: true`; Windows editor no longer
  connects to a staging share or changes any Windows link setting; Mac and Windows host installers no longer create the
  staging folder/share (legacy switch: `CLIPSTAGE_LEGACY_STAGING=1` / `-LegacyStaging`).
- 7 more Node tests for the app's IPC (stubbed Electron) next to v6-dev's 9 path-map tests; 2 new API tests; `ui_platform.mjs` rewritten.
- **Electron navigation hardening** (`main.js`): the old handler allowed every new window and nothing restricted navigation.
  Now popups are always denied; the window can only navigate within the server's origin (`will-navigate`, `will-redirect`);
  webviews are blocked; a plain http(s) link opens in the system browser only for the ClipStage server or hosts listed in
  `config.json` `allowedExternal` (default none). Tested with a stubbed Electron. Not tested in a real Electron window.

## Bugs fixed while merging (present in v6-dev, and in my 5.1.4 for the first one)
1. **Windows editor kit did not include `pathmap.js`.** The app would not start on a Windows editor. Fixed in `install-win-host.ps1`.
2. My 5.1.4 Windows host skipped creating the `clipstage-editor` account, which editor PCs need to read the setup kit.
   v7 always creates it; only the staging share is optional.
3. v6-dev's `ui_platform.mjs` still tested the old staging-folder wording. Rewritten.
4. v6-dev's Windows editor installer still tried to connect to the staging share (it would warn). Removed.
5. Mac upgrade copy (`rsync`) overwrites `editors.json` with the zip's sample. The guide says to delete it from the unzipped folder first.

## Deliberately NOT included
- Skipping a re-mount when a share is already mounted as `EDIT-1` (untested on a real Mac). v7 keeps v6-dev's warning only.
- Developer Mode / Windows symlink changes. Windows has no local links folder.
- Host-side "file exists" check on stage (v6-dev's choice kept: the editor computer decides).

## Verified here / not verified
Run and passing: 16 Node tests; staging DB functions incl. upgrade of a v6-dev table; syntax of Python, JS, page script, bash.
Written but NOT run (no pytest/fastapi/jsdom/PowerShell here): `tests/test_api.py`, `tests/ui_platform.mjs`, both `.ps1` installers.
Never run on real hardware: drag into FCP (one / several files), Leave in place, Windows editing apps, Mac local-links route.
