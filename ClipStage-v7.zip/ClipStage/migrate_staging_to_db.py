#!/usr/bin/env python3
"""
ClipStage v7 - one-time import of the OLD host staging folders into the `staged` table.

    python migrate_staging_to_db.py            dry run: lists what would be imported
    python migrate_staging_to_db.py --apply    imports (clipstage.db is backed up first)

Reads /Users/Shared/staging/<EDITOR>/ (CLIPSTAGE_STAGING_PATH): every symlink there becomes a row for that
editor. Only READS the folders; nothing is deleted, nothing is written to the NAS. Safe to re-run.
Run it on a COPY of clipstage.db first if you want to rehearse (CLIPSTAGE_DB=/tmp/copy.db python ...).
"""
import os
import shutil
import sys
import time
from pathlib import Path

import store
from clipstage_config import STAGING_PATH, clip_uid, norm_path

APPLY = "--apply" in sys.argv


def main() -> int:
    root = Path(STAGING_PATH)
    if not root.is_dir():
        print(f"No staging folder at {root} - nothing to import.")
        return 0
    found = []
    for ed in sorted(p for p in root.iterdir() if p.is_dir()):
        for item in sorted(ed.iterdir()):
            if not item.is_symlink():
                continue                               # copy / hardlink mode files cannot be traced back
            try:
                target = norm_path(os.readlink(str(item)))
                found.append((ed.name, item.name, clip_uid(target), target))
            except OSError:
                pass
    print(f"{len(found)} staged link(s) in {root}")
    for ed, name, uid, _ in found:
        print(f"  {ed:<14} {uid}  {name}")
    if not APPLY:
        print("\nDRY RUN - nothing changed. Re-run with --apply to import.")
        return 0
    if Path(store.DB_PATH).exists():
        bk = Path(store.DB_PATH).with_name(f"clipstage_{time.strftime('%Y%m%d_%H%M%S')}_before_staging_import.db")
        shutil.copy2(store.DB_PATH, bk)
        print(f"Backup written: {bk}")
    new = sum(1 for ed, _, uid, tgt in found if store.stage_add(ed, uid, "migration", tgt))
    store.audit("migration", "import-staging", f"{new} new of {len(found)} link(s)")
    print(f"Imported {new} new row(s) ({len(found) - new} were already there).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
