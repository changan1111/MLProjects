# NEWS EDIT PRO
**JANAM TV Newsroom Automation Console**

---

## Quick Start (Single Machine)
1. Install ffmpeg:  
   `eval "$(/opt/homebrew/bin/brew shellenv)" && brew install ffmpeg`
2. Double-click **START_LOCAL.command**
3. Browser opens at http://127.0.0.1:8765

## Network Mode (One Mac serves all editors)
- Double-click **START_NETWORK_SERVER.command** on the server Mac
- Other editors open the printed URL in their browser

## Login (Supabase)
Editors sign in with their email and password through Supabase Auth.

**One-time setup**
1. In your Supabase project, turn **off** new-user sign-ups
   (Authentication settings) so only people you invite can get in.
2. Create each editor under Authentication > Users.
3. Copy `supabase.example.json` to `supabase.json` and fill in:
   - `url` - Project URL
   - `anon_key` - the public anon / publishable key
   - `allowed_emails` / `allowed_domain` (optional) - extra allow-list,
     e.g. `"allowed_domain": "janamtv.com"`. Leave empty to allow every
     user in the project.
4. Restart the app.

**Rules**
- Use only the public anon / publishable key. **Never** put the
  `service_role` / secret key in this file.
- `supabase.json` is git-ignored. Do not commit it.
- No `supabase.json` (and no `SUPABASE_URL` / `SUPABASE_ANON_KEY`
  variables) = open access, for local dev only. Network mode prints a
  warning in that case.
- A broken `supabase.json` blocks all logins until it is fixed.
- Sessions last 8 hours. Every 15 minutes the server re-checks with
  Supabase, so a deleted or banned user is logged out within ~15 minutes.
  If the internet drops, signed-in editors keep working; **new logins
  need internet.**

## Update from GitHub
Double-click **UPDATE.command**

## Settings
Stage and playout folders are set in the Settings panel in the console
(saved to `pro_config.json`). Built-in defaults:
- Stage folder: `~/Desktop/EXPORT_STAGE`
- Playout: `/Volumes/NAS809377/PLAYOUT/inbox/news`

## Cut Modes
| Mode | Use |
|------|-----|
| AUTO SHOTS | Best clips, adaptive fill |
| ONE BLOCK | All shots full-length for editor |
| STORY ORDER | Narrative/sequence stories |
| INTERVIEW | Multicam audio-follow |

---
*Port 8765 · ProRes 422 TL · MXF XDCAM HD422 50Mbps · 1080i 25fps*

## Performance notes
- Analysis (scene detect, brightness/blur/duplicate checks) is cached in
  `analysis_cache.json` (git-ignored). Re-running a story is near-instant.
  Delete the file to force a fresh analysis.
- Scene detection runs on 320px-wide frames (`SCENE_SCALE_W`) with VideoToolbox
  hardware decode on macOS. If shot cuts look different from before, tune
  `SCENE_THRESHOLD`, or set `SCENE_SCALE_W = 0` for the old full-size behaviour.
- Final render encodes pieces in parallel (`RENDER_WORKERS`) and warns in the
  result if any piece is more than 2 frames off its planned length.

## Security hardening (added)
- Network mode (`0.0.0.0`) refuses to start without a valid `supabase.json`.
  Override knowingly with `NEWS_EDIT_ALLOW_OPEN=1`.
- Requests are rejected unless the Host header is localhost, an IP address
  or this Mac's own name. For a custom hostname, set
  `NEWS_EDIT_ALLOWED_HOSTS=name1,name2`.
- Cross-site POSTs are blocked; 5 failed logins per IP per 5 minutes locks
  that IP out for the rest of the window.
- Clips must be real video files.
- Still plain HTTP: put Caddy/nginx (HTTPS) in front when possible.
- Keep Supabase sign-ups OFF and set `allowed_domain`.
