#!/bin/bash
# NEWS EDIT PRO — Pull latest from GitHub
cd "$(dirname "$0")"
if [ ! -d ".git" ]; then
  echo "ERROR: Not a git repo. Clone from GitHub first."
  read -p "Press Enter to close..."
  exit 1
fi
git pull origin main
echo ""
echo "Update complete. Restart the app."
read -p "Press Enter to close..."
