#!/bin/bash
# NEWS EDIT PRO - double-click to open the console
cd "$(dirname "$0")"
/usr/bin/python3 NewsEditPro.py
