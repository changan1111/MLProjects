#!/bin/bash
# Creates NEWS EDIT PRO as a proper Dock app using Automator
# No py2app needed - works on every Mac immediately
cd "$(dirname "$0")"
TOOL="$(pwd)/NewsEditPro.py"
APP="$HOME/Desktop/NEWS EDIT PRO.app"
MACOS="$APP/Contents/MacOS"
RES="$APP/Contents/Resources"

rm -rf "$APP"
mkdir -p "$MACOS" "$RES"

# Embed script and config
cp NewsEditPro.py "$RES/"
[ -f pro_config.json ] && cp pro_config.json "$RES/"
[ -f supabase.json ] && cp supabase.json "$RES/"

# Main executable - finds brew ffmpeg regardless of PATH
cat > "$MACOS/NEWS EDIT PRO" << 'LAUNCH'
#!/bin/bash
# Add Homebrew to PATH so ffmpeg is always found
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
export NEWS_EDIT_BASE="$(dirname "$0")/../Resources"
cd "$NEWS_EDIT_BASE"
/usr/bin/python3 NewsEditPro.py
LAUNCH
chmod +x "$MACOS/NEWS EDIT PRO"

# Info.plist - proper app metadata
cat > "$APP/Contents/Info.plist" << 'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>NEWS EDIT PRO</string>
  <key>CFBundleDisplayName</key><string>NEWS EDIT PRO</string>
  <key>CFBundleIdentifier</key><string>com.janam.newseditpro</string>
  <key>CFBundleExecutable</key><string>NEWS EDIT PRO</string>
  <key>CFBundleVersion</key><string>2.0.0</string>
  <key>CFBundleShortVersionString</key><string>2.0.0</string>
  <key>NSHumanReadableCopyright</key><string>JANAM TV</string>
  <key>LSMinimumSystemVersion</key><string>12.0</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>LSUIElement</key><false/>
  <key>NSNetworkVolumesUsageDescription</key>
    <string>Accesses NAS for media and playout.</string>
  <key>NSDesktopFolderUsageDescription</key>
    <string>Needs Desktop access for the stage folder.</string>
</dict></plist>
PLIST

# Remove quarantine so it opens without Gatekeeper warning
xattr -cr "$APP" 2>/dev/null || true

echo "Done. Opening NEWS EDIT PRO..."
osascript -e 'display notification "NEWS EDIT PRO.app is ready on Desktop. Drag to /Applications and Dock." with title "Done" sound name "Glass"' 2>/dev/null

# Open it immediately to confirm it works
open "$APP"
