#!/usr/bin/env python3
"""
NEWS EDIT PRO v2 - Timeline Automation Console
==============================================
Broadcast control panel for the news edit desk. Local web console.

v2 additions:
  QUALITY FILTER  - probes each shot (brightness + sharpness) and
                    avoids dark / blown-out / blurry shots when there
                    is enough good material
  DUPLICATE GUARD - visual fingerprint per shot; near-identical
                    scenes (same visuals in 2 files) used only once
  BULLETIN QUEUE  - stack several stories, TAKE ALL builds every
                    timeline in one run
  SETTINGS        - buffer, piece length, filters; saved to
                    pro_config.json, no code editing
  JOB HISTORY     - last 25 timelines logged to history.json

Cut engine (adaptive, never repeats a spot):
  PLENTY (>2.5x material) -> 3-4s pieces, shots interleaved
  SCARCE (1.2-2.5x)       -> longer pieces, one per shot
  SHORT  (<1.2x)          -> everything used once + alert

Run: python3 NewsEditPro.py   (or double-click NEWS_EDIT.command)
"""

import http.server
import secrets
import json
import math
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from datetime import datetime
from xml.sax.saxutils import escape as xml_escape

# One lock guards all shared on-disk state (config, history) because
# ThreadingHTTPServer handles requests concurrently.
_STATE_LOCK = threading.Lock()

# ---- AUTH (Supabase) -----------------------------------------------
# Sign-in is handled by Supabase Auth (email + password). This server
# needs only the project URL and the PUBLIC anon / publishable key -
# never put the service_role / secret key here.
# Config: supabase.json next to this script, or the environment
# variables SUPABASE_URL and SUPABASE_ANON_KEY.
#   no config at all         -> auth DISABLED (open access, dev mode)
#   config present but bad   -> auth ON, nobody can sign in (fail closed)
_SESSIONS = {}           # cookie token -> session dict
_SESS_LOCK = threading.Lock()
_SESSION_TTL = 8 * 3600  # 8 hours - one full broadcast day
_RECHECK_SEC = 15 * 60   # re-ask Supabase whether the user is still valid
_AUTH_WARNED = False
# SUPABASE_PATH is defined further down, next to BASE_DIR. It is only
# used at request time, after the whole module has loaded.


def _load_supabase():
    """Return the Supabase settings dict, or None if auth is disabled."""
    global _AUTH_WARNED
    cfg = None
    try:
        with open(SUPABASE_PATH) as f:
            cfg = json.load(f)
        if not isinstance(cfg, dict):
            raise ValueError("must be a JSON object")
    except FileNotFoundError:
        cfg = None
    except Exception as e:
        cfg = {"_error": f"supabase.json unreadable ({e})"}
    env_url = os.environ.get("SUPABASE_URL")
    env_key = os.environ.get("SUPABASE_ANON_KEY")
    if cfg is None and (env_url or env_key):
        cfg = {"url": env_url, "anon_key": env_key}
    if cfg is None:
        return None

    url = str(cfg.get("url") or "").strip().rstrip("/")
    key = str(cfg.get("anon_key") or "").strip()
    err = cfg.get("_error")
    if not err:
        u = urllib.parse.urlparse(url)
        local = u.hostname in ("127.0.0.1", "localhost", "::1")
        if not url or not key:
            err = "supabase url / anon_key missing"
        elif not (u.scheme == "https" or (u.scheme == "http" and local)):
            err = "supabase url must start with https://"
    if err and not _AUTH_WARNED:
        _AUTH_WARNED = True
        print(f"WARNING: {err} - login is blocked until it is fixed.")

    emails = cfg.get("allowed_emails") or []
    if isinstance(emails, str):
        emails = [emails]
    return {
        "url": "" if err else url,
        "anon_key": "" if err else key,
        "allowed_emails": [str(e).strip().lower() for e in emails
                           if str(e).strip()],
        "allowed_domain": str(cfg.get("allowed_domain") or "")
                          .strip().lower().lstrip("@"),
    }


def _email_allowed(cfg, email):
    """Optional extra allow-list on top of Supabase. Empty = any user
    that Supabase signs in is allowed."""
    email = (email or "").lower()
    emails, dom = cfg["allowed_emails"], cfg["allowed_domain"]
    if not emails and not dom:
        return True
    return email in emails or bool(dom and email.endswith("@" + dom))


def _sb_call(cfg, path, payload, timeout=10):
    """POST JSON to Supabase Auth -> (http_status, body_dict).
    status is None when Supabase could not be reached at all."""
    req = urllib.request.Request(
        cfg["url"] + path, json.dumps(payload).encode(),
        {"apikey": cfg["anon_key"], "Content-Type": "application/json"})

    def as_dict(raw):
        try:
            d = json.loads(raw or b"{}")
            return d if isinstance(d, dict) else {}
        except Exception:
            return {}
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, as_dict(r.read())
    except urllib.error.HTTPError as e:
        return e.code, as_dict(e.read())
    except Exception:
        return None, {}


def _sb_login(email, password):
    """Sign in with Supabase. Returns (session_dict, None) on success,
    or (None, message_for_the_login_page)."""
    cfg = _load_supabase()
    if not cfg or not cfg["url"]:
        return None, "Sign-in is not configured. Ask the administrator."
    status, body = _sb_call(cfg, "/auth/v1/token?grant_type=password",
                            {"email": email, "password": password})
    if status is None or status >= 500:
        return None, ("Cannot reach the sign-in service. "
                      "Check the internet connection.")
    if status == 429:
        return None, "Too many attempts. Wait a minute and try again."
    if status != 200 or not body.get("access_token"):
        txt = json.dumps(body).lower()
        if "email_not_confirmed" in txt or "email not confirmed" in txt:
            return None, "Email not confirmed. Check your inbox first."
        return None, "Incorrect email or password."
    user = body.get("user") or {}
    em = str(user.get("email") or email).lower()
    if not _email_allowed(cfg, em):
        return None, "This account is not authorised for NEWS EDIT PRO."
    now = time.time()
    return {"exp": now + _SESSION_TTL, "chk": now, "email": em,
            "rt": body.get("refresh_token") or "",
            "lock": threading.Lock()}, None


def _revalidate(sess):
    """Ask Supabase (refresh-token grant) whether this user still exists
    and is not banned/signed out. 4xx = no longer valid. Network errors
    or 5xx keep the session so a short internet drop never kicks editors
    out mid-bulletin; it just retries in a minute."""
    cfg = _load_supabase()
    if not cfg or not cfg["url"] or not sess["rt"]:
        return True
    status, body = _sb_call(cfg, "/auth/v1/token?grant_type=refresh_token",
                            {"refresh_token": sess["rt"]})
    if status == 200 and body.get("refresh_token"):
        sess["rt"] = body["refresh_token"]      # Supabase rotates it
        sess["chk"] = time.time()
        return True
    if status is None or status >= 500 or status == 429:
        sess["chk"] = time.time() - _RECHECK_SEC + 60
        return True
    return False


def _cookie_token(cookie_header):
    for part in (cookie_header or "").split(";"):
        k, _, v = part.strip().partition("=")
        if k.strip() == "nep_sess":
            return v.strip()
    return None


def _check_session(cookie_header):
    token = _cookie_token(cookie_header)
    if not token:
        return False
    with _SESS_LOCK:
        sess = _SESSIONS.get(token)
    if not sess:
        return False
    cfg = _load_supabase()
    if time.time() > sess["exp"] or (
            cfg and not _email_allowed(cfg, sess["email"])):
        with _SESS_LOCK:
            _SESSIONS.pop(token, None)
        return False
    if time.time() - sess["chk"] > _RECHECK_SEC:
        with sess["lock"]:                      # one recheck at a time
            if (time.time() - sess["chk"] > _RECHECK_SEC
                    and not _revalidate(sess)):
                with _SESS_LOCK:
                    _SESSIONS.pop(token, None)
                return False
    return True


def _new_session(sess):
    token = secrets.token_hex(32)
    now = time.time()
    with _SESS_LOCK:
        for k in [k for k, v in _SESSIONS.items() if v["exp"] < now]:
            del _SESSIONS[k]                    # tidy expired sessions
        _SESSIONS[token] = sess
    return token


def _auth_required(host):
    """Auth is required whenever Supabase is configured. No config =
    open access."""
    return _load_supabase() is not None

LOGIN_PAGE = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>NEWS EDIT PRO — Login</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#eef1f5;display:flex;align-items:center;
justify-content:center;min-height:100vh;
font-family:-apple-system,Helvetica,Arial,sans-serif}
.box{background:#fff;border:1px solid #d6dde7;border-radius:14px;
padding:36px 32px;width:340px;box-shadow:0 2px 12px rgba(0,0,0,.07)}
h1{font-size:18px;font-weight:700;color:#182230;margin-bottom:4px}
.sub{font-size:13px;color:#5b6b7d;margin-bottom:28px}
label{font-size:12px;font-weight:500;color:#5b6b7d;
letter-spacing:.06em;display:block;margin-bottom:5px}
input{width:100%;padding:10px 12px;border:1px solid #d6dde7;
border-radius:8px;font-size:15px;outline:none;margin-bottom:16px;
background:#f2f5f9;color:#182230}
input:focus{border-color:#e28c00;background:#fff}
button{width:100%;padding:12px;background:#f5a623;color:#241800;
font-size:15px;font-weight:700;border:none;border-radius:8px;
cursor:pointer;letter-spacing:.05em}
button:hover{background:#e08900}
.err{color:#cf3529;font-size:13px;margin-top:12px;text-align:center}
.logo{font-size:13px;font-weight:500;letter-spacing:.12em;
color:#5b6b7d;margin-bottom:6px}
</style></head><body>
<div class="box">
<div class="logo">JANAM TV</div>
<h1>NEWS EDIT PRO</h1>
<div class="sub">Sign in with your work email</div>
<form method="POST" action="/login">
<label>EMAIL</label>
<input name="u" type="email" autocomplete="username"
  autocapitalize="off" required>
<label>PASSWORD</label>
<input name="p" type="password" autocomplete="current-password" required>
<button type="submit">SIGN IN</button>
{ERROR}
</form>
</div></body></html>"""


FPS = 25
EVENT_NAME = "NEWS AUTO"
OUTPUT_DIR = os.path.expanduser("~/Desktop")
# When running inside a .app bundle, config/history live in Resources
BASE_DIR = (os.environ.get("NEWS_EDIT_BASE")
            or os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH  = os.path.join(BASE_DIR, "pro_config.json")
HISTORY_PATH = os.path.join(BASE_DIR, "history.json")
SUPABASE_PATH = os.path.join(BASE_DIR, "supabase.json")
SCENE_THRESHOLD = 0.30
PLENTY_RATIO = 2.5
SHORT_RATIO = 1.2
MAX_PROBES = 200         # cap analysis work per story (was 40; probing is
                         # now one ffmpeg call per shot, run in parallel)
SCENE_SCALE_W = 320      # scene detection runs on frames this wide
                         # (0 = full size, the old behaviour). Scores shift
                         # slightly - re-tune SCENE_THRESHOLD on your footage.
CPU = os.cpu_count() or 4
PROBE_WORKERS = max(2, min(6, CPU))      # parallel shot probes
DETECT_WORKERS = max(1, min(3, CPU // 2))  # parallel scene detections
RENDER_WORKERS = max(1, min(4, CPU // 3 or 1))  # parallel piece encodes
ANALYSIS_CACHE_PATH = os.path.join(BASE_DIR, "analysis_cache.json")
ANALYSIS_CACHE_VERSION = 2
ANALYSIS_CACHE_MAX = 4000


def snap(t):
    """Snap a time to the nearest exact frame of the 25 fps timeline."""
    return round(t * FPS) / FPS

DEFAULT_CONFIG = {
    "shot_min": 3,
    "shot_max": 4,
    "buffer_sec": 10,
    "quality_filter": True,
    "dup_filter": True,
    "dark_limit": 25,      # below = too dark (0-255)
    "bright_limit": 235,   # above = blown out
    "sharp_limit": 3.0,    # edge level below = extreme blur only
                           # (tuned for mobile footage)
    "qc_enabled": False,   # watch stage folder, auto-QC, auto-move
    "stage_dir": os.path.expanduser("~/Desktop/EXPORT_STAGE"),
    "playout_dir": "/Volumes/NAS809377/PLAYOUT/inbox/news",
    "qc_tolerance": 3,     # allowed duration difference (sec)
    "iv_min_shot": 4,      # interview: min sec on one camera
    "iv_wide_every": 20,   # interview: insert wide every N sec
    "iv_wide_len": 4,      # interview: wide shot length
}


def _sanitize_config(cfg):
    """Coerce every value to the expected type and clamp to sane ranges.
    Prevents a malformed settings POST (e.g. shot_min='abc' or
    shot_min > shot_max) from crashing the cut engine later."""
    out = dict(DEFAULT_CONFIG)
    for k, default in DEFAULT_CONFIG.items():
        v = cfg.get(k, default)
        try:
            v = type(default)(v)
        except (TypeError, ValueError):
            v = default
        out[k] = v
    out["shot_min"] = max(1, min(30, out["shot_min"]))
    out["shot_max"] = max(out["shot_min"], min(60, out["shot_max"]))
    out["buffer_sec"] = max(0, min(300, out["buffer_sec"]))
    out["qc_tolerance"] = max(0, min(60, out["qc_tolerance"]))

    def _norm_dir(p, default):
        p = str(p or "").strip()
        if not p:
            return default
        # Accept smb:// or afp:// server URLs and convert to the path
        # the share gets when mounted: smb://SERVER/SHARE/SUB ->
        # /Volumes/SHARE/SUB  (also strips ._smb._tcp.local names)
        m = re.match(r"^(?:smb|afp|cifs)://[^/]+/(.+)$", p, re.I)
        if m:
            p = "/Volumes/" + m.group(1)
        return p.rstrip("/") or default

    out["stage_dir"] = _norm_dir(out["stage_dir"],
                                 DEFAULT_CONFIG["stage_dir"])
    out["playout_dir"] = _norm_dir(out["playout_dir"],
                                   DEFAULT_CONFIG["playout_dir"])
    out["iv_min_shot"] = max(1, min(60, out["iv_min_shot"]))
    out["iv_wide_every"] = max(2, min(600, out["iv_wide_every"]))
    out["iv_wide_len"] = max(1, min(60, out["iv_wide_len"]))
    return out


def load_config():
    cfg = dict(DEFAULT_CONFIG)
    try:
        with open(CONFIG_PATH) as f:
            cfg.update(json.load(f))
    except Exception:
        pass
    return _sanitize_config(cfg)


def _atomic_write_json(path, obj):
    """Write JSON via temp file + rename so a crash mid-write can never
    leave a truncated/corrupt file behind."""
    d = os.path.dirname(path) or "."
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(obj, f, indent=2)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def save_config(cfg):
    keep = _sanitize_config(cfg)
    with _STATE_LOCK:
        _atomic_write_json(CONFIG_PATH, keep)


def load_history():
    try:
        with open(HISTORY_PATH) as f:
            h = json.load(f)
            return h if isinstance(h, list) else []
    except Exception:
        return []


def add_history(entry):
    with _STATE_LOCK:
        h = load_history()
        h.insert(0, entry)
        try:
            _atomic_write_json(HISTORY_PATH, h[:25])
        except Exception:
            pass                      # history is best-effort, never fatal


# ---------------- media helpers ----------------
def ffmpeg_path():
    for p in ("ffmpeg", "/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg"):
        found = shutil.which(p) or (p if os.path.exists(p) else None)
        if found:
            return found
    return None


_DUR_CACHE = {}


def clip_duration_seconds(path):
    """Duration in seconds, cached by (path, mtime) - the same clip is
    queried during pick, planning, and FCPXML build; probing it once
    saves 2 subprocess spawns per clip per story."""
    try:
        key = (path, os.path.getmtime(path))
    except OSError:
        key = (path, 0)
    if key in _DUR_CACHE:
        return _DUR_CACHE[key]
    result = None
    ff = ffmpeg_path()
    if ff:
        try:
            out = subprocess.run(
                [ff.replace("ffmpeg", "ffprobe"), "-v", "quiet",
                 "-show_entries", "format=duration", "-of", "csv=p=0", path],
                capture_output=True, text=True, timeout=20).stdout.strip()
            if out:
                result = float(out)
        except Exception:
            pass
    if result is None:
        try:
            out = subprocess.run(
                ["mdls", "-name", "kMDItemDurationSeconds", "-raw", path],
                capture_output=True, text=True, timeout=10).stdout.strip()
            if out and out != "(null)":
                result = float(out)
        except Exception:
            pass
    _DUR_CACHE[key] = result
    if len(_DUR_CACHE) > 64:
        _DUR_CACHE.pop(next(iter(_DUR_CACHE)))
    return result


# ---- persistent analysis cache (survives restarts) ----
_DISK_LOCK = threading.Lock()
_DISK_CACHE = None
_DISK_DIRTY = 0


def _file_key(path):
    try:
        st = os.stat(path)
        return f"{path}|{int(st.st_mtime)}|{st.st_size}"
    except OSError:
        return None


def _disk_load():
    global _DISK_CACHE
    if _DISK_CACHE is None:
        try:
            with open(ANALYSIS_CACHE_PATH) as f:
                d = json.load(f)
            if d.get("v") != ANALYSIS_CACHE_VERSION:
                d = {}
            _DISK_CACHE = d.get("items", {})
        except Exception:
            _DISK_CACHE = {}
    return _DISK_CACHE


def cache_get(kind, path, extra=""):
    fk = _file_key(path)
    if not fk:
        return None
    with _DISK_LOCK:
        return _disk_load().get(f"{kind}|{fk}|{extra}")


def cache_put(kind, path, value, extra=""):
    global _DISK_DIRTY
    fk = _file_key(path)
    if not fk:
        return
    with _DISK_LOCK:
        c = _disk_load()
        c[f"{kind}|{fk}|{extra}"] = value
        while len(c) > ANALYSIS_CACHE_MAX:
            c.pop(next(iter(c)))
        _DISK_DIRTY += 1


def cache_flush():
    """Write the cache to disk (atomic). Called after each analysis pass."""
    global _DISK_DIRTY
    with _DISK_LOCK:
        if not _DISK_DIRTY or _DISK_CACHE is None:
            return
        try:
            _atomic_write_json(ANALYSIS_CACHE_PATH,
                               {"v": ANALYSIS_CACHE_VERSION,
                                "items": _DISK_CACHE})
            _DISK_DIRTY = 0
        except Exception:
            pass                       # cache is best-effort


def _scene_cmd(ff, path, hw):
    vf = []
    if SCENE_SCALE_W:
        vf.append(f"scale={SCENE_SCALE_W}:-2:flags=fast_bilinear")
    vf.append(f"select='gt(scene,{SCENE_THRESHOLD})'")
    vf.append("showinfo")
    cmd = [ff, "-hide_banner", "-nostats"]
    if hw:
        cmd += ["-hwaccel", "videotoolbox"]
    return cmd + ["-i", path, "-an", "-sn", "-dn", "-vf", ",".join(vf),
                  "-f", "null", "-"]


def detect_shots(path, clip_dur, shot_min):
    ff = ffmpeg_path()
    if not ff or not clip_dur:
        return None
    extra = f"{SCENE_THRESHOLD}|{SCENE_SCALE_W}"
    times = cache_get("scene", path, extra)
    if times is None:
        r = None
        # Hardware decode on macOS (big win on phone HEVC/H.264); if the
        # codec is unsupported ffmpeg errors out and we retry in software.
        for hw in ((True, False) if sys.platform == "darwin" else (False,)):
            try:
                r = subprocess.run(_scene_cmd(ff, path, hw),
                                   capture_output=True, text=True,
                                   timeout=900)
            except Exception:
                r = None
                continue
            if r.returncode == 0:
                break
        if r is None or r.returncode != 0:
            return None
        times = [float(m) for m in re.findall(r"pts_time:([0-9.]+)",
                                              r.stderr)]
        cache_put("scene", path, times, extra)
    bounds = [0.0] + sorted(set(times)) + [clip_dur]
    shots = [(bounds[i], bounds[i + 1]) for i in range(len(bounds) - 1)
             if bounds[i + 1] - bounds[i] >= shot_min]
    return shots or None


def detect_shots_many(clips, shot_min, use_detection=True):
    """{clip: shots or None}, scene detection run in parallel."""
    import concurrent.futures as fut
    durs = {c: clip_duration_seconds(c) for c in clips}
    if not use_detection:
        return {c: None for c in clips}
    uniq = list(dict.fromkeys(clips))
    with fut.ThreadPoolExecutor(max_workers=DETECT_WORKERS) as ex:
        res = list(ex.map(lambda c: detect_shots(c, durs[c], shot_min),
                          uniq))
    cache_flush()
    return dict(zip(uniq, res))


# ---------------- v2: quality + duplicate analysis ----------------
def probe_luma(clip, t):
    """Average brightness (0-255) of a frame near t, or None."""
    ff = ffmpeg_path()
    if not ff:
        return None
    try:
        r = subprocess.run(
            [ff, "-ss", f"{t:.2f}", "-i", clip, "-frames:v", "1",
             "-vf", "signalstats,metadata=print:file=-",
             "-f", "null", "-"],
            capture_output=True, text=True, timeout=30)
        m = re.search(r"YAVG=([0-9.]+)", r.stdout + r.stderr)
        return float(m.group(1)) if m else None
    except Exception:
        return None


def probe_sharpness(clip, t):
    """Edge level of a frame near t - low means blurry. None on failure."""
    ff = ffmpeg_path()
    if not ff:
        return None
    try:
        r = subprocess.run(
            [ff, "-ss", f"{t:.2f}", "-i", clip, "-frames:v", "1",
             "-vf", "edgedetect,signalstats,metadata=print:file=-",
             "-f", "null", "-"],
            capture_output=True, text=True, timeout=30)
        m = re.search(r"YAVG=([0-9.]+)", r.stdout + r.stderr)
        return float(m.group(1)) if m else None
    except Exception:
        return None


def shot_signature(clip, t):
    """64-bit dHash fingerprint of the frame near t, or None."""
    ff = ffmpeg_path()
    if not ff:
        return None
    try:
        r = subprocess.run(
            [ff, "-ss", f"{t:.2f}", "-i", clip, "-frames:v", "1",
             "-vf", "scale=9:8,format=gray", "-f", "rawvideo", "-"],
            capture_output=True, timeout=30)
        raw = r.stdout
        if len(raw) < 72:
            return None
        bits = 0
        for row in range(8):
            for col in range(8):
                a = raw[row * 9 + col]
                b = raw[row * 9 + col + 1]
                bits = (bits << 1) | (1 if a > b else 0)
        return bits
    except Exception:
        return None


def _median(v):
    v = sorted(v)
    return v[len(v) // 2] if v else None


def probe_shot(clip, s, e):
    """ONE ffmpeg call per shot -> (signature, luma, sharpness).
    Samples 3 frames across (up to) 1 s centred in the shot and takes the
    median brightness / sharpness, so one odd frame (flash, motion blur)
    no longer rejects a good shot. The fingerprint uses the middle frame.
    Raw measurements are cached on disk (verdicts are applied later, so
    changing the dark/blur limits does not need a re-probe)."""
    ff = ffmpeg_path()
    if not ff:
        return (None, None, None)
    span = max(0.0, e - s)
    win = min(1.0, max(0.2, span - 0.1))
    t0 = max(s, (s + e) / 2 - win / 2)
    key = f"{t0:.2f}|{win:.2f}"
    hit = cache_get("probe", clip, key)
    if hit is not None:
        return tuple(hit)
    tmpd = tempfile.mkdtemp(prefix="nep_")
    fl, fe = os.path.join(tmpd, "l.txt"), os.path.join(tmpd, "e.txt")
    try:
        graph = (f"fps=3/{win:.3f},split=3[a][b][c];"
                 f"[a]signalstats,metadata=print:file={fl}[o1];"
                 f"[b]edgedetect,signalstats,metadata=print:file={fe}[o2];"
                 f"[c]scale=9:8,format=gray[o3]")
        # NOTE: -frames:v bounds the (single) rawvideo output; the two
        # metadata branches go to a null sink.
        cmd = [ff, "-hide_banner", "-nostats", "-loglevel", "error",
               "-ss", f"{t0:.2f}", "-t", f"{win:.2f}", "-i", clip,
               "-an", "-sn", "-dn", "-filter_complex", graph,
               "-map", "[o1]", "-f", "null", "-",
               "-map", "[o2]", "-f", "null", "-",
               "-map", "[o3]", "-f", "rawvideo", "pipe:1"]
        r = subprocess.run(cmd, capture_output=True, timeout=60)
        def ys(f):
            try:
                txt = open(f).read()
            except OSError:
                return []
            return [float(x) for x in re.findall(r"YAVG=([0-9.]+)", txt)]
        luma, sharp = _median(ys(fl)), _median(ys(fe))
        raw, sig = r.stdout, None
        nfr = len(raw) // 72
        if nfr >= 1:
            raw = raw[(nfr // 2) * 72:(nfr // 2) * 72 + 72]
            bits = 0
            for row in range(8):
                for col in range(8):
                    bits = (bits << 1) | (
                        1 if raw[row * 9 + col] > raw[row * 9 + col + 1]
                        else 0)
            sig = bits
        out = (sig, luma, sharp)
    except Exception:
        out = (None, None, None)
    finally:
        shutil.rmtree(tmpd, ignore_errors=True)
    if any(v is not None for v in out):
        cache_put("probe", clip, list(out), key)
    return out


def hamming(a, b):
    return bin(a ^ b).count("1")


# ---------------- v3: interview / multicam ----------------
ENV_STEP = 1.0 / FPS    # envelope resolution: one video frame (0.04 s)
ENV_SR = 48000          # audio is resampled to this before measuring
ENV_COARSE = 5          # coarse sync search works on 5-frame blocks
MAX_SYNC_LAG = 120      # search camera start offsets up to +/- sec


def audio_envelope(clip, max_sec=None):
    """Loudness list, one value per 0.1s. None if unavailable.
    max_sec bounds how much audio is decoded - a 30-min interview no
    longer requires reading 30 minutes per camera."""
    ff = ffmpeg_path()
    if not ff:
        return None
    limit = ["-t", str(int(max_sec))] if max_sec else []
    try:
        r = subprocess.run(
            [ff, "-i", clip, "-map", "a:0?", "-vn", *limit,
             "-af", f"aresample={ENV_SR},asetnsamples=n={int(ENV_SR * ENV_STEP)},"
             "astats=metadata=1:reset=1,"
             "ametadata=mode=print:key=lavfi.astats.Overall.RMS_level"
             ":file=-",
             "-f", "null", "-"],
            capture_output=True, text=True, timeout=900)
        vals = re.findall(r"RMS_level=(-?[0-9.]+|-inf)", r.stdout)
        env = [0.0 if v == "-inf" else 10 ** (float(v) / 20) for v in vals]
        return env if len(env) > 10 else None
    except Exception:
        return None


def _prep_transitions(v):
    lg = [math.log(x + 1e-6) for x in v]
    return [abs(lg[i + 1] - lg[i]) for i in range(len(lg) - 1)]


def _norm(v):
    m = sum(v) / len(v)
    return [x - m for x in v]


def _corr_scan(a, b, lags, ea, eb, guard):
    """Best (lag, score) of normalised a vs b over the given lags."""
    n = len(a)
    best, best_score = 0, -2.0
    for lag in lags:
        i0 = max(0, -lag)
        i1 = min(n, n - lag)
        sm = 0.0
        for i in range(i0 - i0 % guard + (guard if i0 % guard else 0),
                       i1, guard):
            sm += a[i] * b[i + lag]
        score = sm / (ea * eb) * guard
        if score > best_score:
            best_score, best = score, lag
    return best, best_score


def best_lag(ref, env):
    """Lag (samples of ENV_STEP) aligning env to ref, and match score 0..1.
    Correlates level-TRANSITIONS (log-domain changes): every mic in the
    room changes level at the same moments (speaker changes, pauses),
    so this stays correct even when two mics hear opposite loudness.
    Two passes: a coarse search on ENV_COARSE-frame blocks over the whole
    +/- MAX_SYNC_LAG range, then a frame-accurate search around the
    winner - frame precision without the cost of a full fine search."""
    a_raw, b_raw = _prep_transitions(ref), _prep_transitions(env)
    n = min(len(a_raw), len(b_raw))
    a, b = _norm(a_raw[:n]), _norm(b_raw[:n])
    ea = math.sqrt(sum(x * x for x in a)) or 1.0
    eb = math.sqrt(sum(x * x for x in b)) or 1.0
    max_lag = int(MAX_SYNC_LAG / ENV_STEP)

    # ---- coarse pass (block-averaged transitions)
    K = ENV_COARSE
    def block(v):
        m = len(v) // K
        return [sum(v[i * K:(i + 1) * K]) / K for i in range(m)]
    ca, cb = _norm(block(a_raw[:n])), _norm(block(b_raw[:n]))
    cea = math.sqrt(sum(x * x for x in ca)) or 1.0
    ceb = math.sqrt(sum(x * x for x in cb)) or 1.0
    cmax = max_lag // K
    cguard = max(1, len(ca) // 4000)
    c_lag, _ = _corr_scan(ca, cb, range(-cmax, cmax + 1), cea, ceb, cguard)

    # ---- fine pass: +/- 1.5 blocks around the coarse winner
    lo = max(-max_lag, c_lag * K - 3 * K // 2 - 1)
    hi = min(max_lag, c_lag * K + 3 * K // 2 + 1)
    guard = max(1, n // 6000)
    lag, score = _corr_scan(a, b, range(lo, hi + 1), ea, eb, guard)
    return lag, max(0.0, min(1.0, score))


def smooth(env, k=int(round(0.7 / ENV_STEP)) | 1):
    out = []
    for i in range(len(env)):
        lo, hi = max(0, i - k // 2), min(len(env), i + k // 2 + 1)
        out.append(sum(env[lo:hi]) / (hi - lo))
    return out


def parse_pattern(text, n_cams):
    """'1:6, W:4, 2:5' -> [(0,6),('W',4),(1,5)]. None if invalid/empty."""
    if not text or not str(text).strip():
        return None
    steps = []
    for tok in re.split(r"[,\s]+", str(text).strip()):
        if not tok:
            continue
        m = re.match(r"^([wW]|\d+)[:xX](\d+)$", tok)
        if not m:
            return None
        who, sec = m.group(1), int(m.group(2))
        if sec < 1:
            return None
        if who.lower() == "w":
            steps.append(("W", sec))
        else:
            idx = int(who) - 1
            if not (0 <= idx < n_cams):
                return None
            steps.append((idx, sec))
    return steps or None


def plan_interview(clips, wide_idx, edit_sec, cfg, pattern_text="",
                   insync=False):
    """Multicam interview cut. Returns (segments, info).
    segments = (clip, in_point_in_that_clip, length).
    insync=True -> cameras started together: audio sync is skipped
    (instant for pattern mode)."""
    n = len(clips)
    durs = [clip_duration_seconds(c) or 0 for c in clips]
    pattern_pre = parse_pattern(pattern_text, n)
    need_env = not (insync and pattern_pre)
    envs = [None] * n
    if need_env:
        # decode only what the edit needs (+ sync search margin),
        # all cameras in parallel instead of one after another
        cap = edit_sec + (0 if insync else 2 * MAX_SYNC_LAG) + 60
        import concurrent.futures as _fut
        with _fut.ThreadPoolExecutor(max_workers=min(4, n)) as ex:
            envs = list(ex.map(
                lambda c: audio_envelope(c, max_sec=cap), clips))
    have_audio = all(e is not None for e in envs)

    lags = [0.0] * n           # clip local time = ref time + lag
    scores = [1.0] + [0.0] * (n - 1)
    synced = False
    if insync:
        pass                    # editor says cams started together
    elif have_audio:
        for i in range(1, n):
            lag, score = best_lag(envs[0], envs[i])
            scores[i] = score
            if score > 0.30:           # confident match only
                lags[i] = -lag * ENV_STEP
                synced = True
            # low confidence (flat/quiet mic): assume same start
    # common coverage window in ref (camera 1) time.
    # BUGFIX: previously crashed with ValueError when NO camera duration
    # could be read (min() over an empty generator). Now degrades to the
    # requested duration.
    known = [durs[i] - lags[i] for i in range(n) if durs[i]]
    t0 = max(0.0, max(-lags[i] for i in range(n)))
    t1 = min(known) if known else t0 + edit_sec
    window = max(0.0, t1 - t0)
    total = min(edit_sec, int(window)) if window else edit_sec

    pattern = parse_pattern(pattern_text, n)
    same_audio = False
    if have_audio and not pattern and n >= 2:
        # identical waveforms on all cams -> speaker detect impossible
        same_audio = all(s > 0.985 for s in scores[1:])

    segments = []
    closes = [i for i in range(n) if i != wide_idx] or [wide_idx]

    if pattern or same_audio or not have_audio:
        # ------- TIMED PATTERN (user pattern, or default rotation)
        if not pattern:
            mn = cfg["iv_min_shot"]
            pattern = []
            for i, c in enumerate(closes):
                pattern.append((c, mn + 2))
                if (i + 1) % 2 == 0:
                    pattern.append(("W", cfg["iv_wide_len"]))
            if ("W", cfg["iv_wide_len"]) not in pattern:
                pattern.append(("W", cfg["iv_wide_len"]))
        mode_label = "timed pattern"
        t, pi = t0, 0
        while t - t0 < total:
            who, sec = pattern[pi % len(pattern)]
            idx = wide_idx if who == "W" else who
            take = min(sec, total - (t - t0))
            if take >= 1:
                segments.append((clips[idx],
                                 snap(t + lags[idx]), int(take)))
            t += take
            pi += 1
    else:
        # ------- AUDIO FOLLOW: cut to the camera whose mic speaks
        mode_label = "audio-follow"
        sm = [smooth(e) for e in envs]
        mn = cfg["iv_min_shot"]
        wide_every, wide_len = cfg["iv_wide_every"], cfg["iv_wide_len"]
        t = t0
        cur = closes[0]
        seg_start = t
        last_wide = t0
        while t - t0 < total:
            # loudest close cam at this ref moment
            best_cam, best_v = cur, -1.0
            for c in closes:
                li = int((t + lags[c]) / ENV_STEP)
                v = sm[c][li] if 0 <= li < len(sm[c]) else 0.0
                if v > best_v:
                    best_cam, best_v = c, v
            on_cur = t - seg_start
            want_wide = (t - last_wide) >= wide_every
            switch = (best_cam != cur and on_cur >= mn) or want_wide
            if switch:
                take = int(min(on_cur, total - (seg_start - t0)))
                if take >= 1:
                    segments.append((clips[cur],
                                     snap(seg_start + lags[cur]), take))
                if want_wide:
                    wl = int(min(wide_len, total - (t - t0)))
                    if wl >= 1:
                        segments.append((clips[wide_idx],
                                         snap(t + lags[wide_idx]), wl))
                    t += wl
                    last_wide = t
                cur = best_cam
                seg_start = t
            t += ENV_STEP
        tail = int(min(t - seg_start, total - (seg_start - t0)))
        if tail >= 1:
            segments.append((clips[cur],
                             snap(seg_start + lags[cur]), tail))

    # clamp in-points inside each source clip
    # (dict lookup instead of clips.index() - O(n) per segment before,
    # and index() returned the wrong entry if a path was added twice)
    dur_of = {c: durs[i] for i, c in enumerate(clips)}
    clamped = []
    for clip, inpt, ln in segments:
        d = dur_of.get(clip) or (inpt + ln)
        inpt = max(0.0, min(inpt, max(0.0, d - ln)))
        clamped.append((clip, snap(inpt), ln))
    segments = clamped

    placed = sum(s[2] for s in segments)
    info = {"mode_label": "interview: " + mode_label,
            "synced": synced, "same_audio": same_audio,
            "window": int(window), "placed": placed,
            "offsets": [round(l, 1) for l in lags]}
    return segments, info


def analyze_shots(shots, cfg):
    """shots: [(clip,s,e)] -> annotated list of dicts with quality/dup
    info. Only probes when ffmpeg exists; degrades gracefully.
    Probing runs in parallel (one ffmpeg call per shot); the duplicate
    check then runs in shot order so results match a sequential pass."""
    import concurrent.futures as fut
    have_ff = ffmpeg_path() is not None
    need = cfg["dup_filter"] or cfg["quality_filter"]
    probes = {}
    if have_ff and need:
        idxs = list(range(min(len(shots), MAX_PROBES)))
        with fut.ThreadPoolExecutor(max_workers=PROBE_WORKERS) as ex:
            res = list(ex.map(lambda i: probe_shot(*shots[i]), idxs))
        probes = dict(zip(idxs, res))
        cache_flush()
    out, sigs = [], []
    dropped_dup = dropped_bad = 0
    for i, (clip, s, e) in enumerate(shots):
        info = {"clip": clip, "s": s, "e": e, "bad": False, "dup": False}
        if i in probes:
            sig, luma, sharp = probes[i]
            if cfg["dup_filter"] and sig is not None:
                for prev in sigs:
                    if hamming(sig, prev) <= 8:
                        info["dup"] = True
                        dropped_dup += 1
                        break
                if not info["dup"]:
                    sigs.append(sig)
            if cfg["quality_filter"] and not info["dup"]:
                if luma is not None and (luma < cfg["dark_limit"]
                                         or luma > cfg["bright_limit"]):
                    info["bad"] = True
                elif sharp is not None and sharp < cfg["sharp_limit"]:
                    info["bad"] = True
                if info["bad"]:
                    dropped_bad += 1
        out.append(info)
    return out, dropped_dup, dropped_bad


# ---------------- adaptive cut engine ----------------
_ANALYSIS_CACHE = {}


def prepare_material(clips, cfg):
    """Detect shots + probe quality/dups once per clip set (cached).
    Returns (annotated, n_dup, n_bad)."""
    # key includes each file's size/mtime (re-exported media is never
    # served from cache) and the quality limits (changing them in
    # Settings must re-evaluate, not reuse the old verdict)
    key = (tuple(_file_key(c) or c for c in clips), cfg["shot_min"],
           cfg["quality_filter"], cfg["dup_filter"], cfg["dark_limit"],
           cfg["bright_limit"], cfg["sharp_limit"])
    if key in _ANALYSIS_CACHE:
        return _ANALYSIS_CACHE[key]
    shot_min = cfg["shot_min"]
    use_detection = ffmpeg_path() is not None
    raw = []
    detected = detect_shots_many(clips, shot_min, use_detection)
    for clip in clips:
        dur = clip_duration_seconds(clip)
        shots = detected.get(clip)
        if not shots:
            shots = [(0.0, dur if dur else 0)]
        for s, e in shots:
            if e - s >= shot_min:
                raw.append((clip, s, e))
    if not raw:
        result = ([], 0, 0)
    else:
        annotated, n_dup, n_bad = analyze_shots(raw, cfg)
        result = (annotated, n_dup, n_bad)
    _ANALYSIS_CACHE[key] = result
    if len(_ANALYSIS_CACHE) > 8:
        _ANALYSIS_CACHE.pop(next(iter(_ANALYSIS_CACHE)))
    return result


def parse_keep_ranges(text):
    """'10-25' / '0:10-0:25' / '10-25, 40-55' -> [(start,end)] or []."""
    out = []
    for tok in re.split(r"[,]+", str(text or "").strip()):
        tok = tok.strip()
        if not tok:
            continue
        m = re.match(r"^(.+?)\s*-\s*(.+)$", tok)
        if not m:
            return []
        a, b = parse_duration(m.group(1)), parse_duration(m.group(2))
        if a is None or b is None or b <= a:
            return []
        out.append((a, b))
    return out


def _subtract_ranges(s, e, ranges):
    """Cut [s,e) around protected ranges -> remaining sub-intervals."""
    pieces = [(s, e)]
    for a, b in ranges:
        nxt = []
        for ps, pe in pieces:
            if b <= ps or a >= pe:
                nxt.append((ps, pe))
            else:
                if ps < a:
                    nxt.append((ps, a))
                if b < pe:
                    nxt.append((b, pe))
        pieces = nxt
    return pieces


def plan_segments(clips, edit_sec, cfg, quality_action="use",
                  keeps=None):
    """Returns (segments, mode, stats). Never repeats a spot.
    keeps: {clip_path: [(start,end)]} - protected ranges placed whole
    at the front of the cut, never trimmed, and excluded from the
    auto-pieces so they are never repeated.
    quality_action: 'use'  -> flagged shots stay in (mobile footage OK)
                    'skip' -> flagged shots excluded (unless material
                              would run short, then they return + note)"""
    shot_min, shot_max = cfg["shot_min"], cfg["shot_max"]
    annotated, n_dup, n_bad = prepare_material(clips, cfg)
    if not annotated:
        return None, "BLOCK", {}

    usable_all = [a for a in annotated if not a["dup"]]

    def usable_len(a):
        return (a["e"] - a["s"]) - 0.2

    used_bad = False
    if quality_action == "skip":
        good = [a for a in usable_all if not a["bad"]]
        good_total = sum(usable_len(a) for a in good)
        if good_total >= edit_sec * SHORT_RATIO:
            pool = good
        else:
            pool = usable_all      # not enough good material
            used_bad = True
    else:                          # 'use' - editor accepted flagged shots
        pool = usable_all
        used_bad = n_bad > 0

    keeps = keeps or {}
    protected = []                       # (clip, start, length) - whole
    for clip in clips:
        for a, b in keeps.get(clip, []):
            protected.append((clip, float(a), int(b - a)))
    prot_total = sum(p[2] for p in protected)
    edit_sec = max(0, edit_sec - prot_total)   # auto fills the rest

    usable = []
    for a in pool:
        s0, e0 = a["s"] + 0.2, a["s"] + 0.2 + usable_len(a)
        for ps, pe in _subtract_ranges(s0, e0, keeps.get(a["clip"], [])):
            if pe - ps >= shot_min:
                usable.append((a["clip"], ps, pe - ps))
    if not usable and not protected:
        return None, "BLOCK", {"dup": n_dup, "bad": n_bad}
    if not usable:                        # only protected material
        return protected, "SHOTS", {"dup": n_dup, "bad": n_bad,
                                    "used_bad": False,
                                    "shots": len(protected)}
    total = sum(u[2] for u in usable)
    stats = {"dup": n_dup, "bad": n_bad, "used_bad": used_bad,
             "shots": len(usable)}

    # -------- SHORT
    if total <= edit_sec * SHORT_RATIO:
        segments, placed = [], 0
        for c, inpt, ln in usable:
            take = min(int(ln), max(0, edit_sec - placed))
            if take >= shot_min or (take > 0 and placed + take == edit_sec):
                segments.append((c, snap(inpt), int(take)))
                placed += int(take)
        return protected + segments, "FULL", stats

    # -------- SCARCE -> longer pieces, one per shot
    if total < edit_sec * PLENTY_RATIO:
        factor = edit_sec / total
        segs = []
        for c, inpt, ln in usable:
            want = max(shot_min, math.floor(ln * factor))
            segs.append([c, snap(inpt), min(int(ln), want), int(ln)])
        placed = sum(s[2] for s in segs)
        i = 0
        while placed < edit_sec and i < 500:
            s = segs[i % len(segs)]
            if s[2] < s[3]:
                s[2] += 1
                placed += 1
            i += 1
        while placed > edit_sec:
            s = max(segs, key=lambda x: x[2])
            if s[2] <= shot_min:
                break
            s[2] -= 1
            placed -= 1
        random.shuffle(segs)
        return protected + [(s[0], s[1], s[2]) for s in segs], \
            "LONG", stats

    # -------- PLENTY -> 3-4s pieces, interleaved shots
    shot_slots = []
    for c, inpt, ln in usable:
        slots, pos, end = [], inpt, inpt + ln
        while pos + shot_min <= end:
            seg = min(random.randint(shot_min, shot_max), end - pos)
            slots.append((c, snap(pos), int(seg)))
            pos += seg
        if slots:
            shot_slots.append(slots)
    random.shuffle(shot_slots)
    segments, remaining, level = [], edit_sec, 0
    while remaining >= shot_min:
        placed_any = False
        for slots in shot_slots:
            if remaining < shot_min:
                break
            if level < len(slots):
                c, inpt, seg = slots[level]
                seg = min(seg, remaining)
                if seg >= shot_min:
                    segments.append((c, inpt, seg))
                    remaining -= seg
                    placed_any = True
        level += 1
        if not placed_any:
            break
    if remaining > 0 and segments:
        c, inpt, seg = segments[-1]
        segments[-1] = (c, inpt, seg + remaining)
    return protected + segments, "SHOTS", stats


def plan_story_order(clips, edit_sec, cfg, keeps=None):
    """STORY ORDER: detects shot boundaries then places every shot in
    chronological order, trimming each proportionally to fill the
    requested duration. The narrative sequence is never shuffled.
    Protected keep-zones are placed whole and excluded from trimming.
    Returns (segments, mode, stats)."""
    shot_min = cfg.get("shot_min", 3)
    keeps = keeps or {}
    use_detection = ffmpeg_path() is not None

    # 1. Collect all shots in timeline order
    all_shots = []   # (clip, start, end) in original order
    detected = detect_shots_many(clips, shot_min, use_detection)
    for clip in clips:
        dur = clip_duration_seconds(clip)
        shots = detected.get(clip)
        if not shots:
            shots = [(0.0, dur if dur else edit_sec)]
        for s, e in shots:
            if e - s >= shot_min:
                all_shots.append((clip, s, e))

    if not all_shots:
        return None, "BLOCK", {"shots": 0}

    # 2. Remove protected zones from the pool (they go in whole)
    protected = []
    free_shots = []
    for clip, s, e in all_shots:
        hit = False
        for ks, ke in keeps.get(clip, []):
            if s >= ks and e <= ke:
                protected.append((clip, s, e - s))
                hit = True
                break
        if not hit:
            free_shots.append((clip, s, e))

    prot_total = sum(p[2] for p in protected)
    remaining_dur = max(0, edit_sec - prot_total)
    total_free = sum(e - s for _, s, e in free_shots)

    # 3. Trim each free shot proportionally to fill remaining_dur,
    #    but never below shot_min and never above its natural length.
    #    Keeps chronological order - no shuffling.
    segments = []
    if free_shots and total_free > 0:
        scale = remaining_dur / total_free
        leftover = remaining_dur
        for i, (clip, s, e) in enumerate(free_shots):
            natural = e - s
            if i == len(free_shots) - 1:
                # last shot absorbs rounding remainder
                take = max(shot_min, min(natural, int(leftover)))
            else:
                take = max(shot_min, min(natural, int(natural * scale)))
                take = min(take, int(leftover))
            if take >= shot_min and leftover > 0:
                segments.append((clip, snap(s + 0.15), take))
                leftover -= take
            if leftover <= 0:
                break

    # 4. Insert protected shots at their chronological position
    all_segs = []
    prot_idx = 0
    seg_idx = 0
    for clip, s, e in all_shots:
        matched_prot = next(
            (p for p in protected if p[0] == clip
             and abs(p[1] - s) < 0.5), None)
        if matched_prot:
            all_segs.append(matched_prot)
        elif seg_idx < len(segments):
            all_segs.append(segments[seg_idx])
            seg_idx += 1

    placed = sum(s[2] for s in all_segs)
    stats = {"shots": len(all_segs), "dup": 0, "bad": 0,
             "used_bad": False}
    return all_segs, "ORDER", stats


def plan_block_split(clips):
    """ONE BLOCK mode: cut at every detected shot change but keep EVERY
    shot at full length - nothing trimmed, nothing deleted, opening and
    end shots included. Falls back to whole clips if no ffmpeg."""
    segments = []
    detected = detect_shots_many(clips, 1, ffmpeg_path() is not None)
    for clip in clips:
        dur = clip_duration_seconds(clip)
        shots = detected.get(clip)
        if shots and dur:
            # ensure full coverage from 0 to end (detect_shots drops
            # sub-1s pieces; stitch boundaries back to continuous)
            bounds = sorted({snap(s) for s, e in shots} |
                            {0.0, snap(dur)})
            for i in range(len(bounds) - 1):
                ln = bounds[i + 1] - bounds[i]
                if ln >= 0.5:
                    segments.append((clip, bounds[i], snap(ln)))
        else:
            segments.append((clip, 0, dur if dur else 0))
    return segments, "SPLIT", {"shots": len(segments)}


# ---------------- FCPXML ----------------
def rational(seconds):
    return f"{int(round(seconds * FPS))}/{FPS}s"


def build_fcpxml(slug, clips, edit_sec, segments, ref_layer=False):
    slug = re.sub(r"[^A-Za-z0-9_-]", "_", slug).upper() or "NEWS"
    now = datetime.now()
    date_pfx = now.strftime("%d%m%y")            # 060726
    if re.match(r"^\d{6}_", slug):              # user already typed a date
        project_name = f"{slug}_{now:%H%M}"
    else:
        project_name = f"{date_pfx}_{slug}_{now:%H%M}"
    resources = [
        '    <format id="r1" name="FFVideoFormat1080i50" '
        f'frameDuration="1/{FPS}s" width="1920" height="1080" '
        'fieldOrder="upper first" colorSpace="1-1-1 (Rec. 709)"/>']
    rid_of = {}
    for i, clip in enumerate(clips):
        rid = f"r{i + 2}"
        rid_of[clip] = rid
        dur = clip_duration_seconds(clip) or edit_sec
        # BUGFIX: names went into XML raw - a clip called "LORRY & BUS"
        # or one with quotes produced invalid FCPXML. Escape attributes.
        name = xml_escape(os.path.splitext(os.path.basename(clip))[0],
                          {'"': "&quot;"})
        # BUGFIX: only spaces were %-encoded. '#', '&', '?' and
        # non-ASCII (Tamil) characters in paths broke the media-rep URL.
        src = "file://" + urllib.parse.quote(os.path.abspath(clip))
        resources.append(
            f'    <asset id="{rid}" name="{name}" start="0s" '
            f'duration="{rational(dur)}" hasVideo="1" hasAudio="1" '
            'format="r1" audioSources="1" audioChannels="2" '
            'audioRate="48000">\n'
            f'      <media-rep kind="original-media" src="{src}"/>\n'
            '    </asset>')
    spine, offset = [], 0
    if not segments:
        per, rem = math.ceil(edit_sec / len(clips)), edit_sec
        segments = []
        for clip in clips:
            take = min(per, rem)
            segments.append((clip, 0, take))
            rem -= take
            if rem <= 0:
                break
    multi = len(segments) > 1
    for si, (clip, inpt, seg) in enumerate(segments):
        base = os.path.splitext(os.path.basename(clip))[0]
        # number every piece (01_, 02_ ...) so the editor can shuffle
        # shots on the timeline and still see the original order
        label = f"{si + 1:02d}_{base}" if multi else base
        name = xml_escape(label, {'"': "&quot;"})
        if si == 0 and ref_layer:
            # Full original clip connected BELOW the cut (lane -1),
            # audio muted (-96dB). Child offset is parent-relative, so
            # matching the parent's own start pins it to timeline 0.
            ref_dur = clip_duration_seconds(clips[0]) or edit_sec
            ref_name = xml_escape(
                os.path.splitext(os.path.basename(clips[0]))[0],
                {'"': "&quot;"})
            spine.append(
                f'          <asset-clip ref="{rid_of[clip]}" '
                f'offset="{rational(offset)}" name="{name}" '
                f'start="{rational(inpt)}" duration="{rational(seg)}" '
                'audioRole="dialogue">\n'
                f'            <asset-clip ref="{rid_of[clips[0]]}" '
                f'lane="-1" offset="{rational(inpt)}" '
                f'name="REF_{ref_name}" start="0s" '
                f'duration="{rational(ref_dur)}">\n'
                '              <adjust-volume amount="-96dB"/>\n'
                '            </asset-clip>\n'
                '          </asset-clip>')
        else:
            spine.append(
                f'          <asset-clip ref="{rid_of[clip]}" '
                f'offset="{rational(offset)}" name="{name}" '
                f'start="{rational(inpt)}" duration="{rational(seg)}" '
                'audioRole="dialogue"/>')
        offset += seg
    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE fcpxml>
<fcpxml version="1.9">
  <resources>
{chr(10).join(resources)}
  </resources>
  <library>
    <event name="{EVENT_NAME}">
      <project name="{project_name}">
        <sequence format="r1" duration="{rational(offset)}" tcStart="0s" tcFormat="NDF" audioLayout="stereo" audioRate="48k">
          <spine>
{chr(10).join(spine)}
          </spine>
        </sequence>
      </project>
    </event>
  </library>
</fcpxml>
"""
    out = os.path.join(OUTPUT_DIR, project_name + ".fcpxml")
    with open(out, "w", encoding="utf-8") as f:
        f.write(xml)
    return out, project_name, offset


# ---------------- post-edit QC + playout drop ----------------
import collections

_QC_EVENTS = collections.deque(maxlen=30)
_QC_SEEN = {}          # path -> last size (copy-finished detection)


def _qc_log(status, name, detail):
    with _STATE_LOCK:
        _QC_EVENTS.appendleft({
            "when": datetime.now().strftime("%H:%M:%S"),
            "status": status, "name": name, "detail": detail})


def ffprobe_json(path):
    ff = ffmpeg_path()
    if not ff:
        return None
    try:
        r = subprocess.run(
            [ff.replace("ffmpeg", "ffprobe"), "-v", "quiet",
             "-print_format", "json", "-show_streams", "-show_format",
             path],
            capture_output=True, text=True, timeout=60)
        return json.loads(r.stdout or "{}")
    except Exception:
        return None


def expected_duration_for(filename):
    """Match export name (FCP uses the project name) against history
    so QC can compare real duration vs the planned one."""
    stem = os.path.splitext(os.path.basename(filename))[0]
    for h in load_history():
        if h.get("name") and stem.startswith(str(h["name"])):
            return h.get("total")
    return None


def qc_check(path, cfg):
    """Technical QC for the playout spec. Returns (passed, report).
    FAIL items block the move; WARN items don't."""
    report, fails = [], 0
    info = ffprobe_json(path)
    if not info:
        return False, ["FAIL: file unreadable (ffprobe missing/failed)"]
    vids = [s for s in info.get("streams", [])
            if s.get("codec_type") == "video"]
    auds = [s for s in info.get("streams", [])
            if s.get("codec_type") == "audio"]
    if not vids:
        return False, ["FAIL: no video stream"]
    v = vids[0]
    if v.get("codec_name") != "mpeg2video" or             "4:2:2" not in str(v.get("profile", "")):
        fails += 1
        report.append(f"FAIL: codec {v.get('codec_name')}"
                      f"/{v.get('profile')} - expected XDCAM HD422")
    else:
        report.append("OK: XDCAM HD422")
    if (v.get("width"), v.get("height")) != (1920, 1080):
        fails += 1
        report.append(f"FAIL: {v.get('width')}x{v.get('height')} "
                      "- expected 1920x1080")
    else:
        report.append("OK: 1920x1080")
    if v.get("field_order") in ("tt", "tb", "bt", "bb"):
        report.append("OK: interlaced")
    else:
        report.append("WARN: not flagged interlaced "
                      f"({v.get('field_order')})")
    if not auds:
        fails += 1
        report.append("FAIL: no audio")
    else:
        sr = auds[0].get("sample_rate")
        report.append("OK: audio present" if sr == "48000"
                      else f"WARN: audio {sr} Hz (expected 48000)")
    try:
        dur = float(info.get("format", {}).get("duration", 0))
    except (TypeError, ValueError):
        dur = 0
    exp = expected_duration_for(path)
    if exp:
        if abs(dur - exp) > cfg["qc_tolerance"]:
            fails += 1
            report.append(f"FAIL: duration {dur:.1f}s vs planned {exp}s")
        else:
            report.append(f"OK: duration {dur:.1f}s (planned {exp}s)")
    else:
        report.append(f"OK: duration {dur:.1f}s (no planned value)")
    luma = probe_luma(path, 0.2)
    if luma is not None and luma < 16:
        report.append("WARN: starts on black")
    return fails == 0, report


def _unique_dest(folder, name):
    dest = os.path.join(folder, name)
    stem, ext = os.path.splitext(name)
    k = 2
    while os.path.exists(dest):
        dest = os.path.join(folder, f"{stem}_{k}{ext}")
        k += 1
    return dest


def qc_and_move(path, cfg):
    name = os.path.basename(path)
    ok, report = qc_check(path, cfg)
    if ok:
        pdir = cfg["playout_dir"]
        # Guard: if the playout path is on /Volumes, the volume itself
        # must already be mounted - otherwise makedirs tries to create
        # a folder inside root-owned /Volumes and fails with Errno 13.
        parts = os.path.normpath(pdir).split(os.sep)
        if len(parts) > 2 and parts[1] == "Volumes":
            vol_root = os.sep + os.path.join(parts[1], parts[2])
            if not os.path.isdir(vol_root):
                _qc_log("FAIL", name,
                        f"QC passed, but the volume '{vol_root}' is not "
                        "mounted (or the playout path is wrong). Open the "
                        "real playout folder in Finder, press Opt+Cmd+C, "
                        "and paste it into Settings > Playout folder.")
                return False
        try:
            os.makedirs(pdir, exist_ok=True)
            dest = _unique_dest(pdir, name)
            shutil.move(path, dest)
            _qc_log("PASS", name, "; ".join(report) +
                    f" -> moved to {pdir}")
            return True
        except PermissionError:
            _qc_log("FAIL", name,
                    f"QC passed, but no permission to write into {pdir}. "
                    "Check the path in Settings and that the share is "
                    "mounted with write access.")
            return False
        except Exception as e:
            _qc_log("FAIL", name, f"QC passed but move failed: {e}")
            return False
    _qc_log("FAIL", name, "; ".join(report))
    return False


def qc_watcher():
    """Background thread: watches the stage folder. A file is judged
    'finished copying' when its size is unchanged between two polls -
    FCP/Compressor grow the file while exporting."""
    while True:
        try:
            cfg = load_config()
            if cfg["qc_enabled"] and os.path.isdir(cfg["stage_dir"]):
                for f in os.listdir(cfg["stage_dir"]):
                    if not f.lower().endswith((".mxf", ".mov", ".mp4")):
                        continue
                    p = os.path.join(cfg["stage_dir"], f)
                    try:
                        size = os.path.getsize(p)
                    except OSError:
                        continue
                    prev = _QC_SEEN.get(p)
                    _QC_SEEN[p] = size
                    if prev is not None and prev == size and size > 0:
                        _QC_SEEN.pop(p, None)
                        _qc_log("CHECK", f, "export finished - running QC")
                        qc_and_move(p, cfg)
        except Exception:
            pass
        # forget entries for files that disappeared
        for p in [k for k in _QC_SEEN if not os.path.exists(k)]:
            _QC_SEEN.pop(p, None)
        threading.Event().wait(3)


# ---------------- A-to-Z: render the cut ourselves ----------------
def _encode_piece(ff, i, clip, inpt, ln, tmp):
    p = os.path.join(tmp, f"p{i:03d}.mxf")
    ln = max(1.0 / FPS, ln)
    cmd = [ff, "-y", "-hide_banner", "-nostats",
           "-ss", f"{snap(inpt):.3f}", "-t", f"{snap(ln):.3f}",
           "-i", clip,
           "-vf", "scale=1920:1080:flags=bicubic,setsar=1,"
                  "fps=25,setfield=tff",
           # VFR phone footage: pad/trim audio so it stays locked to the
           # constant-frame-rate video produced by the fps filter
           "-af", "aresample=48000:async=1:first_pts=0",
           "-c:v", "mpeg2video", "-pix_fmt", "yuv422p",
           "-b:v", "50M", "-minrate", "50M", "-maxrate", "50M",
           "-bufsize", "36M",
           "-flags", "+ildct+ilme", "-top", "1",
           "-g", "12", "-bf", "2",
           "-c:a", "pcm_s16le", "-ar", "48000", "-ac", "2", p]
    r = subprocess.run(cmd, capture_output=True, timeout=900)
    if r.returncode != 0 or not os.path.exists(p):
        raise RuntimeError(f"piece {i+1} failed: "
                           + r.stderr.decode(errors="ignore")[-200:])
    return p


def render_segments(segments, out_path):
    """Cut + encode the planned pieces straight to broadcast spec:
    XDCAM HD422 50Mbps, 1920x1080 25i (top field first), PCM 48k.
    Pieces are encoded in parallel (software MPEG-2 4:2:2 can't use the
    Mac hardware encoder), then joined without re-encoding.
    Returns a list of warnings (empty = every piece is frame-exact)."""
    import concurrent.futures as fut
    ff = ffmpeg_path()
    if not ff:
        raise RuntimeError("ffmpeg required for auto-finish "
                           "(brew install ffmpeg)")
    tmp = tempfile.mkdtemp(prefix="newsedit_")
    warnings = []
    try:
        workers = max(1, min(RENDER_WORKERS, len(segments)))
        with fut.ThreadPoolExecutor(max_workers=workers) as ex:
            futs = [ex.submit(_encode_piece, ff, i, c, a, ln, tmp)
                    for i, (c, a, ln) in enumerate(segments)]
            parts = []
            try:
                for f in futs:          # keeps timeline order
                    parts.append(f.result())
            except Exception:
                for f in futs:
                    f.cancel()          # stop queued pieces on first error
                raise
        # sync check: each piece should be within 1 frame of its plan
        # (catches variable-frame-rate footage that drifted)
        ffprobe = ff.replace("ffmpeg", "ffprobe")
        for i, (pp, seg) in enumerate(zip(parts, segments)):
            try:
                d = float(subprocess.run(
                    [ffprobe, "-v", "quiet", "-show_entries",
                     "format=duration", "-of", "csv=p=0", pp],
                    capture_output=True, text=True,
                    timeout=30).stdout.strip())
                if abs(d - seg[2]) > 2.0 / FPS:
                    warnings.append(
                        f"piece {i+1}: {d:.2f}s rendered vs "
                        f"{seg[2]:.2f}s planned")
            except Exception:
                pass
        lst = os.path.join(tmp, "list.txt")
        with open(lst, "w") as f:
            for pp in parts:
                f.write(f"file '{pp}'\n")
        r = subprocess.run([ff, "-y", "-f", "concat", "-safe", "0",
                            "-i", lst, "-c", "copy", out_path],
                           capture_output=True, timeout=600)
        if r.returncode != 0 or not os.path.exists(out_path):
            raise RuntimeError("join failed: "
                               + r.stderr.decode(errors="ignore")[-200:])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return warnings


def notify_mac(msg):
    try:
        safe = str(msg).replace('"', "'")
        subprocess.run(["osascript", "-e",
                        f'display notification "{safe}" '
                        'with title "NEWS EDIT PRO" sound name "Glass"'],
                       capture_output=True, timeout=5)
    except Exception:
        pass


def auto_finish(req):
    """A-to-Z: plan the cut, RENDER it, QC it, drop it in the folder.
    No FCP involved. Returns the same shape as create_timeline plus
    a qc field."""
    clips = req.get("clips") or []
    if not clips:
        return {"error": "No clips."}
    _bad = _check_clips(clips)
    if _bad:
        return {"error": _bad}
    cfg = load_config()
    sec = parse_duration(req.get("dur"))
    if not sec or sec <= 0:
        return {"error": f"Invalid duration '{req.get('dur')}'."}
    if req.get("buf"):
        sec += cfg["buffer_sec"]
    keeps = {}
    for p, txt in (req.get("keep") or {}).items():
        r = parse_keep_ranges(txt)
        if r:
            keeps[str(p)] = r

    mode_req = req.get("mode")
    if mode_req == "block":
        segments, mode, stats = plan_block_split(clips)
    elif mode_req == "story_order":
        segments, mode, stats = plan_story_order(
            clips, sec, cfg, keeps=keeps)
    elif mode_req == "interview":
        if len(clips) < 2:
            return {"error": "Interview mode needs 2+ camera files."}
        try:
            wide_idx = int(req.get("wide", 0))
        except (TypeError, ValueError):
            wide_idx = 0
        wide_idx = wide_idx if 0 <= wide_idx < len(clips) else 0
        pat = req.get("pattern", "")
        if pat and parse_pattern(pat, len(clips)) is None:
            return {"error": f"Pattern '{pat}' invalid."}
        segments, iv = plan_interview(clips, wide_idx, sec, cfg, pat,
                                      insync=bool(req.get("insync")))
        mode, stats = "IV", {"shots": len(segments)}
    else:
        segments, mode, stats = plan_segments(
            clips, sec, cfg, req.get("quality_action") or "use",
            keeps=keeps)
    if not segments:
        segments = [(clips[0], 0,
                     int(clip_duration_seconds(clips[0]) or sec))]
        mode = "BLOCK"

    slug = re.sub(r"[^A-Za-z0-9_-]", "_",
                  req.get("slug", "STORY")).upper() or "NEWS"
    now = datetime.now()
    if re.match(r"^\d{6}_", slug):
        name = f"{slug}_{now:%H%M}"
    else:
        name = f"{now:%d%m%y}_{slug}_{now:%H%M}"
    os.makedirs(cfg["stage_dir"], exist_ok=True)
    out_path = _unique_dest(cfg["stage_dir"], name + ".mxf")
    placed = sum(s[2] for s in segments)
    add_history({"name": name, "total": int(placed),
                 "when": now.strftime("%d %b %H:%M")})
    try:
        sync_warn = render_segments(segments, out_path)
    except Exception as e:
        return {"error": f"Render failed: {e}"}
    moved = qc_and_move(out_path, cfg)     # QC + drop into playout
    if moved:
        notify_mac(f"DONE: {name}.mxf - QC PASS, dropped in playout "
                   "folder. Check Blaze in a minute.")
    else:
        notify_mac(f"ATTENTION: {name}.mxf - QC FAILED, file kept in "
                   "stage folder. See QC panel for the reason.")
    idx = {c: i for i, c in enumerate(clips)}
    segs_ui = [{"len": s[2], "ci": idx.get(s[0], 0)} for s in segments]
    return {"name": name, "total": int(placed),
            "mode_label": "AUTO FINISH - rendered, "
            + ("QC PASS, in playout folder" if moved
               else "QC FAILED - file kept in stage folder"),
            "segs": segs_ui, "alert": ("" if moved else
                      "QC failed - see the QC panel for the reason.")
            + (("  Sync check: " + "; ".join(sync_warn[:3]))
               if sync_warn else ""),
            "stats": stats}


# ---------------- drag-and-drop name resolution ----------------
VIDEO_EXTS = (".mxf", ".mov", ".mp4", ".mts", ".m4v", ".avi", ".mkv")


def resolve_names(names):
    """Browser drops give filenames only (no paths, by browser security).
    Spotlight (mdfind) maps each name back to its real path(s) on the
    mounted volumes. Returns {name: [{path, dur}, ...]}."""
    out = {}
    for name in list(names)[:20]:            # sane cap per drop
        safe = str(name).replace('"', "").replace("\\", "")
        matches = []
        try:
            r = subprocess.run(
                ["mdfind", f'kMDItemFSName == "{safe}"'],
                capture_output=True, text=True, timeout=15)
            for p in r.stdout.strip().split("\n"):
                if (p and p.lower().endswith(VIDEO_EXTS)
                        and os.path.exists(p)):
                    matches.append(p)
                if len(matches) >= 6:
                    break
        except Exception:
            pass
        out[name] = [{"path": p, "dur": clip_duration_seconds(p)}
                     for p in matches]
    return out


# ---------------- native file picker ----------------
def pick_clips():
    r = subprocess.run(
        ["osascript", "-e",
         'set fs to choose file with prompt '
         '"ADD MEDIA - select clip(s) for this story" '
         'with multiple selections allowed\n'
         'set plist to ""\n'
         'repeat with f in fs\n'
         '  set plist to plist & POSIX path of f & "\\n"\n'
         'end repeat\nreturn plist'],
        capture_output=True, text=True)
    if r.returncode != 0:
        return []
    return [p for p in r.stdout.strip().split("\n") if p.strip()]


# ---------------- web console ----------------
PAGE = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>NEWS EDIT PRO</title>
<style>
:root{--bg:#eef1f5;--panel:#ffffff;--panel2:#f2f5f9;--line:#d6dde7;
--txt:#182230;--dim:#5b6b7d;--amber:#e28c00;--amber2:#c67a00;
--green:#128a48;--red:#cf3529;--mono:'SF Mono',Menlo,monospace;}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--txt);
font:15px/1.5 -apple-system,'Helvetica Neue',sans-serif;
min-height:100vh;display:flex;justify-content:center;padding:16px 14px}
.console{width:100%;max-width:none}
.cols{display:grid;grid-template-columns:1.05fr .95fr;gap:14px;
align-items:start}
.col>*{margin-bottom:14px}
@media(max-width:900px){.cols{grid-template-columns:1fr}}
header{display:flex;align-items:center;gap:14px;border:1px solid var(--line);
background:linear-gradient(180deg,#ffffff,#f3f6fa);border-radius:10px;
padding:14px 20px;margin-bottom:14px;
box-shadow:0 1px 3px rgba(20,30,45,.06)}
.tally{width:12px;height:12px;border-radius:50%;background:var(--green);
box-shadow:0 0 10px var(--green)}
h1{font-size:19px;letter-spacing:.14em;font-weight:700}
h1 b{color:var(--amber)}
header .sub{margin-left:auto;font:11px var(--mono);color:var(--dim);
text-align:right}
.gear{cursor:pointer;font-size:18px;color:var(--dim);border:none;
background:none;padding:4px}
.gear:hover{color:var(--amber)}
.panel{border:1px solid var(--line);background:var(--panel);
border-radius:10px;padding:16px 20px;margin-bottom:12px;
box-shadow:0 1px 3px rgba(20,30,45,.05)}
.label{font:11px var(--mono);letter-spacing:.2em;color:var(--amber);
margin-bottom:8px;display:flex;justify-content:space-between}
input[type=text],input[type=number]{width:100%;background:var(--panel2);
color:var(--txt);border:1px solid var(--line);border-radius:6px;
padding:10px 12px;font:16px var(--mono);outline:none}
input:focus{border-color:var(--amber)}
.mediarow{display:flex;gap:10px;align-items:center;margin-bottom:8px}
button{cursor:pointer;border:1px solid var(--line);border-radius:6px;
background:var(--panel2);color:var(--txt);padding:9px 16px;font-size:14px}
button:hover{border-color:var(--amber)}
#cliplist{font:13px var(--mono);color:var(--dim)}
#cliplist .clip{display:flex;justify-content:space-between;
padding:6px 10px;border-bottom:1px solid var(--line)}
#cliplist .clip span:first-child{color:var(--txt)}
#cliplist .clip small{color:var(--dim);font-size:10px}
.keepin{width:110px;background:var(--panel2);color:var(--txt);
border:1px solid var(--line);border-radius:5px;padding:4px 6px;
font:11px var(--mono)}
.xbtn{padding:2px 8px;color:var(--red);border-color:var(--line);
font-size:12px}
#dropzone{border:2px dashed var(--line);border-radius:8px;padding:16px;
text-align:center;font:12px var(--mono);color:var(--dim);margin-top:8px;
transition:all .15s}
#dropzone.hot{border-color:var(--amber);color:#9a5f00;
background:#fff3df}
#choices button{margin:6px 6px 0 0;font-size:12px;padding:5px 10px}
.durrow{display:flex;gap:14px;align-items:center;flex-wrap:wrap}
#dur{width:120px;font-size:22px;text-align:center}
.modes{display:flex;gap:8px;margin-top:8px}
.mode{flex:1;text-align:center;padding:10px;border:1px solid var(--line);
border-radius:6px;background:var(--panel2);cursor:pointer;font-size:13px}
.mode small{display:block;color:var(--dim);font-size:11px;margin-top:2px}
.mode.on{border-color:var(--amber);background:#fff3df;color:#9a5f00}
.takerow{display:flex;gap:8px}
.take{flex:1;background:#f5a623;color:#241800;font-size:16px;
font-weight:800;letter-spacing:.1em;padding:15px;border:none;
border-radius:8px}
.take:hover{background:var(--amber2)}
.take:disabled{background:#cdd5df;color:#5b6b7d;cursor:wait}
.queuebtn{background:var(--panel2);color:var(--txt);font-weight:700;
border:1px solid var(--line);border-radius:8px;padding:0 18px}
#strip{display:flex;height:44px;border:1px solid var(--line);
border-radius:6px;overflow:hidden;background:var(--panel2);margin-top:10px}
#strip .seg{border-right:1px solid #ffffff;display:flex;align-items:center;
justify-content:center;font:10px var(--mono);color:#101418;min-width:14px}
#log{font:12px var(--mono);color:var(--dim);white-space:pre-wrap;
max-height:150px;overflow:auto}
.ok{color:var(--green)}.warn{color:var(--amber)}.err{color:var(--red)}
label.chk{font-size:13px;color:var(--dim);display:flex;gap:6px;
align-items:center}
#queue .qitem{display:flex;justify-content:space-between;gap:8px;
font:13px var(--mono);padding:6px 10px;border-bottom:1px solid var(--line)}
#queue .qitem button{padding:2px 8px;font-size:12px}
#settings{display:none}
#settings.open{display:block}
.setrow{display:flex;gap:14px;align-items:center;margin-bottom:8px;
flex-wrap:wrap}
.setrow label{font-size:13px;color:var(--dim);min-width:170px}
.setrow input[type=number]{width:90px}
#history{font:12px var(--mono);color:var(--dim);max-height:120px;
overflow:auto}
#history .h{display:flex;justify-content:space-between;padding:3px 0;
border-bottom:1px solid var(--line)}
@media(max-width:520px){header .sub{display:none}}
</style></head><body><div class="console">
<header><div class="tally" id="tally"></div>
<h1>NEWS EDIT <b>PRO</b></h1>
<div class="sub">1080i50 &middot; ProRes 422 TL<br>MXF XDCAM HD422 PLAYOUT</div>
<button class="gear" onclick="toggleSettings()" title="Settings">&#9881;</button>
<a href="/logout" style="font:11px var(--mono);color:var(--dim);
text-decoration:none;padding:4px 10px;border:1px solid var(--line);
border-radius:6px" title="Sign out">Sign out</a>
</header>

<div class="panel" id="settings"><div class="label">SETTINGS</div>
<div class="setrow"><label>Piece length min / max (sec)</label>
<input type="number" id="s_min" min="2" max="10">
<input type="number" id="s_max" min="2" max="15"></div>
<div class="setrow"><label>Buffer (sec)</label>
<input type="number" id="s_buf" min="0" max="60"></div>
<div class="setrow"><label class="chk"><input type="checkbox" id="s_q">
Quality filter (skip dark / blurry shots)</label></div>
<div class="setrow"><label class="chk"><input type="checkbox" id="s_d">
Duplicate guard (same visuals used once)</label></div>
<div class="setrow"><label>QC stage folder</label>
<div style="display:flex;gap:6px;flex:1">
<input type="text" id="s_stage" style="flex:1;min-width:160px">
<button onclick="pickFolder('s_stage')" title="Browse">&#128193; Choose</button>
</div></div>
<div class="setrow"><label>Playout folder</label>
<div style="display:flex;gap:6px;flex:1">
<input type="text" id="s_play" style="flex:1;min-width:160px">
<button onclick="pickFolder('s_play')" title="Browse">&#128193; Choose</button>
</div></div>
<div class="setrow"><label>QC duration tolerance (sec)</label>
<input type="number" id="s_tol" min="0" max="60"></div>
<button onclick="saveSettings()">Save settings</button></div>

<div class="cols"><div class="col">
<div class="panel"><div class="label">STORY</div>
<input type="text" id="slug" value="STORY" spellcheck="false">
<div style="font:11px var(--mono);color:var(--dim);margin-top:4px">
date prefix added automatically: <span id="dpfx"></span>_STORYNAME_TIME</div></div>

<div class="panel"><div class="label">MEDIA</div>
<div class="mediarow"><button onclick="pick()">+ Add clips</button>
<button onclick="clearClips()">Clear</button>
<span id="mediacount" style="font:12px var(--mono);color:var(--dim)"></span>
</div>
<div id="dropzone">DRAG &amp; DROP CLIPS HERE &nbsp;&middot;&nbsp;
or in Finder press &#8997;&#8984;C on clips, then &#8984;V here</div>
<div class="mediarow" style="margin-top:8px">
<textarea id="pastebox" rows="1" placeholder="or paste paths here (Finder: select clips, press Opt+Cmd+C, then paste) and click Add"
style="flex:1;background:var(--panel2);color:var(--txt);
border:1px solid var(--line);border-radius:6px;padding:8px;
font:12px var(--mono);resize:vertical"></textarea>
<button onclick="addPasted()">Add</button></div>
<div id="choices"></div>
<div id="cliplist"></div></div>

<div class="panel"><div class="label">DURATION &amp; CUT MODE</div>
<div class="durrow"><input type="text" id="dur" value="50">
<span style="font:12px var(--mono);color:var(--dim)">sec or M:SS</span>
<label class="chk"><input type="checkbox" id="buf"> + buffer</label>
<label class="chk"><input type="checkbox" id="reflayer" checked>
original clip muted on layer below</label>
</div>
<div class="modes">
<div class="mode on" id="mAuto" onclick="setMode('auto')">AUTO SHOTS
<small>adaptive, quality-checked, no repeats</small></div>
<div class="mode" id="mBlock" onclick="setMode('block')">ONE BLOCK
<small>whole clip, trim manually</small></div>
<div class="mode" id="mOrder" onclick="setMode('story_order')">STORY ORDER
<small>shots in sequence, no shuffle</small></div>
<div class="mode" id="mIv" onclick="setMode('interview')">INTERVIEW
<small>multicam, audio-follow / pattern</small></div>
</div>
<div id="ivopts" style="display:none;margin-top:10px">
<div class="setrow"><label>WIDE camera</label>
<select id="wideSel" style="background:var(--panel2);color:var(--txt);
border:1px solid var(--line);border-radius:6px;padding:8px"></select></div>
<div class="setrow"><label class="chk">
<input type="checkbox" id="insync"> cameras started together
(skip audio sync - instant)</label></div>
<div class="setrow"><label>Pattern (optional)</label>
<input type="text" id="pattern" placeholder="1:6, W:4, 2:5"
style="flex:1;min-width:180px"></div>
<div style="font:11px var(--mono);color:var(--dim)">
Empty pattern = AUDIO FOLLOW (cuts to the camera whose mic speaks).
Pattern example: camera 1 for 6s, wide 4s, camera 2 for 5s, repeating.
</div></div></div>

</div><div class="col">
<div class="panel"><div class="label">BULLETIN QUEUE
<span id="qcount"></span></div>
<div id="queue"></div>
<div class="mediarow" style="margin-top:8px">
<button onclick="addToQueue()">+ Add this story to queue</button>
<button onclick="clearQueue()">Clear queue</button></div></div>

<div class="takerow">
<button class="take" id="take" onclick="takeOne()">TAKE &nbsp;&#9654;&nbsp;
THIS STORY</button>
<button class="take" id="takeall" onclick="takeAll()"
style="background:var(--panel2);color:var(--amber);
border:1px solid var(--amber)">TAKE ALL (QUEUE)</button></div>
<button class="take" id="autofin" onclick="autoFinish()"
style="margin-top:8px;background:#128a48;color:#ffffff">
AUTO FINISH &nbsp;&#9654;&#9654;&nbsp; EDIT + EXPORT TO FOLDER (no FCP)
</button>
<div id="decide" style="display:none;gap:8px;margin-top:10px">
<button style="flex:1;border-color:var(--green);color:var(--green)"
onclick="decide('use')">USE THEM (mobile footage OK)</button>
<button style="flex:1;border-color:var(--red);color:var(--red)"
onclick="decide('skip')">SKIP THEM (cut around)</button></div>
<div id="strip" title="Planned pieces"></div>

</div></div>
<div class="panel"><div class="label">LOG</div>
<div id="log">Ready. Add clips and press TAKE.</div></div>

<div class="panel"><div class="label">POST-EDIT QC &rarr; PLAYOUT
<span id="qcstate"></span></div>
<div class="mediarow">
<button id="qcbtn" onclick="toggleQC()">QC WATCH: OFF</button>
<button onclick="qcFile()">QC one file now</button></div>
<div style="font:11px var(--mono);color:var(--dim);margin-bottom:6px"
id="qcpaths"></div>
<div id="qclog" style="font:12px var(--mono);color:var(--dim);
max-height:130px;overflow:auto"></div></div>

<div class="panel"><div class="label">RECENT TIMELINES</div>
<div id="history"></div></div>
</div>
<script>
let clips=[],mode='auto',queue=[],cfg={};
const colors=['#ffb020','#37d67a','#4da3ff','#ff7ad1','#b58cff','#ffd166',
'#6fe3e1','#ff8f5e'];
function esc(s){return String(s).replace(/&/g,'&amp;')
.replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function log(m,cls){const l=document.getElementById('log');
l.innerHTML+='\\n<span class="'+(cls||'')+'">'+esc(m)+'</span>';
l.scrollTop=l.scrollHeight;}
function setMode(m){mode=m;
document.getElementById('mAuto').classList.toggle('on',m=='auto');
document.getElementById('mBlock').classList.toggle('on',m=='block');
document.getElementById('mOrder').classList.toggle('on',m=='story_order');
document.getElementById('mIv').classList.toggle('on',m=='interview');
document.getElementById('ivopts').style.display=
m=='interview'?'block':'none';}
function toggleSettings(){
document.getElementById('settings').classList.toggle('open');}
async function pickFolder(inputId){
try{const r=await fetch('/pickfolder',{method:'POST',
headers:{'Content-Type':'application/json'},body:'{}' });
const d=await r.json();
if(d.path){document.getElementById(inputId).value=d.path;}}
catch(e){log('Folder picker error: '+e,'err');}}
async function loadSettings(){const r=await fetch('/settings');cfg=await r.json();
s_min.value=cfg.shot_min;s_max.value=cfg.shot_max;s_buf.value=cfg.buffer_sec;
s_q.checked=cfg.quality_filter;s_d.checked=cfg.dup_filter;
s_stage.value=cfg.stage_dir||'';s_play.value=cfg.playout_dir||'';
s_tol.value=cfg.qc_tolerance;
document.querySelector('label.chk[for]');}
async function saveSettings(){cfg.shot_min=+s_min.value;cfg.shot_max=+s_max.value;
cfg.buffer_sec=+s_buf.value;cfg.quality_filter=s_q.checked;
cfg.dup_filter=s_d.checked;
cfg.stage_dir=s_stage.value;cfg.playout_dir=s_play.value;
cfg.qc_tolerance=+s_tol.value;
await fetch('/settings',{method:'POST',headers:{'Content-Type':
'application/json'},body:JSON.stringify(cfg)});
log('Settings saved.','ok');toggleSettings();}
async function loadHistory(){const r=await fetch('/history');
const h=await r.json();document.getElementById('history').innerHTML=
h.map(x=>'<div class="h"><span>'+esc(x.name)+'</span><span>'+esc(x.total)+
's &middot; '+x.when+'</span></div>').join('')||'No timelines yet.';}
function addClip(p,name,dur){
if(clips.some(c=>c.path==p)){log('Already added: '+name,'warn');return;}
clips.push({path:p,name:name||p.split('/').pop(),dur:dur});render();}
async function pick(){const r=await fetch('/pick',{method:'POST'});
const d=await r.json();
/* APPEND, never replace - picking from a second folder must keep
   the clips already chosen from the first folder */
d.clips.forEach(c=>addClip(c.path,c.name,c.dur));}
function clearClips(){clips=[];
document.getElementById('choices').innerHTML='';render();}
function shortPath(p){const a=p.split('/');
return a.slice(Math.max(0,a.length-4),-1).join(' / ');}
const dz=document.getElementById('dropzone');
['dragover','dragenter'].forEach(ev=>dz.addEventListener(ev,e=>{
e.preventDefault();dz.classList.add('hot');}));
dz.addEventListener('dragleave',()=>dz.classList.remove('hot'));
dz.addEventListener('drop',async e=>{e.preventDefault();
dz.classList.remove('hot');
const names=[...e.dataTransfer.files].map(f=>f.name);
if(!names.length){log('Nothing droppable detected.','warn');return;}
log('Locating on disk: '+names.join(', ')+' \u2026');
try{const r=await fetch('/resolve',{method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify({names:names})});
const d=await r.json();
for(const n of names){const m=(d.resolved&&d.resolved[n])||[];
if(m.length==1){addClip(m[0].path,n,m[0].dur);log('+ '+n,'ok');}
else if(m.length==0){log(n+': not found by Spotlight - '+
'use + Add clips for this one','warn');}
else{log(n+': '+m.length+' matches - tap the right one below','warn');
showChoices(n,m);}}}
catch(err){log('Resolve error: '+err,'err');}});
document.addEventListener('paste',async e=>{
const txt=(e.clipboardData||window.clipboardData).getData('text');
if(!txt)return;
/* lines that look like file paths */
const lines=txt.split(/\\r?\\n/).map(s=>s.trim())
.filter(s=>s.startsWith('/'));
if(!lines.length)return;
e.preventDefault();
log('Verifying '+lines.length+' pasted path(s) \u2026');
try{const r=await fetch('/verify',{method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify({paths:lines})});
const d=await r.json();
d.verified.forEach(v=>{
if(v.ok){addClip(v.path,v.path.split('/').pop(),v.dur);
log('+ '+v.path.split('/').pop(),'ok');}
else{log('Not a video file or not found: '+v.path,'warn');}});}
catch(err){log('Verify error: '+err,'err');}});
async function addPasted(){
const box=document.getElementById('pastebox');
const lines=box.value.split(/\\r?\\n/).map(s=>s.trim())
.filter(s=>s.startsWith('/'));
if(!lines.length){log('Paste full paths starting with / first.','warn');
return;}
try{const r=await fetch('/verify',{method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify({paths:lines})});
const d=await r.json();
d.verified.forEach(v=>{if(v.ok){
addClip(v.path,v.path.split('/').pop(),v.dur);
log('+ '+v.path.split('/').pop(),'ok');}
else{log('Not found / not a video: '+v.path,'warn');}});
box.value='';}catch(err){log('Verify error: '+err,'err');}}
function showChoices(name,matches){
const box=document.getElementById('choices');
matches.forEach(m=>{const b=document.createElement('button');
b.textContent=name+'  @ '+shortPath(m.path);
b.title=m.path;
b.onclick=()=>{addClip(m.path,name,m.dur);b.remove();log('+ '+name,'ok');};
box.appendChild(b);});}
function removeAt(i){clips.splice(i,1);render();}
function setKeep(i,v){clips[i].keep=v;}
function render(){const c=document.getElementById('cliplist');
c.innerHTML=clips.map((x,i)=>'<div class="clip">'+
'<span title="'+esc(x.path)+'">CAM '+(i+1)+' &middot; '+esc(x.name)+
'<br><small>'+esc(shortPath(x.path))+'</small></span>'+
'<span style="display:flex;gap:6px;align-items:center">'+
'<input class="keepin" placeholder="keep 10-25" value="'+
esc(x.keep||'')+'" onchange="setKeep('+i+',this.value)">'+
(x.dur?Number(x.dur).toFixed(0)+'s':'--')+
'<button class="xbtn" title="remove this clip" '+
'onclick="removeAt('+i+')">&#10005;</button></span>'+
'</div>').join('');
document.getElementById('mediacount').textContent=
clips.length?clips.length+' clip(s)':'';
const s=document.getElementById('wideSel');
s.innerHTML=clips.map((x,i)=>'<option value="'+i+'">CAM '+(i+1)+' - '+
esc(x.name)+'</option>').join('');}
function strip(segs,total){const s=document.getElementById('strip');
s.innerHTML='';segs.forEach((g,i)=>{const d=document.createElement('div');
d.className='seg';const w=g.len/total*100;d.style.width=w+'%';
d.style.background=colors[g.ci%colors.length];
d.title=(i+1)+': '+g.len+'s';
d.textContent=w>3.5?g.len+'s':'';s.appendChild(d);});}
function currentStory(){return{slug:document.getElementById('slug').value,
dur:document.getElementById('dur').value,
buf:document.getElementById('buf').checked,mode:mode,
wide:+(document.getElementById('wideSel').value||0),
pattern:document.getElementById('pattern').value,
insync:document.getElementById('insync').checked,
ref_layer:document.getElementById('reflayer').checked,
keep:Object.fromEntries(clips.filter(c=>c.keep&&c.keep.trim())
.map(c=>[c.path,c.keep])),
clips:clips.map(c=>c.path)};}
function addToQueue(){if(!clips.length){log('Add clips first.','err');return;}
queue.push(currentStory());renderQueue();
log('Queued: '+queue[queue.length-1].slug,'ok');}
function clearQueue(){queue=[];renderQueue();}
function renderQueue(){const q=document.getElementById('queue');
q.innerHTML=queue.map((x,i)=>'<div class="qitem"><span>'+esc(x.slug)+' &middot; '+
esc(x.dur)+'</span><button onclick="queue.splice('+i+',1);renderQueue()">'+
'remove</button></div>').join('')||'';
document.getElementById('qcount').textContent=
queue.length?queue.length+' queued':'';}
async function runStory(body){
const r=await fetch('/create',{method:'POST',
headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
return await r.json();}
let _tmr=null,_t0=0;
function busy(on,txt){const b=document.getElementById('take'),
a=document.getElementById('takeall');b.disabled=a.disabled=on;
document.getElementById('tally').style.background=on?'#e28c00':'#128a48';
if(on){_t0=Date.now();clearInterval(_tmr);
_tmr=setInterval(()=>{b.textContent=(txt||'WORKING')+' '+
Math.round((Date.now()-_t0)/1000)+'s';},1000);
b.textContent=txt||'WORKING';}
else{clearInterval(_tmr);
b.innerHTML='TAKE &nbsp;\\u25B6&nbsp; THIS STORY';}}
let pendingBody=null;
function report(d){if(d.error){log(d.error,'err');return false;}
if(d.decision){log('[CHECK] '+d.msg,'warn');
document.getElementById('decide').style.display='flex';return false;}
log('[DONE] '+d.name+' \\u2014 '+d.total+'s \\u2014 '+d.mode_label,'ok');
if(d.stats)log('  shots:'+d.stats.shots+'  duplicates skipped:'+
(d.stats.dup||0)+'  flagged shots:'+(d.stats.bad||0)+
(d.stats.used_bad?' (included)':' (skipped)'),'');
if(d.alert)log('[ALERT] '+d.alert,'warn');
strip(d.segs,d.total);return true;}
async function decide(action){
document.getElementById('decide').style.display='none';
if(!pendingBody)return;pendingBody.quality_action=action;
busy(true,'BUILDING \\u2026');
try{report(await runStory(pendingBody));}
catch(e){log('Server error: '+e,'err');}
pendingBody=null;busy(false);loadHistory();}
async function autoFinish(){
if(!clips.length){log('No clips loaded.','err');return;}
if(!confirm('AUTO FINISH renders the cut by itself and drops the '+
'finished MXF in the folder - no FCP, no human check of visuals. '+
'Continue?'))return;
busy(true,'RENDERING A-TO-Z \u2026');
log('AUTO FINISH: planning + rendering + QC \u2026 (takes about '+
'1-2x the story duration)');
const body=currentStory();
try{const r=await fetch('/autofinish',{method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify(body)});
report(await r.json());}
catch(e){log('Server error: '+e,'err');}
busy(false);loadHistory();loadQC();}
async function takeOne(){if(!clips.length){log('No clips loaded.','err');
return;}busy(true,'ANALYZING \\u2026');log('Analyzing material \\u2026');
pendingBody=currentStory();
try{report(await runStory(pendingBody));}
catch(e){log('Server error: '+e,'err');}
busy(false);loadHistory();}
async function takeAll(){if(!queue.length){log('Queue is empty.','err');
return;}busy(true,'RUNNING QUEUE \\u2026');
for(let i=0;i<queue.length;i++){
log('--- Story '+(i+1)+'/'+queue.length+': '+queue[i].slug+' ---');
queue[i].quality_action='use';
try{report(await runStory(queue[i]));}
catch(e){log('Server error: '+e,'err');}}
queue=[];renderQueue();busy(false);loadHistory();
log('Bulletin complete. (flagged shots auto-included in queue mode)','ok');}
let qcOn=false;
async function loadQC(){try{const r=await fetch('/qc');const d=await r.json();
qcOn=d.enabled;
document.getElementById('qcbtn').textContent='QC WATCH: '+(qcOn?'ON':'OFF');
document.getElementById('qcbtn').style.borderColor=qcOn?'var(--green)':'';
document.getElementById('qcbtn').style.color=qcOn?'var(--green)':'';
document.getElementById('qcstate').textContent=qcOn?'watching':'';
document.getElementById('qcpaths').textContent=
'stage: '+d.stage+'   \u2192   playout: '+d.playout;
document.getElementById('qclog').innerHTML=d.events.map(e=>
'<div><span class="'+(e.status=='PASS'?'ok':e.status=='FAIL'?'err':'warn')
+'">['+esc(e.when)+' '+esc(e.status)+']</span> '+esc(e.name)+' - '
+esc(e.detail)+'</div>').join('')||'No QC activity yet.';}
catch(e){}}
async function toggleQC(){await fetch('/qc',{method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify({enabled:!qcOn})});loadQC();
log(qcOn?'QC watch stopped - normal manual workflow.':
'QC watch ON - export to the stage folder; passed files auto-move '+
'to playout.','ok');}
async function qcFile(){const r=await fetch('/pick',{method:'POST'});
const d=await r.json();
for(const c of d.clips){log('QC: '+c.name+' \u2026');
await fetch('/qc',{method:'POST',headers:{'Content-Type':
'application/json'},body:JSON.stringify({file:c.path})});}
loadQC();}
setInterval(loadQC,4000);
document.getElementById('dpfx').textContent=
new Date().toLocaleDateString('en-GB').replace(/\\//g,'').slice(0,6);
loadSettings();loadHistory();renderQueue();loadQC();
</script></body></html>"""


# ---- HARDENING (host/origin checks, rate limit, headers) ---------------
import ipaddress
import socket

_LOGIN_FAILS = {}            # ip -> [timestamps]
_LOGIN_MAX, _LOGIN_WINDOW = 5, 300
_EXTRA_HOSTS = set()


def _init_allowed_hosts():
    try:
        h = socket.gethostname().lower()
        _EXTRA_HOSTS.update({h, h + ".local", h.split(".")[0] + ".local"})
    except Exception:
        pass
    for h in os.environ.get("NEWS_EDIT_ALLOWED_HOSTS", "").split(","):
        if h.strip():
            _EXTRA_HOSTS.add(h.strip().lower())


def _host_name(host_header):
    h = (host_header or "").strip().lower()
    if h.startswith("["):                       # [::1]:8765
        return h[1:].split("]")[0]
    return h.rsplit(":", 1)[0] if h.count(":") == 1 else h


def _host_ok(host_header):
    """Blocks DNS-rebinding: only localhost, IP literals and this
    machine's own name are accepted in the Host header."""
    name = _host_name(host_header)
    if not name:
        return False
    if name == "localhost" or name in _EXTRA_HOSTS:
        return True
    try:
        ipaddress.ip_address(name)
        return True
    except ValueError:
        return False


def _rate_limited(ip):
    now = time.time()
    with _SESS_LOCK:
        lst = [t for t in _LOGIN_FAILS.get(ip, []) if now - t < _LOGIN_WINDOW]
        _LOGIN_FAILS[ip] = lst
        return len(lst) >= _LOGIN_MAX


def _note_login_fail(ip):
    with _SESS_LOCK:
        _LOGIN_FAILS.setdefault(ip, []).append(time.time())


def _check_clips(clips):
    """Clips must be real video files. Returns an error string or None."""
    if not isinstance(clips, list) or len(clips) > 60:
        return "Invalid clip list."
    for c in clips:
        if not isinstance(c, str) or not c.lower().endswith(VIDEO_EXTS) \
                or not os.path.isfile(c):
            return "Clip is missing or not a video file: " + str(c)[:120]
    return None


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def end_headers(self):
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy",
            "default-src 'self'; script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
            "frame-ancestors 'none'; form-action 'self'; base-uri 'none'")
        super().end_headers()

    def _guard(self, post=False):
        """403 on rebinding (bad Host) and cross-site requests."""
        host = self.headers.get("Host", "")
        bad = not _host_ok(host)
        if post and not bad:
            origin = self.headers.get("Origin")
            if origin and urllib.parse.urlparse(origin).netloc.lower() \
                    != host.lower():
                bad = True
            if self.headers.get("Sec-Fetch-Site", "same-origin") \
                    not in ("same-origin", "none"):
                bad = True
        if bad:
            self.send_error(403)
        return not bad

    def _secure_flag(self):
        return ("; Secure" if self.headers.get("X-Forwarded-Proto", "")
                .lower() == "https" else "")

    def _read_body(self, limit=1024 * 1024):
        """Parsed JSON body ({} if empty) or None after sending 400/413."""
        try:
            n = int(self.headers.get("Content-Length", 0))
        except ValueError:
            n = -1
        if n < 0 or n > limit:
            self._json({"error": "Bad or oversized request"}, 413)
            return None
        try:
            d = json.loads(self.rfile.read(n) or b"{}") if n else {}
            if not isinstance(d, dict):
                raise ValueError
            return d
        except Exception:
            self._json({"error": "Invalid JSON"}, 400)
            return None

    def do_HEAD(self):
        self.send_response(200)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _redirect(self, location):
        self.send_response(302)
        self.send_header("Location", location)
        self.end_headers()

    def _require_auth(self):
        """Returns True if request is allowed, False if login needed."""
        host = self.headers.get("Host", "")
        if not _auth_required(host):
            return True        # Supabase not configured - open access
        return _check_session(self.headers.get("Cookie", ""))

    def _json(self, obj, code=200):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if not self._guard():
            return
        if self.path == "/logout":
            tok = _cookie_token(self.headers.get("Cookie", ""))
            with _SESS_LOCK:
                _SESSIONS.pop(tok, None)
            self.send_response(302)
            self.send_header("Location", "/login")
            self.send_header("Set-Cookie",
                             "nep_sess=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if self.path == "/login":
            page = LOGIN_PAGE.replace("{ERROR}", "").encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(page)))
            self.end_headers()
            self.wfile.write(page)
            return
        if not self._require_auth():
            self._redirect("/login")
            return
        if self.path == "/":
            data = PAGE.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        elif self.path == "/settings":
            self._json(load_config())
        elif self.path == "/history":
            self._json(load_history())
        elif self.path == "/qc":
            cfg = load_config()
            with _STATE_LOCK:
                ev = list(_QC_EVENTS)
            self._json({"enabled": cfg["qc_enabled"],
                        "stage": cfg["stage_dir"],
                        "playout": cfg["playout_dir"], "events": ev})
        else:
            self.send_error(404)

    def do_POST(self):
        if not self._guard(post=True):
            return
        if self.path == "/login":
            ip = self.client_address[0]
            try:
                n = max(0, min(int(self.headers.get("Content-Length", 0)),
                               4096))
            except ValueError:
                n = 0
            raw = self.rfile.read(n).decode(errors="ignore")
            data = {k: v[0] for k, v in urllib.parse.parse_qs(
                raw, keep_blank_values=True).items()}
            email = data.get("u", "").strip().lower()
            if _rate_limited(ip):
                sess, err = None, ("Too many failed attempts. "
                                   "Wait 5 minutes and try again.")
            else:
                sess, err = (_sb_login(email, data.get("p", ""))
                             if email and data.get("p") else
                             (None, "Enter your email and password."))
                if not sess and email and data.get("p"):
                    _note_login_fail(ip)
            if sess:
                token = _new_session(sess)
                self.send_response(302)
                self.send_header("Location", "/")
                self.send_header("Set-Cookie",
                    f"nep_sess={token}; Max-Age={_SESSION_TTL}; "
                    "Path=/; HttpOnly; SameSite=Strict" + self._secure_flag())
                self.send_header("Content-Length", "0")
                self.end_headers()
            else:
                page = LOGIN_PAGE.replace(
                    "{ERROR}", f'<div class="err">{err}</div>').encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(page)))
                self.end_headers()
                self.wfile.write(page)
            return
        if not self._require_auth():
            self._json({"error": "Not authenticated"}, 401)
            return
        body = self._read_body()
        if body is None:
            return
        if self.path == "/pickfolder":
            try:
                r = subprocess.run(
                    ["osascript", "-e",
                     'set f to choose folder with prompt "Select folder"\n'
                     'return POSIX path of f'],
                    capture_output=True, text=True, timeout=60)
                if r.returncode == 0:
                    path = r.stdout.strip().rstrip("/")
                    self._json({"path": path})
                else:
                    self._json({"path": None})  # user cancelled
            except Exception as e:
                self._json({"path": None, "error": str(e)})
            return
        if self.path == "/verify":
            paths = [str(p).strip() for p in (body.get("paths") or [])][:30]
            out = []
            for p in paths:
                ok = (os.path.isfile(p)
                      and p.lower().endswith(VIDEO_EXTS))
                out.append({"path": p, "ok": ok,
                            "dur": clip_duration_seconds(p) if ok else None})
            self._json({"verified": out})
            return
        if self.path == "/resolve":
            self._json({"resolved": resolve_names(body.get("names") or [])})
            return
        if self.path == "/pick":
            paths = pick_clips()
            self._json({"clips": [{"path": p, "name": os.path.basename(p),
                                   "dur": clip_duration_seconds(p)}
                                  for p in paths]})
        elif self.path == "/settings":
            cfg = load_config()
            cfg.update(body)
            save_config(cfg)
            self._json({"ok": True})
        elif self.path == "/qc":
            cfg = load_config()
            if "enabled" in body:
                cfg["qc_enabled"] = bool(body["enabled"])
                os.makedirs(cfg["stage_dir"], exist_ok=True)
                save_config(cfg)
            if body.get("file"):
                p = str(body["file"])
                if p.lower().endswith((".mxf", ".mov", ".mp4")) \
                        and os.path.isfile(p):
                    qc_and_move(p, cfg)
                else:
                    _qc_log("FAIL", os.path.basename(p), "file not found")
            self._json({"ok": True, "enabled": cfg["qc_enabled"]})
        elif self.path == "/autofinish":
            try:
                self._json(auto_finish(body))
            except Exception as e:
                self._json({"error": str(e)})
        elif self.path == "/create":
            try:
                self._json(create_timeline(body))
            except Exception as e:
                self._json({"error": str(e)})
        else:
            self.send_error(404)


def parse_duration(text):
    t = str(text).strip().lower().replace("sec", "").replace("s", "")
    if not t:
        return None
    if ":" in t:
        p = t.split(":")
        try:
            return (int(p[0]) * 60 + int(float(p[1])) if len(p) == 2 else
                    int(p[0]) * 3600 + int(p[1]) * 60 + int(float(p[2])))
        except (ValueError, IndexError):
            return None
    try:
        return int(float(t))
    except ValueError:
        return None


MODE_LABELS = {
    "IV": "interview",
    "ORDER": "story order - chronological, proportionally trimmed",
    "SPLIT": "shot-by-shot, full length, nothing trimmed",
    "SHOTS": "3-4s pieces, quality-checked shots",
    "LONG": "longer pieces (limited material, no repeats)",
    "FULL": "all material used once (short on visuals)",
    "BLOCK": "single block per clip",
}


def create_timeline(req):
    clips = req.get("clips") or []
    if not clips:
        return {"error": "No clips."}
    _bad = _check_clips(clips)
    if _bad:
        return {"error": _bad}
    cfg = load_config()
    sec = parse_duration(req.get("dur"))
    if not sec or sec <= 0:
        return {"error": f"Invalid duration '{req.get('dur')}'."}
    if req.get("buf"):
        sec += cfg["buffer_sec"]

    segments, mode, stats = (None, "BLOCK", {})
    iv_info = None
    keeps = {}
    for p, txt in (req.get("keep") or {}).items():
        r = parse_keep_ranges(txt)
        if r:
            keeps[str(p)] = r
    if req.get("mode") == "block":
        segments, mode, stats = plan_block_split(clips)
    elif req.get("mode") == "story_order":
        segments, mode, stats = plan_story_order(
            clips, sec, cfg, keeps=keeps)
    elif req.get("mode") == "interview":
        if len(clips) < 2:
            return {"error": "Interview mode needs 2+ camera files."}
        try:
            wide_idx = int(req.get("wide", 0))
        except (TypeError, ValueError):
            wide_idx = 0        # junk from client must not 500 the API
        wide_idx = wide_idx if 0 <= wide_idx < len(clips) else 0
        pat = req.get("pattern", "")
        if pat and parse_pattern(pat, len(clips)) is None:
            return {"error": f"Pattern '{pat}' invalid. "
                    "Example: 1:6, W:4, 2:5"}
        segments, iv_info = plan_interview(
            clips, wide_idx, sec, cfg, pat,
            insync=bool(req.get("insync")))
        mode = "IV"
        stats = {"shots": len(segments)}
    elif req.get("mode") == "auto":
        action = req.get("quality_action")
        if action not in ("use", "skip"):
            # analysis first; if flagged shots found, ask the editor
            _, n_dup, n_bad = prepare_material(clips, cfg)
            if n_bad > 0:
                return {"decision": True, "bad": n_bad, "dup": n_dup,
                        "msg": (f"{n_bad} shot(s) look dark or blurry "
                                "(mobile footage often triggers this). "
                                "Use them or skip them?")}
            action = "use"
        segments, mode, stats = plan_segments(clips, sec, cfg, action,
                                              keeps=keeps)

    out, name, placed = build_fcpxml(req.get("slug", "STORY"),
                                     clips, sec, segments,
                                     ref_layer=bool(req.get("ref_layer")))
    alert = ""
    if mode in ("SPLIT", "ORDER"):
        sec = placed  # these modes use natural lengths
    if placed < sec:
        alert = (f"Only {placed}s of material available for {sec}s - "
                 "timeline is shorter. Add clips or extend visuals.")
    if req.get("mode") == "auto" and not ffmpeg_path():
        alert = (alert + " | " if alert else "") + \
            "ffmpeg not installed - even spread, no quality checks. " \
            "Install: brew install ffmpeg"

    idx = {c: i for i, c in enumerate(clips)}
    segs_ui = ([{"len": s[2], "ci": idx[s[0]]} for s in segments]
               if segments else [{"len": placed, "ci": 0}])
    mode_label = (iv_info["mode_label"] if iv_info
                  else MODE_LABELS[mode])
    if iv_info:
        if iv_info["same_audio"]:
            alert = (alert + " | " if alert else "") + \
                "All cameras share the same audio - speaker detection " \
                "not possible, timed pattern used."
        elif iv_info["synced"]:
            alert = (alert + " | " if alert else "") + \
                f"Cameras auto-synced by audio (offsets " \
                f"{iv_info['offsets']}s)."
    add_history({"name": name, "total": placed,
                 "when": datetime.now().strftime("%d %b %H:%M")})
    try:
        subprocess.Popen(["open", out])
    except OSError:
        pass          # file is on the Desktop either way
    return {"name": name, "total": placed, "mode_label": mode_label,
            "segs": segs_ui, "alert": alert, "stats": stats}


def _ensure_desktop_access():
    """
    Touch the Desktop and stage folder at startup so macOS resolves the
    'allow/don't allow' TCC permission immediately.  If the user clicks
    Allow, the folder is created and the server starts normally.
    If they click Don't Allow the folder won't be accessible — we fall
    back to the app's own directory so the server still starts.
    """
    desktop = os.path.expanduser("~/Desktop")
    stage   = os.path.expanduser("~/Desktop/EXPORT_STAGE")
    try:
        os.listdir(desktop)          # triggers the TCC prompt / grant
        os.makedirs(stage, exist_ok=True)
        print(f"Stage folder ready: {stage}")
    except PermissionError:
        fallback = os.path.join(BASE_DIR, "EXPORT_STAGE")
        os.makedirs(fallback, exist_ok=True)
        print(f"Desktop access denied — using fallback stage: {fallback}")
        # Update running config to fallback path
        cfg = load_config()
        cfg["stage_dir"] = fallback
        save_config(cfg)


def main():
    import argparse
    parser = argparse.ArgumentParser(description="NEWS EDIT PRO Console")
    parser.add_argument("--host", default="127.0.0.1",
                        help="Bind host. Use 0.0.0.0 for network access.")
    parser.add_argument("--port", type=int, default=8765,
                        help="Port (default 8765).")
    parser.add_argument("--no-browser", action="store_true",
                        help="Skip auto-opening the browser.")
    args = parser.parse_args()

    _ensure_desktop_access()   # resolve macOS Desktop TCC permission now

    host, port = args.host, args.port
    _init_allowed_hosts()
    if host not in ("127.0.0.1", "localhost", "::1") \
            and _load_supabase() is None \
            and os.environ.get("NEWS_EDIT_ALLOW_OPEN") != "1":
        print("\nREFUSING TO START: network mode needs Supabase login.")
        print("Create supabase.json (see supabase.example.json), or set")
        print("NEWS_EDIT_ALLOW_OPEN=1 to knowingly run without login.")
        sys.exit(1)
    for _ in range(20):
        try:
            srv = http.server.ThreadingHTTPServer((host, port), Handler)
            break
        except OSError:
            port += 1
    else:
        print("No free port found.")
        sys.exit(1)

    threading.Thread(target=qc_watcher, daemon=True).start()

    if host not in ("127.0.0.1", "localhost", "::1") \
            and _load_supabase() is None:
        print("")
        print("  WARNING: Supabase login is not configured - anyone on this")
        print("  network can use the console. Copy supabase.example.json to")
        print("  supabase.json and fill in your project URL and anon key.")

    if host == "0.0.0.0":
        import socket
        try:
            lan = socket.gethostbyname(socket.gethostname())
        except Exception:
            lan = "YOUR_SERVER_IP"
        print("")
        print("NEWS EDIT PRO  —  NETWORK MODE")
        print("=" * 44)
        print(f"  This machine : http://127.0.0.1:{port}")
        print(f"  Other editors: http://{lan}:{port}")
        print("")
        print("  Share the second URL with all editors.")
        print("  Ctrl+C to stop.")
        print("")
        if not args.no_browser:
            threading.Timer(0.6,
                lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
    else:
        url = f"http://127.0.0.1:{port}"
        print(f"NEWS EDIT PRO console: {url}  (Ctrl+C to quit)")
        if not args.no_browser:
            threading.Timer(0.6, lambda: webbrowser.open(url)).start()

    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")


if __name__ == "__main__":
    main()
