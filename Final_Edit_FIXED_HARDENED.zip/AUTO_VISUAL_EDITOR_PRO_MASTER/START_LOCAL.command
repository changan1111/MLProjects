#!/bin/bash
# NEWS EDIT PRO — Start on THIS machine only
cd "$(dirname "$0")"
python3 NewsEditPro.py --host 127.0.0.1 --port 8765
