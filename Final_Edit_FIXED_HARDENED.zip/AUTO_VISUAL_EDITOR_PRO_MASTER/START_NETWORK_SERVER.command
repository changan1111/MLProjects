#!/bin/bash
# NEWS EDIT PRO — Network mode: serves ALL editors on LAN
cd "$(dirname "$0")"
python3 NewsEditPro.py --host 0.0.0.0 --port 8765
