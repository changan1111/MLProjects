// Plain BM25 over pre-tokenised documents, with an inverted index.
export class BM25 {
  constructor(docs, k1 = 1.2, b = 0.75) {
    this.k1 = k1; this.b = b; this.N = docs.length;
    this.len = docs.map((d) => d.length);
    this.avg = this.len.reduce((s, x) => s + x, 0) / (this.N || 1) || 1;
    this.post = new Map(); // term -> [[docIdx, tf], ...]
    docs.forEach((d, i) => {
      const tf = new Map();
      for (const t of d) tf.set(t, (tf.get(t) || 0) + 1);
      for (const [t, c] of tf) {
        if (!this.post.has(t)) this.post.set(t, []);
        this.post.get(t).push([i, c]);
      }
    });
  }
  idf(term) {
    const n = this.post.get(term)?.length || 0;
    return Math.log(1 + (this.N - n + 0.5) / (n + 0.5));
  }
  // Returns { scores: Float64Array, max } where max is the theoretical best for this query (for 0..1 normalisation).
  score(queryTokens) {
    const scores = new Float64Array(this.N);
    let max = 0;
    for (const t of new Set(queryTokens)) {
      const list = this.post.get(t);
      const idf = this.idf(t);
      max += idf * (this.k1 + 1);
      if (!list) continue;
      for (const [i, tf] of list) {
        const norm = tf + this.k1 * (1 - this.b + (this.b * this.len[i]) / this.avg);
        scores[i] += (idf * tf * (this.k1 + 1)) / norm;
      }
    }
    return { scores, max };
  }
}
