import React, { useMemo, useState } from 'react';
import Papa from 'papaparse';
import weights from '../../config/weights.json';
import synonyms from '../../config/synonyms.json';
import sampleDefects from '../../data/sample-defects.csv?raw';
import sampleQueries from '../../data/sample-queries.csv?raw';
import { parseDefects, parseWorkbook } from '../ingest/jira.js';
import { buildEngine } from '../search/engine.js';
import { loadFb, saveFb, mark, verdictOf, withAliases, demoteMap, tune } from '../search/feedback.js';
import './styles.css';

const FIELDS = [
  ['summary', 'Summary'], ['description', 'Description'], ['resolution', 'Resolution / root cause'],
  ['comments', 'Comments'], ['component', 'Component'], ['aliases', 'Learned from your feedback'],
];
const BANDS = { 'Strong match': ['strong'], 'Close match': ['close'], Possible: ['possible'], 'No match': ['none'] };
const T = weights.thresholds;
const bandOf = (score) => (score >= T.strong ? 'Strong match' : score >= T.close ? 'Close match' : 'Possible');
const readFile = (f) => new Promise((r) => { const x = new FileReader(); x.onload = () => r(x.result); x.readAsText(f); });
const readDefects = async (f) => (/\.xlsx?$/i.test(f.name) ? parseWorkbook(await f.arrayBuffer()) : parseDefects(await readFile(f)));
async function loadMany(files) {
  const list = [], bad = [], seen = new Set();
  let dupes = 0;
  for (const f of files) {
    try {
      for (const d of await readDefects(f)) {
        if (seen.has(d.key)) { dupes++; continue; }
        seen.add(d.key); list.push(d);
      }
    } catch { bad.push(f.name); }
  }
  return { list, bad, dupes, n: files.length };
}
const CHIPS = [['tester', 'Tested by'], ['build', 'Build'], ['fixVersion', 'Fix version'], ['affectsVersion', 'Found in'], ['status', 'Status'], ['assignee', 'Assignee'], ['priority', 'Priority']];
const pc = (n) => `${(n * 100).toFixed(0)}%`;

function Bar({ breakdown }) {
  return (
    <>
      <div className="track" role="img" aria-label="Match contribution by field">
        {FIELDS.map(([f]) => <div key={f} className="seg" style={{ width: `${(breakdown[f] || 0) * 100}%`, background: `var(--${f})` }} />)}
      </div>
      <div className="parts">
        {FIELDS.map(([f, label]) => (breakdown[f] || 0) > 0.002 && <span key={f}><i style={{ background: `var(--${f})` }} />{label} {((breakdown[f] || 0) * 100).toFixed(1)}%</span>)}
      </div>
    </>
  );
}

function Match({ hit, band, q, fb, onMark }) {
  const v = verdictOf(fb, q, hit.defect.key);
  return (
    <div className="match" style={{ '--c': `var(--${BANDS[band][0]})` }}>
      <div className="mhead"><span>{hit.defect.key} · {hit.defect.summary}</span><b>{pc(hit.score)}</b></div>
      <div className="chips">{CHIPS.map(([k, l]) => hit.defect[k] && <span key={k}><b>{l}</b> {hit.defect[k]}</span>)}</div>
      <Bar breakdown={hit.breakdown} />
      <div className="fb">
        <button className={`yes ${v === 'yes' ? 'on' : ''}`} aria-pressed={v === 'yes'} onClick={() => onMark(q, hit, v === 'yes' ? 'clear' : 'yes')}>✓ Duplicate</button>
        <button className={`no ${v === 'no' ? 'on' : ''}`} aria-pressed={v === 'no'} onClick={() => onMark(q, hit, v === 'no' ? 'clear' : 'no')}>✗ Not a match</button>
      </div>
    </div>
  );
}

export default function App() {
  const [corpus, setCorpus] = useState([]);
  const [queries, setQueries] = useState([]);
  const [text, setText] = useState('');
  const [results, setResults] = useState([]);
  const [filter, setFilter] = useState(null);
  const [note, setNote] = useState('');
  const [fb, setFb] = useState(loadFb);
  const [busy, setBusy] = useState(false);
  // Matches scoring below this are hidden (not worth the tester's time). Adjustable and remembered in this browser.
  const [minShow, setMinShow] = useState(() => { try { const v = parseFloat(localStorage.getItem('defectMatch.minShow')); return v > 0 && v < 1 ? v : T.possible; } catch { return T.possible; } });
  const [minText, setMinText] = useState(String(Math.round(minShow * 100)));
  const changeMin = (txt) => { // let the box be typed freely; apply only valid values
    setMinText(txt);
    const n = Number(txt);
    if (txt.trim() !== '' && n >= 1 && n <= 95) { setMinShow(n / 100); try { localStorage.setItem('defectMatch.minShow', String(n / 100)); } catch { /* ignore */ } }
  };
  const W = useMemo(() => (fb.tuned ? { ...weights, fields: { ...weights.fields, ...fb.tuned.fields }, bigramWeight: fb.tuned.bigramWeight } : weights), [fb.tuned]);
  const report = (r) => setNote(`${r.n} file(s) read${r.dupes ? `, ${r.dupes} repeated defect key(s) skipped` : ''}${r.bad.length ? `. Could not read: ${r.bad.join(', ')}` : ''}`);
  const engine = useMemo(() => (corpus.length ? buildEngine(withAliases(corpus, fb), W, synonyms) : null), [corpus, fb.confirmed, W]);
  const update = (next, msg) => { setFb(next); saveFb(next); if (msg) setNote(msg); };
  const onMark = (q, hit, verdict) => update(mark(fb, q, hit, verdict), 'Feedback saved. Click Find matches to re-rank using it.');
  const doTune = () => { setBusy(true); setTimeout(() => { const r = tune(corpus, weights, synonyms, fb.confirmed); setBusy(false); if (r.tuned) update({ ...fb, tuned: r.tuned }, `Tuned on ${r.after.n} confirmed pairs: MRR ${r.before.mrr.toFixed(2)} → ${r.after.mrr.toFixed(2)}. Click Find matches to apply.`); else setNote(`No better weights found on ${r.before.n} pairs (MRR ${r.before.mrr.toFixed(2)}).`); }, 30); };
  const exportFb = () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(fb, null, 2)], { type: 'application/json' })); a.download = 'defect-match-feedback.json'; a.click(); };
  const importFb = async (file) => { try { const inc = JSON.parse(await readFile(file)); const uniq = (a, b) => [...new Map([...a, ...b].map((e) => [`${e.qid}|${e.matchKey}`, e])).values()]; update({ ...fb, confirmed: uniq(fb.confirmed, inc.confirmed || []), rejected: uniq(fb.rejected, inc.rejected || []), tuned: inc.tuned || fb.tuned }, 'Feedback imported.'); } catch { setNote('Could not read that feedback file.'); } };

  const loadSample = () => { setCorpus(parseDefects(sampleDefects)); setQueries(parseDefects(sampleQueries)); setResults([]); };
  const run = () => {
    const typed = text.split('\n').map((s) => s.trim()).filter(Boolean).map((s, i) => ({ key: `Q${i + 1}`, summary: s, description: '' }));
    const list = [...queries, ...typed].slice(0, 100);
    setResults(list.map((q) => { const hits = engine.search(q, { excludeKey: q.key, demote: demoteMap(q, fb, engine) }); return { q, hits }; }));
    setFilter(null);
  };
  const view = results.map((r) => { const vis = r.hits.filter((h) => h.score >= minShow); return { ...r, vis, band: vis.length ? bandOf(vis[0].score) : 'No match' }; });
  const exportCsv = () => {
    const rows = view.map(({ q, vis, band }) => ({ query: q.key, query_summary: q.summary, best_match: vis[0]?.defect.key || '', match_summary: vis[0]?.defect.summary || '', similarity: vis[0] ? pc(vis[0].score) : '', match_tester: vis[0]?.defect.tester || '', match_build: vis[0]?.defect.build || '', match_fix_version: vis[0]?.defect.fixVersion || '', match_status: vis[0]?.defect.status || '', match_assignee: vis[0]?.defect.assignee || '', verdict: band }));
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([Papa.unparse(rows)], { type: 'text/csv' })); a.download = 'defect-matches.csv'; a.click();
  };
  const count = (b) => view.filter((r) => r.band === b).length;
  const shown = filter ? view.filter((r) => r.band === filter) : view;

  return (
    <div className="wrap">
      <header>
        <div><h1>Defect Match</h1><p className="sub">Find the closest existing defects for new ones, and see which fields drove each match.</p></div>
      </header>
      <div className="grid">
        <aside className="panel">
          <h3>1. Load defects</h3>
          <label className="drop"><b>Jira export (CSV, JSON, XML or Excel, multiple files OK)</b><small>{corpus.length ? `${corpus.length} defects loaded` : 'Click to choose one or more files to search in'}</small>
            <input type="file" multiple accept=".csv,.json,.txt,.xml,.xlsx,.xls" onChange={async (e) => { if (e.target.files.length) { const r = await loadMany(e.target.files); setCorpus(r.list); setResults([]); report(r); } }} /></label>
          <label className="drop"><b>New defects (CSV, JSON, XML or Excel, optional)</b><small>{queries.length ? `${queries.length} new defects loaded` : 'Or type them below'}</small>
            <input type="file" multiple accept=".csv,.json,.txt,.xml,.xlsx,.xls" onChange={async (e) => { if (e.target.files.length) { const r = await loadMany(e.target.files); setQueries(r.list); report(r); } }} /></label>
          {note && <p className="sub" role="status">{note}</p>}
          {corpus.length > 0 && corpus.length < 50 && <p className="warn" role="alert">Only {corpus.length} defects loaded. Match scores are unreliable below about 50. Load more files.</p>}
          <h3 style={{ marginTop: 14 }}>2. Add new defect summaries</h3>
          <textarea placeholder="One summary per line, up to 100" value={text} onChange={(e) => setText(e.target.value)} />
          <div className="btns">
            <button className="primary" disabled={!engine} onClick={run}>Find matches</button>
            <button className="ghost" onClick={loadSample}>Load sample (20 + 8)</button>
            <button className="ghost" disabled={!results.length} onClick={exportCsv}>Export CSV</button>
          </div>
          <div className="legend">{FIELDS.slice(0, 5).map(([f, l]) => <span key={f}><i style={{ background: `var(--${f})` }} />{l} {pc(weights.fields[f] / Object.values(weights.fields).reduce((a, b) => a + b, 0))}</span>)}</div>
          <div className="learn">
            <b>Learning</b> <span>{fb.confirmed.length} confirmed · {fb.rejected.length} rejected{fb.tuned ? ' · weights tuned' : ''}</span>
            <div className="btns">
              <button className="ghost" disabled={busy || !corpus.length || fb.confirmed.length < 5} onClick={doTune} title="Needs at least 5 confirmed duplicates">{busy ? 'Tuning…' : 'Tune from feedback'}</button>
              <button className="ghost" onClick={exportFb}>Export feedback</button>
              <label className="ghost filebtn">Import<input type="file" accept=".json" hidden onChange={(e) => e.target.files[0] && importFb(e.target.files[0])} /></label>
              {fb.tuned && <button className="ghost" onClick={() => update({ ...fb, tuned: null }, 'Weights reset to defaults.')}>Reset tuning</button>}
            </div>
          </div>
        </aside>

        <main>
          {!results.length ? (
            <div className="empty"><b>No results yet</b><br />Click “Load sample”, then “Find matches” to try it with 20 sample defects and 8 new ones.</div>
          ) : (
            <>
              <div className="tiles">
                {Object.keys(BANDS).map((b) => (
                  <button key={b} className={`tile t-${BANDS[b][0]} ${filter === b ? 'on' : ''}`} onClick={() => setFilter(filter === b ? null : b)} aria-pressed={filter === b}>
                    <b>{count(b)}</b>{b}
                  </button>
                ))}
              </div>
              <p className="sub" style={{ margin: '0 0 12px', fontSize: 13 }}>
                Percentages are similarity scores, not the chance of a duplicate. Review each candidate yourself.{' '}
                <label>Hide matches below <input type="number" min="1" max="95" value={minText} onChange={(e) => changeMin(e.target.value)} style={{ width: 56 }} />%</label>
              </p>
              {shown.map(({ q, hits, vis, band }) => (
                <div className="card" key={q.key + q.summary} style={{ '--c': `var(--${BANDS[band][0]})` }}>
                  <div className="q">
                    <div><b>{q.key}</b><span className="pill">{band}</span><br />{q.summary}{q.description && <><br /><small>{q.description}</small></>}</div>
                    <div className="pct">{vis[0] ? pc(vis[0].score) : '—'}</div>
                  </div>
                  {vis[0] ? <Match hit={vis[0]} band={band} q={q} fb={fb} onMark={onMark} /> : <p className="sub">No similar defect found{hits[0] ? ` above ${pc(minShow)}` : ''}.</p>}
                  {vis.length > 1 && (
                    <details><summary>Other matches ({Math.min(2, vis.length - 1)})</summary>
                      {vis.slice(1, 3).map((h) => <Match key={h.defect.key} hit={h} band={bandOf(h.score)} q={q} fb={fb} onMark={onMark} />)}
                    </details>
                  )}
                </div>
              ))}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
