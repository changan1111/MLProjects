import { buildEngine } from './engine.js';

// Feedback = what the user told the tool. It is stored in this browser (localStorage) and can be exported/imported.
const KEY = 'defectMatch.feedback.v1';
export const emptyFb = () => ({ confirmed: [], rejected: [], tuned: null });

export function loadFb() {
  try { const r = JSON.parse(localStorage.getItem(KEY)); return r && r.confirmed ? { ...emptyFb(), ...r } : emptyFb(); } catch { return emptyFb(); }
}
export function saveFb(fb) { try { localStorage.setItem(KEY, JSON.stringify(fb)); } catch { /* storage can be blocked */ } }

export const qid = (q) => `${q.key}|${q.summary}`;
export const qText = (q) => `${q.summary || ''} ${q.description || ''}`.trim();

export function verdictOf(fb, q, key) {
  const id = qid(q);
  if (fb.confirmed.some((e) => e.qid === id && e.matchKey === key)) return 'yes';
  if (fb.rejected.some((e) => e.qid === id && e.matchKey === key)) return 'no';
  return null;
}

// verdict: 'yes' | 'no' | 'clear'
export function mark(fb, q, hit, verdict) {
  const id = qid(q), key = hit.defect.key;
  const rest = (list) => list.filter((e) => !(e.qid === id && e.matchKey === key));
  const entry = { qid: id, text: qText(q), matchKey: key };
  return {
    ...fb,
    confirmed: verdict === 'yes' ? [...rest(fb.confirmed), entry] : rest(fb.confirmed),
    rejected: verdict === 'no' ? [...rest(fb.rejected), entry] : rest(fb.rejected),
  };
}

// Learning 1: a confirmed duplicate teaches the tool the wording that was used for that defect.
// The confirmed query's text is added to the matched defect as an extra searchable field.
export function withAliases(corpus, fb) {
  const m = new Map();
  for (const c of fb.confirmed) m.set(c.matchKey, `${m.get(c.matchKey) || ''} ${c.text}`.trim());
  return corpus.map((d) => (m.has(d.key) ? { ...d, aliases: m.get(d.key) } : d));
}

// Learning 2: a rejected match is pushed down for the same or a very similar query.
export function demoteMap(query, fb, engine) {
  const qt = new Set(engine.tokens(qText(query)));
  const out = new Map();
  for (const r of fb.rejected) {
    const rt = new Set(engine.tokens(r.text));
    let inter = 0;
    for (const t of qt) if (rt.has(t)) inter++;
    const jaccard = inter / (qt.size + rt.size - inter || 1);
    if (r.qid === qid(query) || jaccard >= 0.5) out.set(r.matchKey, 0.5);
  }
  return out;
}

// How well a weight setting ranks the confirmed pairs (higher MRR = right defect nearer the top).
export function evaluate(corpus, weights, synonyms, pairs) {
  const engine = buildEngine(corpus, { ...weights, topK: 100000 }, synonyms);
  let rr = 0, hit1 = 0, n = 0;
  for (const p of pairs) {
    if (!corpus.some((d) => d.key === p.matchKey)) continue;
    const rank = engine.search({ key: p.qid, summary: p.text, description: '' }).findIndex((r) => r.defect.key === p.matchKey) + 1;
    n++; if (rank === 1) hit1++; if (rank > 0) rr += 1 / rank;
  }
  return { n, mrr: n ? rr / n : 0, recall1: n ? hit1 / n : 0 };
}

// Learning 3: coarse search over field weights using the confirmed pairs. Runs on the plain corpus (no learned aliases).
export function tune(corpus, weights, synonyms, pairs) {
  const base = evaluate(corpus, weights, synonyms, pairs);
  let best = { score: base.mrr + base.recall1 / 100, tuned: null, res: base };
  const g = [0.15, 0.35, 0.55];
  for (const summary of g) for (const description of g) for (const resolution of g) for (const bigramWeight of [0.25, 1]) {
    const fields = { ...weights.fields, summary, description, resolution };
    const res = evaluate(corpus, { ...weights, fields, bigramWeight }, synonyms, pairs);
    const score = res.mrr + res.recall1 / 100;
    if (score > best.score + 1e-9) best = { score, tuned: { fields, bigramWeight }, res };
  }
  return { before: base, after: best.res, tuned: best.tuned };
}
