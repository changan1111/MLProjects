import { BM25 } from '../index/bm25.js';
import { tokenize, addBigrams, buildSynonymMap, compilePhrases } from '../text/tokenize.js';

// defects: [{ key, summary, description, resolution, comments, component, ... }]
export function buildEngine(defects, weights, synonyms) {
  const synMap = buildSynonymMap(synonyms.groups);
  const phrases = compilePhrases(synonyms.phrases);
  const baseFields = Object.keys(weights.fields);
  // 'aliases' holds wording learned from confirmed feedback; it only exists once something was confirmed.
  const fieldNames = defects.some((d) => d.aliases) ? [...baseFields, 'aliases'] : baseFields;
  const wOf = (f) => (f === 'aliases' ? weights.aliasWeight ?? 0.25 : weights.fields[f]);
  const termsOf = (text) => {
    const uni = tokenize(text, synMap, phrases);
    return { uni, bi: addBigrams(uni) };
  };

  const idx = {};
  for (const f of fieldNames) {
    const docs = defects.map((d) => termsOf(d[f] || ''));
    idx[f] = {
      uni: new BM25(docs.map((x) => x.uni), weights.bm25.k1, weights.bm25.b),
      bi: new BM25(docs.map((x) => x.bi), weights.bm25.k1, weights.bm25.b),
    };
  }

  const wSum = baseFields.reduce((s, f) => s + weights.fields[f], 0);

  function search(query, { excludeKey, demote } = {}) {
    // The query defect's summary + description are matched against every field of the corpus.
    const q = termsOf(`${query.summary || ''} ${query.summary || ''} ${query.description || ''}`);
    const total = new Float64Array(defects.length);
    const parts = {};
    for (const f of fieldNames) {
      parts[f] = new Float64Array(defects.length);
      const u = idx[f].uni.score(q.uni);
      const b = idx[f].bi.score(q.bi);
      for (let i = 0; i < total.length; i++) {
        const su = u.max ? u.scores[i] / u.max : 0;
        const sb = b.max ? b.scores[i] / b.max : 0;
        const s = (su + weights.bigramWeight * sb) / (1 + weights.bigramWeight);
        const c = (wOf(f) / wSum) * s * (weights.scoreScale || 1);
        parts[f][i] = c;
        total[i] += c;
      }
    }
    const ranked = [];
    for (let i = 0; i < total.length; i++) {
      if (excludeKey && defects[i].key === excludeKey) continue;
      if (total[i] > 0) {
        const dm = demote?.get(defects[i].key) ?? 1; // pushed down by 'Not a match' feedback
        const k = (total[i] > 1 ? 1 / total[i] : 1) * dm;
        const breakdown = {};
        for (const f of fieldNames) breakdown[f] = parts[f][i] * k;
        ranked.push({ defect: defects[i], score: Math.min(1, total[i]) * dm, breakdown });
      }
    }
    ranked.sort((a, b) => b.score - a.score);
    return ranked.slice(0, weights.topK);
  }

  const band = (score) =>
    score >= weights.thresholds.strong ? 'Strong match'
      : score >= weights.thresholds.close ? 'Close match'
        : score >= weights.thresholds.possible ? 'Possible' : 'No match';

  return { search, band, tokens: (text) => tokenize(text, synMap, phrases) };
}
