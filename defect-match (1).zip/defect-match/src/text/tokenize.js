import { stemmer } from 'stemmer';

const STOP = new Set(('a an and are as at be but by for from has have if in into is it its of on or that the ' +
  'their then there these this to was were will with when while not no yes can could should would also ' +
  'issue defect bug jira ticket observed expected actual step steps please see below above ' +
  'successfully properly correctly unexpectedly randomly sometimes often really very just still again my our your me').split(' '));

// Remove Jira markup, code blocks, stack-trace lines, urls, @mentions.
export function clean(text = '') {
  return String(text)
    .replace(/\{code[^}]*\}[\s\S]*?\{code\}/gi, ' ')
    .replace(/\{noformat\}[\s\S]*?\{noformat\}/gi, ' ')
    .replace(/^\s*at\s+[\w.$<>]+\(.*\).*$/gm, ' ')
    .replace(/https?:\/\/\S+/g, ' ')
    .replace(/\[~[^\]]+\]/g, ' ')
    .replace(/!\S+!/g, ' ')
    .replace(/[{}|*_]{2,}/g, ' ');
}

export function buildSynonymMap(groups = []) {
  const map = new Map();
  for (const g of groups) for (const w of g) map.set(w.toLowerCase(), g[0].toLowerCase());
  return map;
}

// Protected tokens (error codes, exception names, ids with digits) are kept unstemmed.
const isProtected = (t) => /\d/.test(t) || /(exception|error)$/.test(t) && t.length > 9;

const esc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
// Multi-word phrases ("sign in", "changing password") become canonical tokens so different wordings meet.
export function compilePhrases(phrases = []) {
  return phrases.map(({ to, from }) => ({
    to: ` ${to} `,
    re: new RegExp(`(?<![a-z0-9])(?:${from.map((f) => esc(f.toLowerCase()).replace(/[ \-]+/g, '[\\s\\-_]+')).join('|')})(?![a-z0-9])`, 'g'),
  }));
}

export function tokenize(text, synMap = new Map(), phrases = []) {
  let t = clean(text).toLowerCase().replace(/[’]/g, "'");
  for (const { re, to } of phrases) t = t.replace(re, to);
  const words = t.replace(/[^a-z0-9_]+/g, ' ').split(' ');
  const out = [];
  for (let w of words) {
    if (w.length < 2 || STOP.has(w)) continue;
    if (isProtected(w)) { out.push(w); continue; }
    w = synMap.get(w) || w;
    w = stemmer(w);
    w = synMap.get(w) || w;
    out.push(w);
  }
  return out;
}

export function addBigrams(tokens) {
  const bi = [];
  for (let i = 0; i < tokens.length - 1; i++) bi.push(tokens[i] + '_' + tokens[i + 1]);
  return bi;
}
