import Papa from 'papaparse';
import * as XLSX from 'xlsx';

const ALIASES = {
  key: ['issue key', 'key', 'id', 'defect id'],
  summary: ['summary', 'title'],
  description: ['description', 'details'],
  resolution: ['resolution', 'root cause', 'rca', 'fix', 'resolution notes'],
  comments: ['comment', 'comments'],
  component: ['component/s', 'component', 'components', 'module'],
};

// Extra fields shown on each match (not used for scoring). Add your own column / field names here.
export const META = {
  status: ['status'], priority: ['priority'], assignee: ['assignee'], reporter: ['reporter'],
  tester: ['tester', 'tested by', 'qa', 'qa owner', 'qa assignee', 'verified by', 'test engineer'],
  build: ['build', 'build number', 'build no', 'build id', 'found in build', 'build version', 'release', 'release build', 'release build no', 'release no', 'release number', 'release version'],
  fixVersion: ['fix version/s', 'fix version', 'fix versions', 'fixversions'],
  affectsVersion: ['affects version/s', 'affects version', 'affects versions', 'versions'],
};
// Your Jira custom fields. Values are appended to (or replace) the standard fields.
export const CUSTOM = {
  comments: { ids: ['customfield_76363'], names: ['last five comments'] },
  resolution: { ids: ['customfield_10021'], names: [] },
  status: { ids: ['customfield_102851'], names: [] },
};
const metaNorm = (k) => String(k).toLowerCase().replace(/[^a-z0-9]/g, '');

// Maps whatever headers your Jira export has onto our standard fields.
// Duplicate columns (Jira repeats "Comment") are concatenated.
export function parseJiraCsv(text) {
  const { data } = Papa.parse(text, { header: false, skipEmptyLines: true });
  if (!data.length) return [];
  const headers = data[0].map((h) => String(h).trim().toLowerCase());
  const cols = {};
  for (const [field, names] of Object.entries(ALIASES)) {
    cols[field] = headers.map((h, i) => (names.includes(h) ? i : -1)).filter((i) => i >= 0);
  }
  return data.slice(1).map((row, n) => {
    const d = {};
    for (const field of Object.keys(ALIASES)) d[field] = cols[field].map((i) => row[i] || '').join(' ').trim();
    for (const [m, names] of Object.entries(META)) {
      const idxs = headers.map((h, i) => (names.map(metaNorm).includes(metaNorm(h)) ? i : -1)).filter((i) => i >= 0);
      d[m] = idxs.map((i) => row[i] || '').filter(Boolean).join(', ');
    }
    if (!d.key) d.key = `ROW-${n + 1}`;
    return d;
  });
}

// ---- JSON support (Jira REST API response or a flat array of defects) ----
const norm = (k) => String(k).toLowerCase().replace(/[^a-z0-9]/g, '');

// Flattens strings, arrays, Jira rich text (ADF) and {name}/{body} objects into plain text.
function flat(x) {
  if (x == null) return '';
  if (typeof x === 'string' || typeof x === 'number') return String(x);
  if (Array.isArray(x)) return x.map(flat).filter(Boolean).join(' ');
  if (typeof x === 'object') {
    if (typeof x.text === 'string') return x.text;
    if (x.content) return flat(x.content);
    if (x.body) return flat(x.body);
    if (x.comments) return flat(x.comments);
    if (x.displayName) return x.displayName;
    if (x.name) return x.name;
    if (x.value) return flat(x.value);
  }
  return '';
}

const JSON_ALIASES = {
  summary: ['summary', 'title'],
  description: ['description', 'details'],
  resolution: ['rootcause', 'rca', 'resolutionnotes', 'resolutiondescription', 'fix', 'resolution'],
  comments: ['comment', 'comments'],
  component: ['components', 'component', 'module'],
};


function applyCustom(d, byId, byName) {
  for (const [field, { ids, names }] of Object.entries(CUSTOM)) {
    const vals = [...new Set([...ids.map(byId), ...names.map(byName)].filter(Boolean))];
    if (!vals.length) continue;
    d[field] = field === 'status' ? vals[0] : [d[field], ...vals].filter(Boolean).join(' ');
  }
}

export function parseJiraJson(text) {
  const data = JSON.parse(text);
  const items = Array.isArray(data) ? data : data.issues || data.defects || data.results || [];
  return items.map((item, n) => {
    const f = item.fields || item;
    const lookup = new Map(Object.keys(f).map((k) => [norm(k), f[k]]));
    const d = { key: item.key || f.key || item.id || `ROW-${n + 1}` };
    for (const [field, names] of Object.entries(JSON_ALIASES)) {
      d[field] = names.map((a) => flat(lookup.get(a))).filter(Boolean).join(' ').trim();
    }
    for (const [m, names] of Object.entries(META)) {
      d[m] = [...new Set([...new Set(names.map(metaNorm))].map((a) => flat(lookup.get(a))).filter(Boolean))].join(', ');
    }
    applyCustom(d, (id) => flat(lookup.get(metaNorm(id))), () => '');
    return d;
  });
}

// ---- XML support (Jira "XML" export: <item> per defect, <customfield id="customfield_N">) ----
const decode = (t) => t
  .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
  .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&')
  .replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
const all = (xml, name) => [...xml.matchAll(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, 'g'))].map((m) => decode(m[1])).filter(Boolean);
const one = (xml, name) => all(xml, name)[0] || '';

export function parseJiraXml(text) {
  const items = text.match(/<item>[\s\S]*?<\/item>/g) || [];
  return items.map((raw, n) => {
    const cfs = [...raw.matchAll(/<customfield\s+id="([^"]+)"[^>]*>([\s\S]*?)<\/customfield>/g)];
    const byId = new Map(), byName = new Map();
    for (const [, id, body] of cfs) {
      // user-type fields keep the person's name in displayname="..." and an id as the text
      const v = [...body.matchAll(/<customfieldvalue(?:\s([^>]*))?>([\s\S]*?)<\/customfieldvalue>/g)]
        .map((m) => decode((m[1] || '').match(/displayname="([^"]*)"/i)?.[1] || m[2])).filter(Boolean).join(' ');
      byId.set(id.toLowerCase(), v);
      byName.set(metaNorm(one(body, 'customfieldname')), v);
    }
    const x = raw.replace(/<customfields>[\s\S]*?<\/customfields>/, ''); // standard tags only
    const d = {
      key: one(x, 'key') || `ROW-${n + 1}`,
      summary: one(x, 'summary') || one(x, 'title'),
      description: one(x, 'description'),
      resolution: one(x, 'resolution'),
      comments: all(x, 'comment').join(' '),
      component: all(x, 'component').join(', '),
      status: one(x, 'status'), priority: one(x, 'priority'),
      assignee: one(x, 'assignee'), reporter: one(x, 'reporter'),
      fixVersion: all(x, 'fixVersion').join(', '), affectsVersion: all(x, 'version').join(', '),
      tester: '', build: '',
    };
    // tester / build etc. often live in custom fields whose NAME matches
    for (const [m, names] of Object.entries(META)) {
      if (d[m]) continue;
      d[m] = [...new Set(names.map(metaNorm))].map((a) => byName.get(a)).filter(Boolean).join(', ');
    }
    applyCustom(d, (id) => byId.get(id.toLowerCase()) || '', (nm) => byName.get(metaNorm(nm)) || '');
    return d;
  });
}

// One entry point: picks JSON or CSV from the content, so .csv, .json and .txt all work.
export function parseDefects(text) {
  const t = text.replace(/^\uFEFF/, '').trim();
  if (t.startsWith('{') || t.startsWith('[')) return parseJiraJson(t);
  if (t.startsWith('<')) return parseJiraXml(t);
  return parseJiraCsv(t);
}

// ---- Excel (.xlsx / .xls): every sheet, header row found automatically (title rows above it are skipped) ----
export function parseWorkbook(buffer) {
  const wb = XLSX.read(buffer, { type: 'array' });
  const out = [], seen = new Set();
  for (const name of wb.SheetNames) {
    const rows = XLSX.utils.sheet_to_json(wb.Sheets[name], { header: 1, raw: false, defval: '' });
    const at = rows.findIndex((r) => r.some((c) => ['summary', 'title', 'issuekey', 'key'].includes(metaNorm(c))));
    if (at < 0) continue;
    for (const d of parseJiraCsv(Papa.unparse(rows.slice(at)))) {
      if (!seen.has(d.key)) { seen.add(d.key); out.push(d); }
    }
  }
  return out;
}
