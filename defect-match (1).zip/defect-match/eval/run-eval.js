// Usage: node eval/run-eval.js [defects.csv] [gold.csv]
// Prints Recall@1/3/5 and MRR. Run this after every change to weights/synonyms/code.
import fs from 'node:fs';
import Papa from 'papaparse';
import { parseDefects } from '../src/ingest/jira.js';
import { buildEngine } from '../src/search/engine.js';

const defectsPath = process.argv[2] || 'data/sample-defects.csv';
const goldPath = process.argv[3] || 'data/sample-gold.csv';
const weights = JSON.parse(fs.readFileSync('config/weights.json', 'utf8'));
const synonyms = JSON.parse(fs.readFileSync('config/synonyms.json', 'utf8'));

const defects = parseDefects(fs.readFileSync(defectsPath, 'utf8'));
const gold = Papa.parse(fs.readFileSync(goldPath, 'utf8'), { header: true, skipEmptyLines: true }).data;
const byKey = new Map(defects.map((d) => [d.key, d]));
const engine = buildEngine(defects, { ...weights, topK: 1000 }, synonyms);

let hit1 = 0, hit3 = 0, hit5 = 0, rr = 0, n = 0;
for (const g of gold) {
  // A gold row names either an existing defect (query_key) or free text (query_text).
  const q = g.query_text ? { key: 'T', summary: g.query_text, description: '' } : byKey.get(g.query_key);
  if (!q) { console.warn('missing query', g.query_key); continue; }
  const ranked = engine.search(q, { excludeKey: g.query_text ? undefined : q.key });
  const rank = ranked.findIndex((r) => r.defect.key === g.match_key) + 1;
  n++;
  if (rank === 1) hit1++;
  if (rank >= 1 && rank <= 3) hit3++;
  if (rank >= 1 && rank <= 5) hit5++;
  if (rank > 0) rr += 1 / rank;
  console.log(`${g.query_key || g.query_text.slice(0, 45)} -> expect ${g.match_key}: rank ${rank || 'not found'}`);
}
const pct = (x) => ((100 * x) / n).toFixed(0) + '%';
console.log(`\npairs=${n}  Recall@1=${pct(hit1)}  Recall@3=${pct(hit3)}  Recall@5=${pct(hit5)}  MRR=${(rr / n).toFixed(3)}`);
