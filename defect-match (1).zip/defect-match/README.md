# Defect Match

Offline Jira defect similarity search. Plain JavaScript, no models, no network calls.

## Use at the office (no install)
Open `dist/index.html` (downloaded from GitHub Actions artifact), load your Jira CSV export, paste up to 100 summaries, click Find matches, Export CSV.

## Tune accuracy
1. Put real known-duplicate pairs in a gold CSV (columns: query_key,match_key,note). Keep real data out of GitHub (data/real* is git-ignored).
2. `node eval/run-eval.js your-defects.csv your-gold.csv` prints Recall@1/3/5 and MRR.
3. Edit `config/weights.json` (field weights, bigram weight, thresholds) and `config/synonyms.json`; re-run eval. Keep changes that improve the numbers.

## Layout
src/text (cleaning, stemming, bigrams) · src/index (BM25) · src/search (field-weighted engine) · src/ingest (Jira CSV mapping) · src/ui · eval · config
